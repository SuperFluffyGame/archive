function setup() {
  createCanvas(400, 400);
  console.log(hyper(5,2,3))
}

function draw() {
  background(220);
}
function hyper(n,a,b){
  if(typeof n !== 'bigint'){
    n = BigInt(n)
  }
  if(typeof n !== 'bigint'){
    a = BigInt(a)
  }
  if(typeof n !== 'bigint'){
    b = BigInt(b)
  }
  if (n === BigInt(0)) {
    return b + BigInt(1)
  }
  if (n === BigInt(1)) {
    return a + b
  }
  if (n === BigInt(2)) {
    return a * b
  }
  if (n === BigInt(3)) {
    return a ** b
  }
  let result = a
  if(n > 0){
    for (let i = BigInt(1); i < b; i++) {

      result = hyper(n - BigInt(1), a, result)
    }
  }
  return String(result)
}
const bigH = (n, a, b) => {
  if (n < BigInt(0) || a < BigInt(0) || b < BigInt(0)) {
    throw Error('Can only hyperoperate on non-negative integers')
  }

  // successor operator
  if (n === BigInt(0)) {
    // Ignore `a`
    return b + BigInt(1)
  }

  // addition
  if (n === BigInt(1)) {
    return a + b
  }

  // multiplication
  if (n === BigInt(2)) {
    return a * b
  }

  // exponentiation
  if (n === BigInt(3)) {
    return a ** b
  }

  // n >= 4, time for some handy base cases

  if (a === BigInt(0)) {
    // Fun fact:
    return b % BigInt(2) === BigInt(0) ? BigInt(1) : BigInt(0)
  }

  if (a === BigInt(1)) {
    // 1^...^b = 1 for all finite b
    return BigInt(1)
  }

  // a >= 2

  if (b === BigInt(0)) {
    // a^0 = 1 for all a >= 2
    return BigInt(1)
  }

  if (b === BigInt(1)) {
    // a^...^1 = a for all a >= 2
    return a
  }

  // b >= 2

  if (a === BigInt(2) && b === BigInt(2)) {
    // Another fun fact
    return BigInt(4)
  }

  let result = a
  for (let i = BigInt(1); i < b; i++) {
    // This can cause a stack explosion... unavoidable because H is not primitive recursive
    result = bigH(n - BigInt(1), a, result)
  }

  return result
}

const H = (n, a, b) => {
  if ([n, a, b].every(arg => typeof arg === 'bigint')) {
    return bigH(n, a, b)
  }

  if ([n, a, b].every(arg => Number.isInteger(arg))) {
    // All plain doubles... convert inputs to `BigInt`s, then convert the result back to a double
    try {
      return Number(bigH(BigInt(n), BigInt(a), BigInt(b)))
    } catch (error) {
      // Not clear what other error could be thrown at this stage?
      /* istanbul ignore if */
      if (!(
        error instanceof RangeError &&
        (
          error.message.includes('BigInt') || // BigInt overflow
          error.message.includes('stack') // stack overflow
        )
      )) {
        throw error
      }
    }

    return Infinity
  }

  throw Error('Can only hyperoperate on three numbers or three BigInts')
}