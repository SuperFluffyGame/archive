function precedence(op){
  switch(op){
    case "+":{
      return 2
    }
    case "-":{
      return 2
    }
    case "*":{
      return 3
    }
    case "/":{
      return 3
    }
    case "^":{
      return 4
    }

  }
}

function mathInterp(str){
//   let chars = str.split("")
//   chars = chars.filter(e=>e.match(/\S/))
  
//   let outQ = []
//   let opQ = []
  
//   for(let ch of chars){
//     if(ch == ch.match(/\d/)){
//       outQ.push(ch)
//     }else if(ch == ch.match(/[\+\-\*\/\^\(\)]/)){
//       if(precedence(ch) <= precedence(opQ[opQ.length-1])){
//         outQ.push(opQ.pop())
//       }
//       opQ.push(ch)
//     }
//   }
  
//   for(let i = 0; i < opQ.length+1; i++){
//     outQ.push(opQ.pop())
//   }
  
//   return outQ.join(" ")
}