function add1(var1,var2){
  return var1 + var2
}
const add2 = function(var1,var2){
  return var1 + var2
}
const add3 = (var1,var2) => {
  return var1 + var2
}
const double = var1 => var1*2

let array = [1,3,2,4,3,10]
function setup() {
  let n1 = 10
  let n2 = 20
  console.log(double(n2))
  array = array.map((num,index,arr) => num * arr[index-1])
  array.shift()
  console.log(array)
}