window.onload = preload
function preload(){
  main()
}
let a
function main(){
  a = newDiv()
  a.style = `
position: absolute;
height: 40px;
top: 10px;
aspect-ratio: 1;
background:blue;`
  a.textContent = "HI"
}
function newDiv(mainCanvas){
  let out = document.createElement('div')
  mainCanvas.appendChild(out)
  return out
}
function