let pPoint
let mpoint
function setup() {
  createCanvas(400, 400);
  strokeWeight(2)
  pPoint = createVector(0,0)
  mpoint = createVector(0,0)
}
function draw() {
  background(220);
  translate(0,height/2)
  // point = createVector(0,0)
  for(let i = 0; i < width; i += 0.01){
    //pPoint = (point)
    mpoint = createVector(i,tan(i/10)*10)
    point(mpoint)
  }
  // for(let x = 0; x < width; x += 1){
  //   for(let y = -height/2; y < height/2; y += 1){
  //     if(isAround(y,-(log(x)*10),0.5)){
  //       point(x,y)
  //     }
  //   }
  // }
  text(round(frameRate()),0,0)
}
function deepCloneVector(vector){
  return createVector(vector.x,vector.y)
}
function isAround(a,b,epsilon){
  if(abs(a-b) < epsilon*1.001){
    return true
  } else{
    return false
  }
}