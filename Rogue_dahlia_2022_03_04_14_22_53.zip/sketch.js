window.onload = setup
function setup(){
  gl = createCanvas(400,400,'webgl')
  main()
}
function main(){
  gl.clearColor(0,0,0,1)
  gl.clear(gl.COLOR_BUFFER_BIT)
}
function createCanvas(width,height,context){
  c = document.createElement('canvas')
  c.width = width; c.height = height;
  document.body.appendChild(c)
  return c.getContext(context)
}