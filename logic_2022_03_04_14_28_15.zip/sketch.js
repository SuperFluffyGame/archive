let tGate1
let glIn

let nodes = []
function setup() {
  createCanvas(400, 400);
  textSize(20)
  textAlign(CENTER,CENTER)
  
  tGate1 = new NotGate()
  glIn = new GlobalIn(100)
  nodes.push(tGate1,glIn)
}

function draw() {
  background(220);
  nodes.forEach((elem)=>{
    elem.show()
  })
}
class Gate{
  constructor(numIn,numOut,name){
    this.numIn = numIn
    this.numOut = numOut
    this.inputs = []
    this.outputs = []
    for(let i = 0; i < numIn; i++){
      this.inputs.push(0)
    }
    for(let i = 0; i < numOut; i++){
      this.outputs.push(0)
    }
    this.logic = ()=>{}
    
    this.name = name
    this.pos = createVector(100,100)
    this.size = createVector(textWidth(this.name)+20,max(30,numIn*20))
  }
  show(){
    this.logic()
    stroke(0)
    fill('lightblue')
    rect(this.pos.x,this.pos.y,this.size.x,this.size.y)
    noStroke()
    fill('black')
    text(this.name,this.pos.x+this.size.x/2,
         this.pos.y+this.size.y/2+2.5)
    for(let i = 0; i < this.numIn; i++){
      if(this.inputs[i] == 0){
        fill('black')
      }else{
        fill('red')
      }
      circle(this.pos.x,
             this.pos.y+(this.size.y/(this.numIn+1))*(i+1),
             5)
    }
    for(let i = 0; i < this.numOut; i++){
      if(this.outputs[i] == 0){
        fill('black')
      }else{
        fill('red')
      }
      circle(this.pos.x+this.size.x,
             this.pos.y+(this.size.y/(this.numIn+1))*(i+1),
             5)
    }
  }
}
class NotGate extends Gate{
  constructor(){
    super(1,1,"NOT")
    this.logic = ()=>{
       if(this.inputs[0] == 0){
         this.outputs[0] = 1
       } else if(this.inputs[0] == 1){
         this.outputs[0] = 0
       } 
    }
  }
}
class GlobalIn{
  constructor(y){
    this.state = 1
    this.pos = createVector(0,y)
  }
  show(){
    stroke(0)
    if(this.state == 0){
      fill('black')
    }else{
      fill('red')
    }
    circle(0,this.pos.y,20)
  }
}