function stringToByteArray(string){
  let t = new TextEncoder()
  return t.encode(string)
}
function byteArrayToString(arr){
  arr = new Uint8Array(arr).buffer
  let t = new TextDecoder("utf-8")
  return t.decode(arr)
}
function LEsignedShort(num){
  let a = new Int16Array([num])
  let b = new Uint8Array(a.buffer)
  return [...b]
}
function LEunsignedShort(num){
  let a = new Uint16Array([num])
  let b = new Uint8Array(a.buffer) 
  return [...b]
}
function LEsignedInt(num){
  let a = new Int32Array([num])
  let b = new Uint8Array(a.buffer)
  return [...b]
}
function LEsignedLong(num){
  let a = new BigInt64Array([BigInt(num)])
  let b = new Uint8Array(a.buffer)
  return [...b]
}
function LEsignedFloat(float){
  let a = new Float32Array([float])
  let b = new Uint8Array(a.buffer)
  return [...b]
}
function LEsignedDouble(double){
  let a = new Float64Array([double])
  let b = new Uint8Array(a.buffer)
  return [...b]
}
function LEsignedByte(num){
  let a = new Int8Array([num])
  let b = new Uint8Array(a.buffer)
  return [...b]
}

//PARSERS
function parseLEsignedShort(arr){
  let a = new Uint8Array(arr)
  let b = new Int16Array(a.buffer)
  return b[0]
}
function parseLEunsignedShort(arr){
  let a = new Uint8Array(arr)
  let b = new Uint16Array(a.buffer)
  return b[0]
}
function parseLEsignedByte(num){
  let a = new Uint8Array([num])
  let b = new Int8Array(a.buffer)
  return b[0]
}
function parseLEsignedInt(arr){
  let a = new Uint8Array(arr)
  let b = new Int32Array(a.buffer)
  return b[0]
}
function parseLEsignedLong(arr){
  let a = new Uint8Array(arr)
  let b = new BigInt64Array(a.buffer)
  return b[0]
}
function parseLEsignedFloat(arr){
  let a = new Uint8Array(arr)
  let b = new FLoat32Array(a.buffer)
  return b[0]
}
function parseLEsignedDouble(arr){
  let a = new Uint8Array(arr)
  let b = new Float64Array(a.buffer)
  return b[0]
}