const nbtTags = {
  End:        0,
  Byte:       1, 
  Short:      2,
  Int:        3,
  Long:       4, 
  Float:      5,
  Double:     6,
  ByteArray:  7,  
  String:     8,
  List:       9, 
  Compound:   10,
  IntArray:   11, 
  LongArray:  12  
}
function compileNBT(json, inList=false){
  let bytes = []
  for(let e in json){
    let type = json[e].type
    let value = json[e].value
    let listType = json[e].listType
    //COMPOUND
    if(type == "Compound"){
      if(!inList){
        bytes.push(nbtTags.Compound)
        bytes.push(...LEunsignedShort(e.length))
        bytes.push(...stringToByteArray(e))
      }
      bytes.push(...compileNBT(value))
      bytes.push(0)
    }
    //BYTE
    else if(type == "Byte"){
      if(!inList){
        bytes.push(nbtTags.Byte)
        bytes.push(...LEunsignedShort(e.length))
        bytes.push(...stringToByteArray(e))
      }
      bytes.push(...LEsignedByte(value))
    }
    //SHORT
    else if(type == "Short"){
      if(!inList){
        bytes.push(nbtTags.Short)
        bytes.push(...LEunsignedShort(e.length))
        bytes.push(...stringToByteArray(e))
      }
      bytes.push(...LEsignedShort(value))
    }
    //INT
    else if(type == "Int"){
      if(!inList){
        bytes.push(nbtTags.Int)
        bytes.push(...LEunsignedShort(e.length))
        bytes.push(...stringToByteArray(e))
      }
      bytes.push(...LEsignedInt(value))
    }
    //LONG
    else if(type == "Long"){
      if(!inList){
        bytes.push(nbtTags.Long)
        bytes.push(...LEunsignedShort(e.length))
        bytes.push(...stringToByteArray(e))
      }
      bytes.push(...LEsignedLong(value))
    }
    //FLOAT
    else if(type == "Float"){
      if(!inList){
        bytes.push(nbtTags.Float)
        bytes.push(...LEunsignedShort(e.length))
        bytes.push(...stringToByteArray(e))
      }
      bytes.push(...LEsignedFloat(value))
    }
    //DOUBLE
    else if(type == "Double"){
      if(!inList){
        bytes.push(nbtTags.Double)
        bytes.push(...LEunsignedShort(e.length))
        bytes.push(...stringToByteArray(e))
      }
      bytes.push(...LEsignedDouble(value))
    }
    //BYTE ARRAY
    else if(type == "ByteArray"){
      if(!inList){
        bytes.push(nbtTags.ByteArray)
        bytes.push(...LEunsignedShort(e.length))
        bytes.push(...stringToByteArray(e))
      }
      bytes.push(...LEsignedInt(value.length))
      value.forEach((el,i,a) => {
        bytes.push(...LEsignedByte(el))
      })
    }
    //STRING
    else if(type == "String"){
      if(!inList){
        bytes.push(nbtTags.String)
        bytes.push(...LEunsignedShort(e.length))
        bytes.push(...stringToByteArray(e))
      }
      bytes.push(...LEunsignedShort(value.length))
      bytes.push(...stringToByteArray(value))
    }
    //LIST
    else if(type == "List"){
      if(!inList){
        bytes.push(nbtTags.List)
        bytes.push(...LEunsignedShort(e.length))
        bytes.push(...stringToByteArray(e))
      }
      bytes.push(nbtTags[listType])
      bytes.push(...LEsignedInt(json[e].value.length))
      let d = {}
      value.forEach((el,i,a)=>{
        el.type = listType
        d[i] = el
      })
      bytes.push(...compileNBT(d,true))
      
    }
    //INT ARRAY
    else if(type == "IntArray"){
      if(!inList){
        bytes.push(nbtTags.IntArray)
        bytes.push(...LEunsignedShort(e.length))
        bytes.push(...stringToByteArray(e))
      }
      bytes.push(...LEsignedInt(value.length))
      value.forEach((el,i,a) => {
        bytes.push(...LEsignedInt(el))
      })
    }
    //LONG ARRAY
    else if(type == "LongArray"){
      if(!inList){
        bytes.push(nbtTags.LongArray)
        bytes.push(...LEunsignedShort(e.length))
        bytes.push(...stringToByteArray(e))
      }
      bytes.push(...LEsignedInt(value.length))
      value.forEach((el,i,a) => {
        bytes.push(...LEsignedLong(el))
      })
    }
    else{
      return new Error("Type not supported: " + type + ". " + "(" + e + ")")
    }
  }
  return bytes
}
function exportNBTasString(arr){
  if(arr.constructor.name == "Error"){return arr}
  return arr.map(e=>e.toString(16).padStart(2,0)).join('')
}
function exportNBTasFile(arr,name){
  let buf = new ArrayBuffer(arr.length)
  let dataArray = new Int8Array(buf)
  dataArray.set(arr,0)
  return new Blob([dataArray.buffer],{type: "application/octet-stream"})
}