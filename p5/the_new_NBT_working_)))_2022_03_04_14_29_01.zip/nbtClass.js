class NBT{
  constructor(data){
    this.data = data
  }
  exportString(){
    let compiled = compileNBT(this.data)
    return exportNBTasString(compiled)
  }
  exportBlob(){
    let compiled = compileNBT(this.data)
    return exportNBTasFile(compiled)
  }
  exportArray(){
    return compileNBT(this.data)
  }
}
class Block extends NBT{
  constructor(name,states){
    super({})
    this.blockData = {
      name: name,
      states: states
    }
    this.data = {
      "-Compound": {
        "String | name": this.blockData.name,
        "Compound | states": this.blockData.states
      }
    }
  }
}
class Structure extends NBT{
  constructor(sizeX,sizeY,sizeZ){
    super({})
    this.blocks = []
    this.data = {
      "Compound | ": {
        "Int | format_version": 1,
        "List | Int | size": [
          {"-Int": sizeX},
          {"-Int": sizeY},
          {"-Int": sizeZ}
        ]
      }
    }
  }
}