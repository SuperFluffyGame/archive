function nextBytes(arr,c,l){
  let out = []
  for(let i = 0; i < l; i++){
    out.push(arr[c+i])
  }
  return out
}
function parseNBT(bin, currentIndex=0, inList=false){ 
  let out = {}
  while(currentIndex <= bin.length){
         if(bin[currentIndex] == nbtTags.End){
           return {data: out, index: currentIndex}
         }
    else if(bin[currentIndex] == nbtTags.Compound){
      currentIndex ++
      //name length
      let nameLength = parseLEsignedShort(nextBytes(bin,currentIndex,2))
      currentIndex += 2
      //name
      let name = byteArrayToString(nextBytes(bin,currentIndex,nameLength))
      currentIndex += nameLength
      //the object
      let a = parseNBT(bin,currentIndex)
      out[name] = a.data
      currentIndex = a.index
    }
    else if(bin[currentIndex] == nbtTags.Byte){
      currentIndex ++

      let nameLength = parseLEsignedShort(nextBytes(bin,currentIndex,2))
      currentIndex += 2

      let name = byteArrayToString(nextBytes(bin,currentIndex,nameLength))
      currentIndex += nameLength

      out[name] = parseLEsignedByte(nextBytes(bin,currentIndex,1))
      currentIndex ++
    }
    else if(bin[currentIndex] == nbtTags.Short){
      currentIndex ++

      let nameLength = parseLEsignedShort(nextBytes(bin,currentIndex,2))
      currentIndex += 2

      let name = byteArrayToString(nextBytes(bin,currentIndex,nameLength))
      currentIndex += nameLength

      out[name] = parseLEsignedShort(nextBytes(bin,currentIndex,2))
      currentIndex += 2
    }
    else if(bin[currentIndex] == nbtTags.Int){
      currentIndex ++

      let nameLength = parseLEsignedShort(nextBytes(bin,currentIndex,2))
      currentIndex += 2

      let name = byteArrayToString(nextBytes(bin,currentIndex,nameLength))
      currentIndex += nameLength

      out[name] = parseLEsignedInt(nextBytes(bin,currentIndex,4))
      currentIndex += 4
    }
    else if(bin[currentIndex] == nbtTags.Long){
      currentIndex ++

      let nameLength = parseLEsignedShort(nextBytes(bin,currentIndex,2))
      currentIndex += 2

      let name = byteArrayToString(nextBytes(bin,currentIndex,nameLength))
      currentIndex += nameLength

      out[name] = parseLEsignedLong(nextBytes(bin,currentIndex,4))
      currentIndex += 8
    }
    else if(bin[currentIndex] == nbtTags.Float){
      currentIndex ++

      let nameLength = parseLEsignedShort(nextBytes(bin,currentIndex,2))
      currentIndex += 2

      let name = byteArrayToString(nextBytes(bin,currentIndex,nameLength))
      currentIndex += nameLength

      out[name] = parseLEsignedFloat(nextBytes(bin,currentIndex,4))
      currentIndex += 4
    }
    else if(bin[currentIndex] == nbtTags.Double){
      currentIndex ++

      let nameLength = parseLEsignedShort(nextBytes(bin,currentIndex,2))
      currentIndex += 2

      let name = byteArrayToString(nextBytes(bin,currentIndex,nameLength))
      currentIndex += nameLength

      out[name] = parseLEsignedDouble(nextBytes(bin,currentIndex,4))
      currentIndex += 8
    }
    else if(bin[currentIndex] == nbtTags.ByteArray){
      currentIndex ++

      let nameLength = parseLEsignedShort(nextBytes(bin,currentIndex,2))
      currentIndex += 2

      let name = byteArrayToString(nextBytes(bin,currentIndex,nameLength))
      currentIndex += nameLength
      
      let arrayLength = parseLEsignedInt(nextBytes(bin,currentIndex,4))
      currentIndex += 4

      let ba = nextBytes(bin,currentIndex,arrayLength)
      currentIndex += arrayLength
      
      out[name] = ba
    }
    else if(bin[currentIndex] == nbtTags.String){
      currentIndex ++

      let nameLength = parseLEsignedShort(nextBytes(bin,currentIndex,2))
      currentIndex += 2

      let name = byteArrayToString(nextBytes(bin,currentIndex,nameLength))
      currentIndex += nameLength

      let stringLength = parseLEunsignedShort(nextBytes(bin,currentIndex,2))
      currentIndex += 2
      
      out[name] = byteArrayToString(nextBytes(bin,currentIndex,stringLength))
      currentIndex += stringLength
    }
    else if(bin[currentIndex] == nbtTags.List){
      currentIndex ++
      
    }
    else{
      currentIndex ++
    }
  }
  
  return {data: out, index: currentIndex}
}
function parseNBTlist(type,length,bytes,index){
  return {data: {},index: index}
}
function parseBinaryFromString(string){
  let bin = []
  bin = string.match(/.{1,2}/g)
  bin.forEach((e,i,a)=>{
    bin[i] = parseInt(e,16)
  })
  return bin
}
function parseBinaryFromFile(file){
  
}