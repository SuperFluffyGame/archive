let nbt, dirtBlock
let dirtNBT = [
  10,0,0,3,14,0,102,111,114,109,97,116,95,118,101,114,115,105,111,110,1,0,0,0,9,4,0,115,105,122,101,3,3,0,0,0,1,0,0,0,1,0,0,0,1,0,0,0,10,9,0,115,116,114,117,99,116,117,114,101,9,13,0,98,108,111,99,107,95,105,110,100,105,99,101,115,9,2,0,0,0,3,1,0,0,0,0,0,0,0,3,1,0,0,0,255,255,255,255,9,8,0,101,110,116,105,116,105,101,115,0,0,0,0,0,10,7,0,112,97,108,101,116,116,101,10,7,0,100,101,102,97,117,108,116,9,13,0,98,108,111,99,107,95,112,97,108,101,116,116,101,10,1,0,0,0,8,4,0,110,97,109,101,14,0,109,105,110,101,99,114,97,102,116,58,100,105,114,116,10,6,0,115,116,97,116,101,115,8,9,0,100,105,114,116,95,116,121,112,101,6,0,110,111,114,109,97,108,0,3,7,0,118,101,114,115,105,111,110,3,210,16,1,0,10,19,0,98,108,111,99,107,95,112,111,115,105,116,105,111,110,95,100,97,116,97,0,0,0,0,9,22,0,115,116,114,117,99,116,117,114,101,95,119,111,114,108,100,95,111,114,105,103,105,110,3,3,0,0,0,110,0,0,0,200,255,255,255,109,254,255,255,0]
function setup() {
  createCanvas(400, 400);
  background(220);

  nbt = new NBT(nbtJSON)
  console.log(nbt.exportString())
  
  console.log(parseNBT(compileNBT(nbtJSON)).data)
  
  
  let link = document.createElement('a')
  let url = URL.createObjectURL(nbt.exportBlob())
  link.href = url
  link.innerText = "Export"
  document.body.appendChild(link)
  
  let fileIn = document.createElement('input')
  fileIn.type = "file"
  fileIn.id = "file"
  document.body.appendChild(fileIn)
  
  
//   let myStructure = new Structure(1,1,1)
//   console.log(myStructure.exportString())
  
//   let dirtBlock = new Block('minecraft:dirt', {
//     "Compound | states": {
//       "String | dirt_type": "normal"
//     }
//   })
//   console.log(drtBlock.exportString())
}
let file, fileBuff, fileBin
async function draw(){
  file = await document.getElementById("file").files[0]
  if(file !== undefined){
    fileBuff = await file.arrayBuffer()
    fileBin = [...new Uint8Array(fileBuff)]
  }
}

let nbtJSON = {
  "": {type: "Compound","value": {
    "nim": {type: "String", value: "hi"},
    "testInt": {type: "Int", value: -100},
    "la bit": {type: "Byte", value: 30},
    "sampleList": {type: "List", listType: "List", value: [
      {listType: "Int", value: [
        {value: 200}
       ]}
     ]},
    "mi float": {type: "Float", value: 1.23},
    "super float": {type: "Double", value: 1.23456},
    "BA": {type: "ByteArray", value: [1,2,3]}
    }
  }
}