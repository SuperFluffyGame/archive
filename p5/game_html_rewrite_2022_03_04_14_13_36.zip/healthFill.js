//document.getElementById("background").style.height = 
function max(num1,num2){
  if(num1 >= num2){return num2}
  else if(num2 >= num1){return num1}
  else{console.log("Error on healthFill.js line 1-5")}
}
class weapon {
  constructor(name, image, damage, cost) {
    this.l1 = document.createElement("DIV")
    this.l2 = document.createElement("DIV")
    this.dImage = document.createElement("DIV")
    this.nameObj = document.createElement("DIV")
    this.damageObj = document.createElement("DIV")
    this.costObj = document.createElement("DIV")
    
    this.name = name
    this.image = image
    this.damage = damage
    this.cost = cost
    this.shopDraw()

    document.body.appendChild(this.costObj)
    document.body.appendChild(this.damageObj)
    document.body.appendChild(this.nameObj)
    document.body.appendChild(this.dImage)
    document.body.appendChild(this.l1)
    document.body.appendChild(this.l2)

  }
  draw(x, y) {
    this.dImage.style.position = "absolute"
    this.dImage.style.width = "8vw"
    this.dImage.style.height = "8vw"
    this.dImage.style.backgroundImage = "url(" + this.image + ")"
    this.dImage.style.top = "calc(" + y + "vw - 4vw)"
    this.dImage.style.left = "calc(" + x + "vw - 4vw)"
    this.dImage.style.zIndex = 6
    this.dImage.style.backgroundSize = "8vw"
    this.dImage.style.display = "block"
  }
  shopDraw(y) {
    this.l1s = this.l1.style
    this.l1s.position = "absolute"
    this.l1s.left = 0
    this.l1s.right = 0
    this.l1s.top = y + "vw"
    this.l1s.margin = "auto"
    this.l1s.width = "60vw"
    this.l1s.height = "0.4vw"
    this.l1s.background = "black"
    this.l1s.zIndex = 7
    this.l1s.display = "block"

    this.l2s = this.l2.style
    this.l2s.position = "absolute"
    this.l2s.left = 0
    this.l2s.right = 0
    this.l2s.top = (y + 8) + "vw"
    this.l2s.margin = "auto"
    this.l2s.width = "60vw"
    this.l2s.height = "0.4vw"
    this.l2s.background = "black"
    this.l2s.zIndex = 7
    this.l2s.display = "block"

    this.nameObjs = this.nameObj.style
    this.nameObjs.position = "absolute"
    this.nameObjs.left = "8vw"
    this.nameObjs.top = (y+3)  + "vw"
    this.nameObjs.margin = "auto"
    this.nameObjs.width = "60vw"
    this.nameObjs.height = "0.4vw"
    this.nameObjs.zIndex = 7
    this.nameObjs.display = "block"
    this.nameObj.innerHTML = this.name
    this.nameObjs.textAlign = "center"
    this.nameObjs.fontSize = "2vw"
    
    this.damageObjs = this.damageObj.style
    this.damageObjs.position = "absolute"
    this.damageObjs.left = "24vw"
    this.damageObjs.top = (y+3)  + "vw"
    this.damageObjs.margin = "auto"
    this.damageObjs.width = "60vw"
    this.damageObjs.height = "0.4vw"
    this.damageObjs.zIndex = 7
    this.damageObjs.display = "block"
    this.damageObj.innerHTML = this.damage
    this.damageObjs.textAlign = "center"
    this.damageObjs.fontSize = "2vw"

    
    this.costObjs = this.costObj.style
    this.costObjs.position = "absolute"
    this.costObjs.left = "35.5vw"
    this.costObjs.top = (y+3)  + "vw"
    this.costObjs.margin = "auto"
    this.costObjs.width = "60vw"
    this.costObjs.height = "0.4vw"
    this.costObjs.zIndex = 7
    this.costObjs.display = "block"
    this.costObj.innerHTML = this.cost
    this.costObjs.textAlign = "center"
    this.costObjs.fontSize = "2vw"
    
    
    this.draw(25, y + 4.5)
  }
  hide() {
    this.l1s.display = "none"
    this.l2s.display = "none"
    this.dImage.style.display = "none"
    this.costObjs.display = "none"
    this.nameObjs.display = "none"
    this.damageObjs.display = "none"
  }
}

class screen {
  constructor(name, z_index, showName, width, height, top) {
    this.name = name
    this.z_index = z_index
    this.screen = document.createElement("DIV")
    var a = this.screen.style
    a.display = "block"
    a.width = width + "vw"
    a.height = height + "vw"
    a.position = "absolute"
    a.background = "white"
    a.left = 0
    a.right = 0
    a.top = top + "vw"
    a.margin = "0 auto"
    a.bottom = 0
    a.border = "1vw solid black"
    a.borderRadius = "5px"
    a.zIndex = this.z_index
    a.textAlign = "center"
    a.fontSize = "4vw"
    document.body.appendChild(this.screen)
    if (showName) {
      this.screen.innerHTML = this.name
    }
  }
  show() {
    this.screen.style.display = "initial"
  }
  hide() {
    this.screen.style.display = "none"
  }
}

class menuThing {
  constructor(name, zIndex, icon) {
    this.name = name
    this.zIndex = zIndex
    this.thing = document.createElement("DIV")
    this.a = this.thing.style
    this.thing.setAttribute("id", "menu")
    this.a.display = "block"
    this.a.width = 14.5 + "vw"
    this.a.height = 12.5 + "vw"
    this.a.position = "absolute"
    this.a.background = "white"
    this.a.left = 0
    this.a.right = 0
    this.a.top = 10 + "vw"
    this.a.margin = "0 auto"
    this.a.bottom = 0
    this.a.border = "0.4vw solid black"
    this.a.borderRadius = "5px"
    this.a.zIndex = this.zIndex
    this.a.textAlign = "center"
    this.a.fontSize = "3vw"
    this.thing.innerHTML = this.name
    document.body.appendChild(this.thing)
    var ii = document.createElement("DIV")
    ii.position = "absolute"
    ii.style.margin = "auto"
    ii.style.backgroundImage = "url(" + icon + ")"
    ii.style.backgroundSize = "calc(14.5vw / 1.75)"
    ii.style.width = "calc(14.5vw / 1.75)"
    ii.style.height = "calc(14.5vw / 1.75)"
    ii.style.zIndex = 5
    this.thing.appendChild(ii)
  }
  show() {
    this.thing.style.display = "initial"
  }
  hide() {
    this.thing.style.display = "none"
  }
}

var health = 10
var maxHealth = 10
var coins = 0
var damage
var currentWeapon = "woodSword"
var currentScreen = 2

var menuScreenObj = new screen("Menu Screen", 1, false, 50, 40, 10)
var shopObj = new menuThing("Shop", 2, "https://superfluffygame.github.io/game-assets/shopIcon.png")
var upgradeObj = new menuThing("Upgrade", 2, "https://superfluffygame.github.io/game-assets/upgrades.png")
var statObj = new menuThing("Stats", 2, "https://superfluffygame.github.io/game-assets/info.png")

var shopScreenObj = new screen("Shop", 3, true, 70, 50, 2.5)
var upScreenObj = new screen("Upgrades", 3, true, 70, 50, 2.5)
var statScreenObj = new screen("Statistics", 3, true, 70, 50, 2.5)

shopObj.a.left = "-32.5vw"
shopObj.a.top = "12vw"
upgradeObj.a.top = "12vw"
statObj.a.right = "-32.5vw"
statObj.a.top = "12vw"

var woodSword = new weapon("Wooden Sword", "https://superfluffygame.github.io/game-assets/woodSword.png", 4, 5)
var stoneSword = new weapon("Stone Sword", "https://superfluffygame.github.io/game-assets/stoneSword.png", 10, 5)
var ironSword = new weapon("Iron Sword", "https://superfluffygame.github.io/game-assets/ironSword.png", 24, 5)
var diaSword = new weapon("Diamond Sword", "https://superfluffygame.github.io/game-assets/diaSword.png", 50, 5)

window.onload = function() {
  var menuObjs = [shopObj, upgradeObj, statObj]
  menuScreen2()
  setup()
  window.addEventListener('keypress', function(e) {
    switch (e.key) {
      case "m":
        if (!e.repeat)
          if (currentScreen == 1) {
            currentScreen = 0
          } else {
            currentScreen = 1
          }
        break;
      case " ":
        if (!e.repeat)
          attack()
        setup()
        break;
    }
    menuScreen2()
  }, false);

  for (let i = 0; i < menuObjs.length; i++) {
    menuObjs[i].thing.addEventListener('mouseover', function() {
      menuObjs[i].a.background = "#DDDDDD"
    }, false)
  }

  for (let i = 0; i < menuObjs.length; i++) {
    menuObjs[i].thing.addEventListener('mouseout', function() {
      menuObjs[i].a.background = "white"
    }, false)
  }

  for (let i = 0; i < menuObjs.length; i++) {
    menuObjs[i].thing.addEventListener('mousedown', function() {
      menuObjs[i].a.background = "#BBBBBB"
    }, false)
  }

  for (let i = 0; i < menuObjs.length; i++) {
    menuObjs[i].thing.addEventListener('mouseup', function() {
      menuObjs[i].a.background = "#DDDDDD"
      switch (i) {
        default:
          currentScreen = 0
          menuScreen2()
          break;
        case 0:
          currentScreen = 2
          menuScreen2()
          break;
        case 1:
          currentScreen = 3
          menuScreen2()
          break;
        case 2:
          currentScreen = 4
          menuScreen2()
          break;
      }
    }, false)
  }
}

function attack() {
  if (health - damage > 0) {
    health = health - damage
  } else {
    coins++
    maxHealth++
    health = maxHealth
  }
}

function setup() {
  if (currentWeapon == "Hand") {
    damage = 1
  } else if (currentWeapon == "woodSword") {
    damage = 4
  } else if (currentWeapon == "stoneSword") {
    damage = 10
  } else if (currentWeapon == "ironSword") {
    damage = 16
  } else if (currentWeapon == "diaSword") {
    damage = 30
  }

  document.getElementById("healthFill").style.background = ("hsl(" + health / maxHealth * 100 + ",100%,50%)")
  document.getElementById("healthFill").style.width = 1 / (maxHealth / health) * 60 + "vw"
  document.getElementById("coins").style.fontSize = 5 + "vw"
  if (health < 0) {
    document.getElementById("health").style.top = 2 + "vw"
    document.getElementById("health").innerHTML = "DEAD"
    document.getElementById("health").style.fontSize = 3 + "vw"
  } else {
    document.getElementById("health").style.top = 1 + "vw"
    document.getElementById("health").style.fontSize = 5 + "vw"
    document.getElementById("health").innerHTML = health
  }
  document.getElementById("coins").innerHTML = "Coins: " + coins
  document.getElementById("damage").innerHTML = "Damage: " + damage
  document.getElementById("weapon").innerHTML = "Weapon: " + currentWeapon

}


function menuScreen2() {
  switch (currentScreen) {
    case 0:
      hide()
      break;
    case 1:
      hide()
      menuScreen()
      break;
    case 2:
      hide()
      shopScreen()
      break;
    case 3:
      hide()
      upScreenObj.show()
      break;
    case 4:
      hide()
      statScreenObj.show()
      break;
  }
}

function menuScreen() {
  menuScreenObj.show()
  shopObj.show()
  upgradeObj.show()
  statObj.show()
}

var moneyInShop = document.createElement("DIV")
document.body.appendChild(moneyInShop)
var moneyInShops = moneyInShop.style

var iconInShop = document.createElement("DIV")
var nameInShop = document.createElement("DIV")
var damageInShop = document.createElement("DIV")
var costInShop = document.createElement("DIV")
document.body.appendChild(iconInShop)
document.body.appendChild(nameInShop)
document.body.appendChild(damageInShop)
document.body.appendChild(costInShop)
var iconInShops = iconInShop.style
var nameInShops = nameInShop.style
var damageInShops = damageInShop.style
var costInShops = costInShop.style



function shopScreen() {
  moneyInShops.width = "40vw"
  moneyInShops.height = "20vw"
  moneyInShops.position = "absolute"
  moneyInShops.top = "4vw"
  moneyInShops.color = "#CCCC44"
  moneyInShops.fontSize = "5vw"
  moneyInShops.zIndex = 8
  moneyInShops.left = "16vw"
  moneyInShop.innerHTML = "Coins: " + coins
  moneyInShops.display = "block"
  
  iconInShops.width = "20vw"
  iconInShops.height = "20vw"
  iconInShops.position = "absolute"
  iconInShops.top = "9vw"
  iconInShops.color = "black"
  iconInShops.fontSize = "3vw"
  iconInShops.zIndex = 8
  iconInShops.left = "22vw"
  iconInShop.innerHTML = "Icon"
  iconInShops.display = "block"
  
  damageInShops.width = "20vw"
  damageInShops.height = "20vw"
  damageInShops.position = "absolute"
  damageInShops.top = "9vw"
  damageInShops.color = "black"
  damageInShops.fontSize = "3vw"
  damageInShops.zIndex = 8
  damageInShops.left = "48vw"
  damageInShop.innerHTML = "Damage"
  damageInShops.display = "block"
  
  costInShops.width = "20vw"
  costInShops.height = "20vw"
  costInShops.position = "absolute"
  costInShops.top = "9vw"
  costInShops.color = "black"
  costInShops.fontSize = "3vw"
  costInShops.zIndex = 8
  costInShops.left = "62vw"
  costInShop.innerHTML = "Cost"
  costInShops.display = "block"
  
  nameInShops.width = "20vw"
  nameInShops.height = "20vw"
  nameInShops.position = "absolute"
  nameInShops.top = "9vw"
  nameInShops.color = "black"
  nameInShops.fontSize = "3vw"
  nameInShops.zIndex = 8
  nameInShops.left = "34vw"
  nameInShop.innerHTML = "Name"
  nameInShops.display = "block"
  
  shopScreenObj.show()
  woodSword.shopDraw(14)
  stoneSword.shopDraw(22)
  ironSword.shopDraw(30)
  diaSword.shopDraw(38)
}

function hide() {
  menuScreenObj.hide()
  shopObj.hide()
  upgradeObj.hide()
  statObj.hide()

  shopScreenObj.hide()
  upScreenObj.hide()
  statScreenObj.hide()

  woodSword.hide()
  ironSword.hide()
  stoneSword.hide()
  diaSword.hide()
  moneyInShops.display = "none"
  iconInShops.display = "none"
  damageInShops.display = "none"
  nameInShops.display = "none"
  costInShops.display = "none"
}