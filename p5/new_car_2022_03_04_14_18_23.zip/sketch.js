let playerCar
function setup() {
  createCanvas(400, 400);
  playerCar = new Car(300,300,25,40,180)
  rectMode(CENTER)
  strokeWeight(2)
  noFill()
}

function draw() {
  background(220);
  stroke('black')
  playerCar.show()
  stroke('red')
  //line(0,height/2,width,height/2)
  //line(width/2,0,width/2,height)


}
function rotRect(x,y,sx,sy,angle){
  push()
  translate(x,y)
  rotate(angle)
  rect(0,0,sx,sy)
  pop()
}
class Car{
  constructor(x,y,sx,sy,angle){
    this.pos = createVector(x,y)
    this.vel = createVector(0,0)
    this.acc = createVector(0,0)
    this.size = createVector(sx,sy)
    this.angle = angle
  }
  show(){
    this.move()
    rotRect(this.pos.x,this.pos.y,this.size.x,this.size.y,this.angle)
    point(this.pos.x+sin(-this.angle)*15,this.pos.y+cos(-this.angle)*15)
  }
  move(){
    if(keyIsDown(87)){
      let t = createVector(sin(-this.angle),cos(-this.angle))
      t.normalize()
      t.mult(0.5)
      this.acc.add(t)
    }
    if(keyIsDown(83)){
      let t = createVector(sin(-this.angle),cos(-this.angle))
      t.normalize()
      t.mult(-0.5)
      this.acc.add(t)
    }
    if(keyIsDown(68) && this.vel.mag() >= 2){
      this.angle += radians(3)
    }
    if(keyIsDown(65) && this.vel.mag() >= 2){
      this.angle -= radians(3)
    }
    let c = 0.25
    this.friction = this.vel
    this.friction.mult(-1);
    this.friction.normalize();
    this.friction.mult(c);
    
    this.acc.add(this.friction)
    if(this.acc.mag() > 5){
      this.acc.normalize()
      this.acc.mult(4)
    }

    this.vel.add(this.acc)
    if(abs(this.vel.x) <= c){
      this.vel.x = 0
    }
    if(abs(this.vel.y) <= c){
      this.vel.y = 0
    }
    if(this.vel.mag() > 5){
      this.vel.normalize()
      this.vel.mult(5)
    }
    this.pos.add(this.vel)
  }
}
// function rotatedRect(x,y,sx,sy,angle){
//   //rect(x,y,sx,sy)
//   line(x+   sin(angle+radians(90))*sx/2-sin(angle)*sx/2,
//        y-sy+cos(angle+radians(90))*sy/2-cos(angle)*sy/2+sy,
//        x-   sin(angle+radians(90))*sx/2-sin(angle)*sx/2,
//        y-sy-cos(angle+radians(90))*sy/2-cos(angle)*sy/2+sy)
//   line(x-sx+sin(angle)*sx/2+sin(angle+radians(90))*sx/2+sx,
//        y+   cos(angle)*sy/2+cos(angle+radians(90))*sy/2,
//        x-sx-sin(angle)*sx/2+sin(angle+radians(90))*sx/2+sx,
//        y-   cos(angle)*sy/2+cos(angle+radians(90))*sy/2)  
//   line(x+   sin(angle+radians(90))*sx/2+sin(angle)*sx/2,
//        y+sy+cos(angle+radians(90))*sy/2+cos(angle)*sy/2-sy,
//        x-   sin(angle+radians(90))*sx/2+sin(angle)*sx/2,
//        y+sy-cos(angle+radians(90))*sy/2+cos(angle)*sy/2-sy)  
//   line(x+sx+sin(angle)*sx/2-sin(angle+radians(90))*sx/2-sx,
//        y+   cos(angle)*sy/2-cos(angle+radians(90))*sy/2,
//        x+sx-sin(angle)*sx/2-sin(angle+radians(90))*sx/2-sx,
//        y-   cos(angle)*sy/2-cos(angle+radians(90))*sy/2)  
// }