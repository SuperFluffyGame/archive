let particles = []
function setup() {
  createCanvas(400, 400);
  angleMode(DEGREES)
}

function draw() {
  background('#FF6633');
  strokeWeight(4)
  particles.forEach((particle,index,arr) => {
    particle.updatePos(arr,index)
    particle.show()
  })
  noStroke()
  text(round(frameRate()),50,50)
  text(particles.length,100,50)
  createParticleBatch(mouseX,mouseY)
}
function mousePressed(){
  createParticleBatch(mouseX,mouseY)
}
function createParticleBatch(x,y){
  for(let i = 0; i < 45; i++){
    particles.push(new Particle(mouseX,mouseY,i*8+random(-50,50),random(2,3)))
  }
}
class Particle{
  constructor(x,y,angle,speed=1){
    this.x = x
    this.y = y
    this.angle = angle
    this.speed = speed
    this.lifetimeMax = 75
    this.lifetime = this.lifetimeMax
  }
  show(){
    stroke(0,map(this.lifetime,0,this.lifetimeMax,0,255))
    point(this.x,this.y)
  }
  updatePos(array,index){
    this.lifetime -= random(0,3)
    this.x += cos(this.angle)*this.speed
    this.y += sin(this.angle)*this.speed
  }
}