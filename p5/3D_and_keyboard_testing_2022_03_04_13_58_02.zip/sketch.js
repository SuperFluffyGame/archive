let cam

function setup() {
  createCanvas(400, 400, WEBGL);
  cam = createCamera()
  noCursor()
  smooth()
  specularMaterial(0,0,255)
}

function draw() {
  background(220);
  smooth()
  pointLight(200,200,255,250,250,250)
  pointLight(0,255,100,-250,-250,-250)
  box(100)
  cam.lookAt((sin(-mouseX/100))+cam.eyeX,(sin(-mouseY/100))+cam.eyeY,(cos(-mouseX/100))+cam.eyeZ)
  if (keyIsPressed && keyCode === 68) {
    cam.move(1, 0, 0)
  }
  if (keyIsPressed && keyCode === 65) {
    cam.move(-1, 0, 0)
  }
  if (keyIsPressed && keyCode === 87) {
    cam.move(0, 0, -1)
  }
  if (keyIsPressed && keyCode === 83) {
    cam.move(0, 0, 1)
  }
  if (keyIsPressed && keyCode === 32) {
    cam.move(0, -1, 0)
  }
  if (keyIsPressed && keyCode === 16) {
    cam.move(0, 1, 0)
  }
}
 function keyPressed() {
   if (mouseX > 0 && mouseX < width && mouseY > 0 && mouseY < height && keyCode === 70) {
    let fs = fullscreen();
     fullscreen(!fs);
     if(!fs){
       resizeCanvas(displayWidth,displayHeight)
     }
   }
}