let vsSource = `
attribute vec4 aPosition;
attribute vec4 aColor;
attribute lowp float aRot;

varying lowp vec4 vColor;

void main(){
  lowp vec4 newPos = vec4(aPosition.x,aPosition.y,1,1);
  newPos.x = aPosition.x * cos(aRot) - aPosition.y * sin(aRot);
  newPos.y = aPosition.x * sin(aRot) + aPosition.y * cos(aRot);
  gl_Position = newPos;
  vColor = aColor;
}
`

let fsSource = `
varying lowp vec4 vColor;
void main(){
  gl_FragColor = vColor;
}
`