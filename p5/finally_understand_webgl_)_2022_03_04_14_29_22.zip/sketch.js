let gl = document.getElementById("can").getContext("webgl")
window.onload = main


function main(){
  myScene = new Scene(gl)
  myScene.createTriangle2D([
    0,0,
    0,1,
    1,1
  ],[1,1,0,1])
  
  
  myScene.render()

  
  requestAnimationFrame(main)
}

function clear(gl,r,g,b,a){
  gl.clearColor(r,g,b,a)
  gl.clear(gl.COLOR_BUFFER_BIT)
}