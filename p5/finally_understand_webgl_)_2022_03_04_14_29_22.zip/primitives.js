class Scene{
  constructor(gl){
    this.gl = gl
  }
  clear(r,g,b,a){
    this.gl.clearColor(r,g,b,a)
    this.gl.clear(gl.COLOR_BUFFER_BIT)
  }
  render(){
    this.clear()
    let program = initShaderProgram(gl,vsSource,fsSource)

    let programInfo = {
      aLocations: {
        Position: gl.getAttribLocation(program,"aPosition"),
        Color: gl.getAttribLocation(program,"aColor"),
        Rot: gl.getAttribLocation(program,"aRot")

      }
    }
    let rot = Array(5).fill(0)

    createBuffer(gl,this.allGeo,programInfo.aLocations.Position,{
      num: 3
    })
    createBuffer(gl,this.allColor,programInfo.aLocations.Color,{
      num: 4
    })
    createBuffer(gl,rot,programInfo.aLocations.Rot,{
      num: 1
    })


    gl.useProgram(program)

    gl.drawArrays(gl.TRIANGLES,0,this.allGeo.length/3)
  }
}