let m = {
  x: 0,
  y: 0
}
document.addEventListener('mousemove',(e)=>{
  m.x = (e.x-250)/240
  m.y = -(e.y-250)/240
})