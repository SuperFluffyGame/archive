let square1
let zRot, yRot
function setup() {
  createCanvas(400, 400);
  square1  = [createVector( 100, 100,  100),
              createVector(-100, 100,  100),
              createVector(-100, -100, -100),
              createVector( 100, -100, -100)]
  strokeWeight(5)
  zRot = radians(90)
  yRot = radians(0)
}

function draw() {
  translate(width/2,height/2)
  background(220);
  for(let i = 0; i < square1.length; i++){
    vpoint(iso(square1[i]))
  }
}
function iso(vector){
  return createVector(vector.x*sin(zRot),vector.y*cos(yRot))
}
function vpoint(vector){
  point(vector.x,vector.y)
}