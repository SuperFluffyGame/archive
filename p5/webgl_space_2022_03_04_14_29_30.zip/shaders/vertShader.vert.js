const vs = 
`
attribute vec4 aPos;

void main(){
  gl_Position = aPos;
}
`