const fs = `
uniform lowp vec4 starPos;

lowp float square(lowp float a){
  return a*a;
}

void main(){
  lowp vec4 color = vec4(0.0,0.0,0.0,1.0);

  // for(int i = 0; i < 1; i++){
  //   if(
  //     sqrt(square((gl_FragCoord.x/400.0) - starPos[i].x) + 
  //          square((gl_FragCoord.y/400.0) - starPos[i].y)) < 0.1){
  //     color = vec4(1.0,1.0,1.0,1.0);
  //   }
  // }

  gl_FragColor = starPos;
}
`