let canvas = document.getElementById("can")
let gl = canvas.getContext("webgl2")

function main(){
  gl.clearColor(0,0,0,1)
  gl.clear(gl.COLOR_BUFFER_BIT)
  
  
  let points = [-1,-1,1,-1,1,1,-1,-1,-1,1,1,1]
  let shader = initShaderProgram(gl,vs,fs)
  
  
  let stars=[
    1.0,0.5,1,1
  ]
  
  createBuffer(gl,points,gl.getAttribLocation(shader,"aPos"))
  gl.uniform4fv(gl.getUniformLocation(shader,"starPos"),stars)
  
  gl.useProgram(shader)
  
  gl.drawArrays(gl.TRIANGLES,0,6)
}
main()