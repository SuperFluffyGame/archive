import * as PIXI from "/modules/pixi.min.js";
let BUMP = new Bump(PIXI);

//PIXI.settings.RESOLUTION = window.devicePixelRatio;
PIXI.settings.SCALE_MODE = PIXI.SCALE_MODES.NEAREST;
PIXI.settings.ROUND_PIXELS = true

//Creating aliases
let loader = PIXI.Loader.shared;
let resources = loader.resources;
let Sprite = PIXI.Sprite;
let Text = PIXI.Text;
let TextStyle = PIXI.TextStyle;
let Graphics = PIXI.Graphics;
let globalGraphics = new Graphics()

//starting functions
requestAnimationFrame(setConstants);
requestAnimationFrame(resizeRenderer);

//Creating the pixi app
let app = new PIXI.Application();
document.body.appendChild(app.view);
app.renderer.view.style.position = "absolute";
app.renderer.view.style.display = "block";
app.renderer.autoResize = true;
app.renderer.backgroundColor = 0x3ab1cf;

//Loading the images and text
loader
  .add("commonCrateIMG", "/textures/common-crate.png")
  .add("uncommonCrateIMG", "/textures/uncommon-crate.png")
  .add("rareCrateIMG", "/textures/rare-crate.png")
  .add("epicCrateIMG", "/textures/epic-crate.png")
  .add("legendaryCrateIMG", "/textures/legendary-crate.png")
  .add("mythicCrateIMG", "/textures/mythic-crate.png")
  .add("menuIcon", "/textures/menuIcon2.png")
  .load(setup);

//Setting the constants
let width, height, mouseX, mouseY;
document.body.addEventListener("mousemove", function (event) {
  mouseX = event.pageX;
  mouseY = event.pageY;
});
function setConstants() {
  width = window.innerWidth;
  height = window.innerHeight;
  requestAnimationFrame(setConstants);
}

function resizeRenderer() {
  app.renderer.resize(width, height);
  requestAnimationFrame(resizeRenderer);
}

//custom key checker (didnt create myself)
function keyboard(value) {
  let key = {};
  key.value = value;
  key.isDown = false;
  key.isUp = true;
  key.press = undefined;
  key.release = undefined;
  //The `downHandler`
  key.downHandler = (event) => {
    if (event.key === key.value) {
      if (key.isUp && key.press) key.press();
      key.isDown = true;
      key.isUp = false;
      event.preventDefault();
    }
  };

  //The `upHandler`
  key.upHandler = (event) => {
    if (event.key === key.value) {
      if (key.isDown && key.release) key.release();
      key.isDown = false;
      key.isUp = true;
      event.preventDefault();
    }
  };

  //Attach event listeners
  const downListener = key.downHandler.bind(key);
  const upListener = key.upHandler.bind(key);

  window.addEventListener("keydown", downListener, false);
  window.addEventListener("keyup", upListener, false);

  // Detach event listeners
  key.unsubscribe = () => {
    window.removeEventListener("keydown", downListener);
    window.removeEventListener("keyup", upListener);
  };

  return key;
}
//custom round function (didnt create myself)
function roundTo(n, digits) {
  var negative = false;
  if (digits === undefined) {
    digits = 0;
  }
  if (n < 0) {
    negative = true;
    n = n * -1;
  }
  var multiplicator = Math.pow(10, digits);
  n = parseFloat((n * multiplicator).toFixed(11));
  n = (Math.round(n) / multiplicator).toFixed(digits);
  if (negative) {
    n = (n * -1).toFixed(digits);
  }
  return n;
}

function randomInt(min, max) {
  min = Math.ceil(min);
  max = Math.floor(max);
  return Math.round(Math.random() * (max - min) + min);
}

///
/// MAIN FUNCTIONS
///

let uiScale = 1;
let crate;
let GAME = {};

let common = { minCoins: 1, maxCoins: 3, chance: 75, health: 2};
let uncommon = { minCoins: 2, maxCoins: 10, chance: 15 + common.chance, health: 5 };
let rare = { minCoins: 5, maxCoins: 24, chance: 6 + uncommon.chance, health: 10 };
let epic = { minCoins: 12, maxCoins: 32, chance: 3 + rare.chance, health: 15 };
let legendary = { minCoins: 36, maxCoins: 96, chance: 0.9 + epic.chance, health: 25 };
let mythic = { minCoins: 128, maxCoins: 512, chance: 0.1 + legendary.chance, health: 40};

let coinsTxt, menuIconSprite, menuTxt;
let mainMenuScreen, noScreen


let settings = {autosave: 1}
function setup() {
  loadgame()
  setInterval(savegame,30*1000)
  coinsTxt = new Text(GAME.coins, { fill: "black"});
  randomCrate();
  
  mainMenuScreen = new MenuScreen(width/2,0,width/2,height)
  noScreen = new MenuScreen(0,0,0,0)
  currentScreen = noScreen

  // menuIconSprite = new Sprite(resources.menuIcon.texture);
  // app.stage.addChild(menuIconSprite);
  // menuIconSprite.scale.set(Math.round(Math.min(width, height) / 400));
  // menuIconSprite.position.set(width - menuIconSprite.width, 0);

//   menuTxt = new Text("[E]", {
//     fill: "yellow",
//     stroke: "black",
//     strokeThickness: 5,
//   });
//   menuTxt.position.set(
//     menuIconSprite.x + menuIconSprite.width / 2 - menuTxt.width / 2,
//     menuIconSprite.y + menuIconSprite.height - menuTxt.height / 4
//   );
//   app.stage.addChild(menuTxt);

  app.stage.addChild(globalGraphics)
  app.stage.addChild(coinsTxt);

  requestAnimationFrame(reposition);
  requestAnimationFrame(main);
  
  
  
  document.body.addEventListener("click", function () {
    if(currentScreen == noScreen)
    if (BUMP.hitTestPoint({ x: mouseX, y: mouseY }, crate.sprite)) {
      if (crate.HP - 1 > 0) {
        crate.HP--;
      } else {
        crate.destroy();
      }
    }
  });
  document.body.addEventListener("mousemove", function () {
    document.body.style.cursor = 'default'
    if(currentScreen == noScreen)
    if (BUMP.hitTestPoint({ x: mouseX, y: mouseY }, crate.sprite)) {
      document.body.style.cursor = 'pointer'
    }
  })
  document.body.addEventListener("mousedown", function () {
    if(currentScreen == noScreen)
    if (BUMP.hitTestPoint({ x: mouseX, y: mouseY }, crate.sprite)) {
      crate.clickScale = 0.5
    }
  })
  document.body.addEventListener("mouseup", function(){
      crate.clickScale = 0
  })
  
  document.body.addEventListener("keypress", function(event){
    let key = event.key
    
 
  })
}


function reposition() {
  crate.sprite.position.set(width/2,height/2)
  crate.sprite.scale.set(Math.round(Math.min(width, height) / 100)- crate.clickScale)
  
//   menuIconSprite.position.set(width - menuIconSprite.width, 0);
//   menuIconSprite.scale.set(2);
  
//   menuTxt.position.set(
//     menuIconSprite.x + menuIconSprite.width / 2 - menuTxt.width / 2,
//     menuIconSprite.y + menuIconSprite.height - menuTxt.height / 4
//   );
  
  mainMenuScreen.x = width/3 * 2
  mainMenuScreen.y = 0
  mainMenuScreen.sx = width/3
  mainMenuScreen.sy = height
  mainMenuScreen.color = 0x3a6bcf
  
  requestAnimationFrame(reposition);
}
let currentScreen
function main() {
  
  coinsTxt.text = "Coins: " + GAME.coins;
  coinsTxt.position.set(width/2-195,0)
  mainMenuScreen.show()
  crate.draw()
  globalGraphics.clear()
  globalGraphics.beginFill(0xFFFFFF)
  globalGraphics.lineStyle('black')
  globalGraphics.lineStyle({width: 3, color: 0x000000})
  globalGraphics.drawRect(width/2-200,0,400,75)
  globalGraphics.endFill()
  globalGraphics.moveTo(width/3,0)
  globalGraphics.lineTo(width/3,height)
  requestAnimationFrame(main);
}

let chance;

function randomCrate() {
  if (crate != undefined) {
    crate.sprite.destroy();
  }
  chance = roundTo(Math.random() * 100, 2);
  if (chance <= common.chance) {
    crate = new Crate(common);
    crate.setHP(common.health, common.health, "top");
  } else if (chance > common.chance && chance <= uncommon.chance) {
    crate = new Crate(uncommon);
    crate.setHP(uncommon.health, uncommon.health, "top");
  } else if (chance > uncommon.chance && chance <= rare.chance) {
    crate = new Crate(rare);
    crate.setHP(rare.health, rare.health, "top");
  } else if (chance > rare.chance && chance <= epic.chance) {
    crate = new Crate(epic);
    crate.setHP(epic.health, epic.health, "top");
  } else if (chance > epic.chance && chance <= legendary.chance) {
    crate = new Crate(legendary);
    crate.setHP(legendary.health, legendary.health, "top");
  } else if (chance > legendary.chance && chance <= mythic.chance) {
    crate = new Crate(mythic);
    crate.setHP(mythic.health, mythic.health, "top");
  }
  crate.sprite.position.set(width/2,height/2)
  crate.sprite.scale.set(Math.round(Math.min(width, height) / 100)- crate.clickScale)
}
function loadgame(){
  console.log('load')
  if(localStorage.getItem('GAME') != undefined){
    console.log('loaded GAME')
    GAME = atob(localStorage.getItem('GAME'))
  }else{
    GAME = {coins: 0}
  }
}
function savegame(){
  if(settings.autosave == 1){
    localStorage.setItem("GAME",btoa(GAME))
    console.log(localStorage.getItem("GAME"))
  }
}

//====================
// END MAIN FUNCTIONS
//====================

let thisCoinText;
let thisCoinTextThing = 0;

class Crate {
  constructor(rarity) {
    let texture;
    this.clickScale = 0
    this.rarity = rarity;
    if (this.rarity == common) {
      texture = resources.commonCrateIMG.texture;
    } else if (this.rarity == uncommon) {
      texture = resources.uncommonCrateIMG.texture;
    } else if (this.rarity == rare) {
      texture = resources.rareCrateIMG.texture;
    } else if (this.rarity == epic) {
      texture = resources.epicCrateIMG.texture;
    } else if (this.rarity == legendary) {
      texture = resources.legendaryCrateIMG.texture;
    } else if (this.rarity == mythic) {
      texture = resources.mythicCrateIMG.texture;
    } else {
      console.error("Rarity not valid or something went wrong.");
    }
    this.sprite = new Sprite(texture);
    this.sprite.anchor.set(0.5, 0.5);
    app.stage.addChild(this.sprite);
    this.sprite.scale.set(4)
    this.sprite.position.set(width/2,height/2)
    

    this.graphics = new Graphics();
    app.stage.addChild(this.graphics);
  }
  setHP() {
    this.HP = arguments[0];
    this.maxHP = arguments[1];
    this.HPbarPosition = arguments[2];
  }
  draw() {

    this.graphics.clear();

    if (this.HPbarPosition == "top") {
      this.graphics.beginFill(0x000000, 0);
      this.graphics.lineStyle(2, 0xffffff, 1);
      this.graphics.drawRect(
        this.sprite.x - this.sprite.scale.x * 10,
        this.sprite.y - this.sprite.scale.x * 15,
        this.sprite.scale.x * 20,
        this.sprite.scale.y * 2
      );

      this.graphics.beginFill(0x00ff00);
      this.graphics.lineStyle(0);
      this.graphics.drawRect(
        this.sprite.x - this.sprite.scale.x * 10,
        this.sprite.y - this.sprite.scale.x * 15,
        (this.HP / this.maxHP) * this.sprite.scale.x * 20,
        this.sprite.scale.y * 2
      );
    }
    this.graphics.endFill();
  }
  destroy() {
    let coinIncrease;
    coinIncrease = randomInt(this.rarity.minCoins, this.rarity.maxCoins);
    GAME.coins += coinIncrease;

    this.floatingText = new floatingText(
      this.sprite.x,
      this.sprite.y,
      "+" + coinIncrease
    );
    this.floatingText.draw({ fill: "#fcd61c" });

    this.graphics.clear();
    randomCrate();
  }
}
class floatingText {
  constructor(x, y, text) {
    this.x = x;
    this.y = y;
    this.text = text;
    this.floating = 0;
    this.maxFloat = 75;
  }
  draw(style) {
    this.textObject = new Text(this.text, this.style);
    this.textObject.style = style;
    this.textObject.position.set(
      this.x - this.textObject.width / 2,
      this.y - 120
    );
    app.stage.addChild(this.textObject);
    this.float();
  }
  float() {
    if (this.floating < this.maxFloat) {
      this.floating++;
      this.textObject.y--;
      requestAnimationFrame(this.float.bind(this));
    } else {
      app.stage.removeChild(this.textObject);
    }
  }
}

class MenuScreen {
  constructor(x,y,sx,sy){
    this.x = x
    this.y = y
    this.sx = sx
    this.sy = sy
    this.color = 0xFFFFFF
    this.lineWidth = 3
    this.graphics = new Graphics()
    app.stage.addChild(this.graphics)
  }
  show(){
    this.graphics.clear()
    this.graphics.beginFill(this.color)
    this.graphics.lineStyle({width: this.lineWidth})
    this.graphics.drawRoundedRect(this.x,this.y,this.sx,this.sy,0)
    this.graphics.endFill()
  }
}