let dot1, dot2, dot3, dot4
let mRot, rot
function setup() {
  createCanvas(400, 400);
  rot = radians(0)
  dot1 = create2dMatrix(25,25)
  dot2 = create2dMatrix(-25,25)
  dot3 = create2dMatrix(-25,-25)
  dot4 = create2dMatrix(25,-25)
  
  mRot = new Matrix("2d",
                    [[ cos(rot), -sin(rot) ],
                    [  sin(rot),  cos(rot) ]])
  


  strokeWeight(5)

}
function draw() {
  background(220);
  translate(width/2,height/2)
  
  mRot.content = [[ cos(rot), -sin(rot) ],
                 [  sin(rot),  cos(rot) ]]
  
  
  td1 = matrixMult(dot1,mRot)
  td2 = matrixMult(dot2,mRot)
  td3 = matrixMult(dot3,mRot)
  td4 = matrixMult(dot4,mRot)

  mPoint2d(td1)
  mPoint2d(td2)
  mPoint2d(td3)
  mPoint2d(td4)
  rot = mouseX/100
}
class Matrix{
  constructor(type,contentArray){
    this.content = contentArray
    this.dimensions = [this.content.length,this.content[0].length]
    this.type = type
  }
  setContent(content){
    this.content = content
    this.mHeight = this.content.length
    this.mWidth = this.content[0].length
  }
  mult(matrix){
  let out = [];
  if (this.dimensions[1] == matrix.dimensions[0]) {
    for(let z = 0; z < this.dimensions[0]; z++){
      out.push([0])
      for(let y = 0; y < matrix.dimensions[1]; y++){
        out[z][y] = 0
      }
    }
    for (let i = 0; i < this.dimensions[0]; i++) {
      for (let j = 0; j < matrix.dimensions[1]; j++) {
        for (let k = 0; k < this.dimensions[1]; k++) {
          out[i][j] += this.content[i][k] * matrix.content[k][j];
        }
      }
    }
    this.content = out
  } else {
    console.error("Matrices cannot be multiplied");
  }
  }
}
function matrixAdd(m1, m2) {
  if (m1.dimensions[0] == m2.dimensions[0] && m1.dimensions[1] == m2.dimensions[1]) {
    let out = [];
    for (let i = 0; i < m1.dimensions[0]; i++) {
      out.push([]);
      for (let j = 0; j < m1.dimensions[1]; j++) {
        out[i][j] = m1.content[i][j] + m2.content[i][j];
      }
    }
    let out2 = new Matrix(out);
    return out2;
  } else {
    console.error("Matrix diminsions not the same, impossible");
  }
}
function matrixMult(m1, m2) {
  let out = [];
  if (m1.dimensions[1] == m2.dimensions[0]) {
    for(let z = 0; z < m1.dimensions[0]; z++){
      out.push([0])
      for(let y = 0; y < m2.dimensions[1]; y++){
        out[z][y] = 0
      }
    }
    for (let i = 0; i < m1.dimensions[0]; i++) {
      for (let j = 0; j < m2.dimensions[1]; j++) {
        for (let k = 0; k < m1.dimensions[1]; k++) {
          out[i][j] += m1.content[i][k] * m2.content[k][j];
        }
      }
    }
    let type = m1.type
    out2 = new Matrix(type,out);
    return out2;
  } else {
    console.error("Matrices cannot be multiplied");
  }
}
function create2dMatrix(x,y){
  return new Matrix("2d",[[x,y]])
}
function mPoint2d(matrix){
    point(matrix.content[0][0],matrix.content[0][1])
}