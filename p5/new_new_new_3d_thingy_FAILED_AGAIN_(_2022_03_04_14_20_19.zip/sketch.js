let dot1,dot2,dot3,dot4,dot5,dot6,dot7,dot8
let cube
let mcamera
function setup() {
  createCanvas(400, 400);

  mcamera = new Camera(create3dMatrix(0,0,0,1),0)
  
  dot1 = new dot3d(create3dMatrix( 25, 25, 25,1),mcamera)
  dot2 = new dot3d(create3dMatrix( 25, 25,-25,1),mcamera)
  dot3 = new dot3d(create3dMatrix( 25,-25, 25,1),mcamera)
  dot4 = new dot3d(create3dMatrix( 25,-25,-25,1),mcamera)
  dot5 = new dot3d(create3dMatrix(-25, 25, 25,1),mcamera)
  dot6 = new dot3d(create3dMatrix(-25, 25,-25,1),mcamera)
  dot7 = new dot3d(create3dMatrix(-25,-25, 25,1),mcamera)
  dot8 = new dot3d(create3dMatrix(-25,-25,-25,1),mcamera)


  cube = [dot1,dot2,dot3,dot4,dot5,dot6,dot7,dot8]
  
  
  frameRate(144)
  strokeWeight(4)
}

function draw() {
  background(220)
  translate(width/2,height/2)
  if(keyIsDown(65)){
      mcamera.truetranslate(-1,0,0)
  }
  if(keyIsDown(68)){
    mcamera.truetranslate(1,0,0)
  }
  mcamera.rotation = mouseX
  for(let i = 0; i < cube.length; i++){
    cube[i].orthoShow()
  }
}
class Matrix{
  constructor(type,contentArray){
    this.content = contentArray
    this.dimensions = [this.content.length,this.content[0].length]
    this.type = type
  }
  setContent(content){
    this.content = content
    this.mHeight = this.content.length
    this.mWidth = this.content[0].length
  }
  mult(matrix){
    let out = [];
    if (this.dimensions[1] == matrix.dimensions[0]) {
      for(let z = 0; z < this.dimensions[0]; z++){
        out.push([0])
        for(let y = 0; y < matrix.dimensions[1]; y++){
          out[z][y] = 0
        }
      }
      for (let i = 0; i < this.dimensions[0]; i++) {
        for (let j = 0; j < matrix.dimensions[1]; j++) {
          for (let k = 0; k < this.dimensions[1]; k++) {
            out[i][j] += this.content[i][k] * matrix.content[k][j];
          }
        }
      }
      this.content = out
    } else {
      console.error("Matrices cannot be multiplied");
    }
  }
  add(matrix){
    if (this.dimensions[0] == matrix.dimensions[0] && this.dimensions[1] == matrix.dimensions[1]) {
      let out = [];
      for (let i = 0; i < matrix.dimensions[0]; i++) {
        out.push([]);
        for (let j = 0; j < matrix.dimensions[1]; j++) {
          out[i][j] = matrix.content[i][j] + matrix.content[i][j];
        }
      }
      let type = this.type
      let out2 = new Matrix(type,out);
      return out2;
    } else {
      console.error("Matrix diminsions not the same, impossible");
    }
  }
}
function matrixAdd(m1, m2) {
  if (m1.dimensions[0] == m2.dimensions[0] && m1.dimensions[1] == m2.dimensions[1]) {
    let out = [];
    for (let i = 0; i < m1.dimensions[0]; i++) {
      out.push([]);
      for (let j = 0; j < m1.dimensions[1]; j++) {
        out[i][j] = m1.content[i][j] + m2.content[i][j];
      }
    }
    let type = m1.type
    let out2 = new Matrix(type,out);
    return out2;
  } else {
    console.error("Matrix diminsions not the same, impossible");
  }
}
function matrixMult(m1, m2) {
  let out = [];
  if (m1.dimensions[1] == m2.dimensions[0]) {
    for(let z = 0; z < m1.dimensions[0]; z++){
      out.push([0])
      for(let y = 0; y < m2.dimensions[1]; y++){
        out[z][y] = 0
      }
    }
    for (let i = 0; i < m1.dimensions[0]; i++) {
      for (let j = 0; j < m2.dimensions[1]; j++) {
        for (let k = 0; k < m1.dimensions[1]; k++) {
          out[i][j] += m1.content[i][k] * m2.content[k][j];
        }
      }
    }
    let type = m1.type
    out2 = new Matrix(type,out);
    return out2;
  } else {
    console.error("Matrices cannot be multiplied");
  }
}
function create3dMatrix(x,y,z,w){
  return new Matrix("3d",[[x,y,z,w]])
}
function mPoint2d(matrix){
  point(matrix.content[0][0],matrix.content[0][1])
}
function consoleMatrix(matrix){
  for(let i = 0; i < matrix.dimensions[0]; i++){
    console.log(matrix.content[i])
  }
}
class dot3d{
  constructor(position,camera){
    this.camera = camera
    this.truePos = position
    this.transPos = position
    this.screenPos = new Matrix("2d",[[this.transPos.content[0][0],
                                       this.transPos.content[0][1]]])
  }
  orthoShow(){
    this.screenPos = new Matrix("2d",[[this.transPos.content[0][0]-
                                       this.camera.truePos.content[0][0],
                                       this.transPos.content[0][1]-
                                       this.camera.truePos.content[0][1]]])
    mPoint2d(this.screenPos)
  }
  truerotateX(angle){
    let rangle = radians(angle)
    let rotXMatrix = new Matrix("rot",[[1,0,0,0],
                                   [0,cos(rangle),-sin(rangle),0],
                                   [0,sin(rangle), cos(rangle),0],
                                   [0,0,0,1]])
    this.truePos.mult(rotXMatrix)
  }
  truerotateY(angle){
    let rangle = radians(angle)
    let rotXMatrix = new Matrix("rot",[[cos(rangle),0,sin(rangle),0],
                                       [0,1,0,0],
                                       [-sin(rangle),0, cos(rangle),0],
                                       [0,0,0,1]])
    this.truePos.mult(rotXMatrix)
  }
  truetranslate(x,y,z){
    this.pTranslate = [x,y,z]
    let translateMatrix = new Matrix("move",[[1,0,0,0],
                                             [0,1,0,0],
                                             [0,0,1,0],
                                             [x,y,z,1]])
    this.truePos.mult(translateMatrix)
  }
}
class Camera{
  constructor(position,rot){
    this.rotation = rot
    this.truePos = position
    this.transPos = position
    this.screenPos = new Matrix("2d",[[this.transPos.content[0][0],
                                       this.transPos.content[0][1]]])
  }

  truerotateX(angle){
    let rangle = radians(angle)
    let rotXMatrix = new Matrix("rot",[[1,0,0,0],
                                   [0,cos(rangle),-sin(rangle),0],
                                   [0,sin(rangle), cos(rangle),0],
                                   [0,0,0,1]])
    this.truePos.mult(rotXMatrix)
  }
  truerotateY(angle){
    let rangle = radians(angle)
    let rotXMatrix = new Matrix("rot",[[cos(rangle),0,sin(rangle),0],
                                       [0,1,0,0],
                                       [-sin(rangle),0, cos(rangle),0],
                                       [0,0,0,1]])
    this.truePos.mult(rotXMatrix)
  }
  truetranslate(x,y,z){
    this.pTranslate = [x,y,z]
    let translateMatrix = new Matrix("move",[[1,0,0,0],
                                             [0,1,0,0],
                                             [0,0,1,0],
                                             [x,y,z,1]])
    this.truePos.mult(translateMatrix)
  }
}