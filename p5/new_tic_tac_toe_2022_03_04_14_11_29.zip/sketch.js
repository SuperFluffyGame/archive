var s1,s2,s3,s4,s5,s6,s7,s8,s9
var s = [s1,s2,s3,s4,s5,s6,s7,s8,s9]
function setup() {
  createCanvas(400, 400);
  for(let i = 0; i < s.length; i++){
    s[i] = createButton('⠀')
    s[i].id(i)
    s[i].style("background: white; border: 0px solid black")
  }
}

function draw() {
  background('white');
  s[0].style('border-bottom: 5px solid; border-right: 5px solid;')
      .position(50,50)
      .size(100,100)
  s[1].style('border-bottom: 5px solid; border-right: 5px solid; border-left: 5px solid')
      .position(150,50)
      .size(100,100)
  s[2].style('border-bottom: 5px solid; border-left: 5px solid;')
      .position(250,50)
      .size(100,100)
  s[3].style('border-top: 5px solid; border-right: 5px solid; border-bottom: 5px solid')
      .position(50,150)
      .size(100,100)
  s[4].style('border-top: 5px solid; border-right: 5px solid; border-left: 5px solid; border-bottom: 5px solid')
      .position(150,150)
      .size(100,100)
  s[5].style('border-top: 5px solid; border-left: 5px solid; border-bottom: 5px solid')
      .position(250,150)
      .size(100,100)
  s[6].style('border-top: 5px solid; border-right: 5px solid;')
      .position(50,250)
      .size(100,100)
  s[7].style('border-top: 5px solid; border-right: 5px solid; border-left: 5px solid')
      .position(150,250)
      .size(100,100)
  s[8].style('border-top: 5px solid; border-left: 5px solid;')
      .position(250,250)
      .size(100,100)
  for(let i = 0; i < s.length; i++){
    s[i].mouseClicked(mset)
    s[i].label = s[i].myVar
  }
}
function mset(){
  this.myVar = this.id
}