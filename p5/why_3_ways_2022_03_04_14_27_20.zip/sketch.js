//Function 1
function type1(x){
  return x * x
}
//Function 2
const type2 = function(x){
  return x * x
}
//Function 3
const type3 = x => x*x

//Class 1
class Class1{
  square(x){
    return x*x
  }
}

//Class 2
function Class2(){}
Class2.prototype.square = function(x){
  return x * x
}

//Class 3
const Class3proto = {
  square(x){
    return x*x
  }
}
function Class3(){
  return Object.create(Class3proto)
}

function setup() {
  console.log("Type 1: " + type1(8))
  console.log("Type 2: " + type2(8))
  console.log("Type 3: " + type3(8))
  
  a = new Class1()
  console.log("Class 1: " + a.square(6))
  
  b = new Class2()
  console.log("Class 2: " + b.square(6))
  
  c = Class3()
  console.log("Class 3: " + c.square(6))
}