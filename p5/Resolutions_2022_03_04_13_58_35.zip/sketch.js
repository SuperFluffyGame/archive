function setup() {
  createCanvas(1366, 768);
  pixelDensity(2)
}

function draw() {
  background(220);
  scale(.2)
  strokeWeight(10)
  fill('magenta')
  rect(0,0,7680,4320)
  fill('pink')
  rect(0,0,3840,2160)
  fill('cyan')
  rect(0,0,2560,1440)
  fill('lime')
  rect(0,0,1920,1080)
  fill('yellow')
  rect(0,0,1366,768)
  fill('white')
  rect(0,0,852,480)
  fill('lightgray')
  rect(0,0,640,360)
  
  fill(0)
  textSize(100)
  textAlign(RIGHT,BOTTOM)
  text('8K (4320p)',7680,4320)
  text('4K (2160p)',3840,2160)
  text('QHD (1440p)',2560,1440)
  text('FHD (1080p)',1920,1080)
  text('HD (720p)',1366,768)
  text('SD (480p)',852,480)
  text('SD (360p)',640,360)
 }
function keyPressed(){
  if(keyCode === 70){
    let fs = fullscreen()
    fullscreen(!fs)
  }
}