let lin1,lin2
let ray1
function setup() {
  createCanvas(400, 400);
  lin1 = new Line(100,60,95,300)
  lin2 = new Line(50,200,200,50)
  ray1 = new Ray(createVector(0,0),radians(45),200,[lin1,lin2],2)
}

function draw() {
  background(220);
  stroke(0);

  ray1.angle = atan2(mouseX,mouseY)
  
  lin1.show()
  lin2.show()
  ray1.show()

}
class Line{
  constructor(x1,y1,x2,y2){
    this.p1 = createVector(x1,y1)
    this.p2 = createVector(x2,y2)
  }  
  show(){
    line(this.p1.x,this.p1.y,this.p2.x,this.p2.y)
  }
  intersectsRaw(lin){
    let x1 = this.p1.x, x2 = this.p2.x
    let x3 = lin.p1.x,  x4 = lin.p2.x
    let y1 = this.p1.y, y2 = this.p2.y
    let y3 = lin.p1.y,  y4 = lin.p2.y
    let uA = ((x4-x3)*(y1-y3) - (y4-y3)*(x1-x3)) / ((y4-y3)*(x2-x1) - (x4-x3)*(y2-y1));
    let uB = ((x2-x1)*(y1-y3) - (y2-y1)*(x1-x3)) / ((y4-y3)*(x2-x1) - (x4-x3)*(y2-y1));
    
    return {a: uA, b: uB}
  }
  intersects(lin){
    let u = this.intersectsRaw(lin)
      if (u.a >= 0 && u.a <= 1 && u.b >= 0 && u.b <= 1) {
          return true;
      }
      return false;
  }
  intersectsAt(lin){
    let u = this.intersectsRaw(lin)
    let intersectionX = this.p1.x + (u.a * (this.p2.x-this.p1.x));
    let intersectionY = this.p1.y + (u.a * (this.p2.y-this.p1.y));  
    return createVector(intersectionX,intersectionY);
  }
}
class Ray{
  constructor(origin,angle,maxMag,collisionList,bounce){
    this.origin = origin
    this.angle = angle
    this.maxMag = maxMag
    this.collisions = collisionList
    this.maxBounce = bounce
  }
  show(){
    let lines = []
    lines.push(new Line(origin.x,origin.y,
                        this.maxMag*sin(this.angle),
                        this.maxMag*cos(this.angle)))
    let length = 0
    while(length < this.maxMag){
      let length = 0
      for(let i = 0; i < this.collisions.length; i++){
        if(lines[0].intersects(this.collisions[i])){
          lines[0].p2 = lines[0].intersectsAt(this.collisions[i])
          lines.push(new Line(lines[0].p2.x,lines[0].p2.y,lines[0].p2.x,100))
        }
      }
      for(let i = 0; i < lines.length; i++){
        length += sqrt(lines[i].p2.x**2+lines[i].p2.y**2)
      }
    }
    for(let i = 0; i < lines.length; i++){
      stroke('red')
      lines[i].show()
      text(length,350,350)
    }
  }
}