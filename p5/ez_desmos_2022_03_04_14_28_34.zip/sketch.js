let des
function setup() {
  createCanvas(400, 400);
  des = new Desmos()
  des.polygon([[0,0],[0,1],[1,1]],"blue")
}
class Desmos {
  constructor(){
    this.expressions = []
    this.nextID = 0
  }
  polygon(vertices, color){
    let latex = "\\polygon("
    for(let i = 0; i < vertices.length; i++){
      latex += "(" + vertices[i][0] + "," + vertices[i][1] + ")"
      if(i != vertices.length-1){
        latex += ","
      }
    }
    latex += ")"
    this.expressions.push(
      {
        id: this.nextID,
        latex: latex,
        color: color
      }
    )
  }
  export(){
    return "Calc.setExpressions(" + ")"
  }
}