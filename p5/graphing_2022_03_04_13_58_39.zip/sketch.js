function setup() {
  createCanvas(400, 400);
}

function draw() { 
  textAlign(LEFT,CENTER)
  textSize(15)
  stroke(0)
  strokeWeight(1)
  background(220);
  text("FPS: " + round(frameRate()),20,20)
  text(round(s,2),350,350)
  translate(mouseX,mouseY)
  scale(s)
  stroke(0)
  strokeWeight(2/s)
  line(0,-400,0,400)
  line(-400,0,400,0)
  let z=0.1
  let y = 0,py = 0,px = 0
  stroke(0)
  textSize(0.5)
  for(let i = -40; i <= 40; i++){
    line(i*10,2,i*10,-2)
    textSize(3)
    if(i != 0){
    text(i*10,i*10,5)}
  }
  for(let i = -40; i <= 40; i++){
    line(i,0.25,i,-0.25)
    textSize(0.75)
    if(i != 0 && s > 10){
    text(i,i,1)}
  }
  for(let i = -40; i <= 40; i++){
    line(-2,i*10,2,i*10)
    textSize(3)
    if(i != 0){
    text(-i*10,5,i*10)}
  }
  for(let i = -40; i <= 40; i++){
    line(-0.25,i,0.25,i)
    textSize(0.75)
    if(i != 0 && s > 10){
    text(-i,-1,i)}
  }
  //line 1
  stroke('red')
  for(let x = -height; x <= height; x+= z){
    py = y
    y = 0-(    5*x-7 )
    px = x-z
    line(px,py,x,y)
  }
  //line 2
  stroke('blue')
  for(let x = -height; x <= height; x+= z){
    py = y
    y = 0-(   (1/16)*x+10 )
    px = x-z
    line(px,py,x,y)
  }
}
let s = 5
function mouseWheel(scaler){
  if(s < 1){s=1}else{  s -= (scaler.delta/100)*s/10}
}
