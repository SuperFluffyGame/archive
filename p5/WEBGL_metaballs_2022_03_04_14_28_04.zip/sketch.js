let marcher
//let img
let res = 20
function preload(){
  marcher = loadShader('march.vert','march.frag')
}
function setup() {
  createCanvas(400, 400,WEBGL);
  frameRate(144)
//   img = createImage(floor(width/res)+1,floor(height/res)+1)
  
//   img.loadPixels()
//   for(let i = 0; i < img.width; i++){
//     for(let j = 0; j < img.height; j++){
//       img.set(i,j,color(0,0,0))
//     }
//   }
//   img.updatePixels()
//   img.loadPixels()
//   for(let i = 0; i < img.width; i++){
//     for(let j = 0; j < img.height; j++){
//       img.set(i,j,color(random(0,255),0,0))
//     }
//   }
//   img.updatePixels()
}

function draw() {
  background(220);
  shader(marcher)
  marcher.setUniform('u_resolution',[width,height])
  marcher.setUniform('res',res)
  //marcher.setUniform('points',img)
  marcher.setUniform('mouse',[mouseX,mouseY])
  
  marcher.setUniform('metas',[(mouseX/width*2),(mouseY/width*2),0.0,0.0,0.5,0.5])
  rect(0,0,width,height)
}