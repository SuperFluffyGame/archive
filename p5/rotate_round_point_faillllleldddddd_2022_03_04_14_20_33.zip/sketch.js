let rot = 0
let prot = 45
let protSlider
function setup() {
  createCanvas(400, 400);
  protSlider = createSlider(0,360,0)
}

function draw() {
  background(220);
  strokeWeight(2)
  stroke(0)
  rotatedRectAroundPoint(200,100,20,20,200,200,radians(protSlider.value()))
  strokeWeight(4)
  stroke('red')
  point(200,200)
}
// function createCircle(x,y,r){
//   let c = []
//   for(let i = 0; i < 360; i++){
//     c.push([x+sin(radians(i))*r,y+cos(radians(i))*r])
//   }
//   for(let i = 1; i < c.length; i++){
//     line(c[i][0],c[i][1],c[i-1][0],c[i-1][1])
//   }
// }
// function rotSquare(x,y,sx,sy,rot){
//   r = radians(rot)
//   line(x-sx/2+sin(r)*sx,y-sy/2+cos(r)*sy,x+sx/2-sin(r)*sx,y-sy/2-cos(r)*sy)
//   line(x-sx/2+sin(r)*sx,y-sy/2+cos(r)*sy,x-sx/2-sin(r)*sx,y+sy/2-cos(r)*sy)
//   line(x+sx/2+sin(r)*sx,y-sy/2+cos(r)*sy,x+sx/2-sin(r)*sx,y+sy/2-cos(r)*sy)
//   line(x-sx/2+sin(r)*sx,y+sy/2+cos(r)*sy,x+sx/2-sin(r)*sx,y+sy/2-cos(r)*sy)
// }
function rotatedRect(x,y,sx,sy,angle){
  //rect(x,y,sx,sy)
  line(x+   sin(angle+radians(90))*sx/2-sin(angle)*sx/2,
       y-sy+cos(angle+radians(90))*sy/2-cos(angle)*sy/2+sy,
       x-   sin(angle+radians(90))*sx/2-sin(angle)*sx/2,
       y-sy-cos(angle+radians(90))*sy/2-cos(angle)*sy/2+sy)
  line(x-sx+sin(angle)*sx/2+sin(angle+radians(90))*sx/2+sx,
       y+   cos(angle)*sy/2+cos(angle+radians(90))*sy/2,
       x-sx-sin(angle)*sx/2+sin(angle+radians(90))*sx/2+sx,
       y-   cos(angle)*sy/2+cos(angle+radians(90))*sy/2)  
  line(x+   sin(angle+radians(90))*sx/2+sin(angle)*sx/2,
       y+sy+cos(angle+radians(90))*sy/2+cos(angle)*sy/2-sy,
       x-   sin(angle+radians(90))*sx/2+sin(angle)*sx/2,
       y+sy-cos(angle+radians(90))*sy/2+cos(angle)*sy/2-sy)  
  line(x+sx+sin(angle)*sx/2-sin(angle+radians(90))*sx/2-sx,
       y+   cos(angle)*sy/2-cos(angle+radians(90))*sy/2,
       x+sx-sin(angle)*sx/2-sin(angle+radians(90))*sx/2-sx,
       y-   cos(angle)*sy/2-cos(angle+radians(90))*sy/2)  
}
function rotatedRectAroundPoint(x,y,sx,sy,rx,ry,angle){
  let tx = x,ty=y
  tx -= rx
  ty -= ry
  ty = ty+sin(angle)*100
  tx = ty+cos(angle)*100
  tx += rx
  ty += ry
  rotatedRect(tx,ty,sx,sy,angle)
}