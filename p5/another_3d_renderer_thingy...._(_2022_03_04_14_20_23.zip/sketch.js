let testCube
function setup() {
  createCanvas(400, 400);
  testCube = new Cube(new Vertex3d(-40,0,-40),20)
  noFill()
}

function draw() {
  translate(width/2,height/2)
  background(220);
  renderCubes([testCube])
}
class Vertex3d{
  constructor(x,y,z){
    this.x = x
    this.y = y
    this.z = z
  }
}
class Vertex2d{
  constructor(x,y){
    this.x = x
    this.y = y
  }
}
class tri3d{
  constructor(v1,v2,v3){
    this.vertices = [v1,v2,v3]
  }
}
class tri2d{
  constructor(v1,v2,v3){
    this.vertices = [v1,v2,v3]
  }
}
class square3d{
  constructor(v1,v2,v3,v4){
    this.triangles = [new tri3d(v1,v2,v4),new tri3d(v2,v3,v4)]
  }
}
class Cube{
  constructor(center,r){
                                        //- is BACK - is Left -is Down
                 //Back
   this.faces = [new square3d(new Vertex3d(center.x-r,center.y-r,center.z-r),
                              new Vertex3d(center.x-r,center.y-r,center.z+r), 
                              new Vertex3d(center.x-r,center.y+r,center.z+r), 
                              new Vertex3d(center.x-r,center.y+r,center.z-r)),
                 //Left
                 new square3d(new Vertex3d(center.x-r,center.y-r,center.z-r),
                              new Vertex3d(center.x+r,center.y-r,center.z-r), 
                              new Vertex3d(center.x+r,center.y-r,center.z+r), 
                              new Vertex3d(center.x-r,center.y-r,center.z+r)),
                 //Right
                 new square3d(new Vertex3d(center.x-r,center.y+r,center.z-r),
                              new Vertex3d(center.x+r,center.y+r,center.z-r), 
                              new Vertex3d(center.x+r,center.y+r,center.z+r), 
                              new Vertex3d(center.x-r,center.y+r,center.z+r)),      
                 //Up
                 new square3d(new Vertex3d(center.x-r,center.y-r,center.z+r),
                              new Vertex3d(center.x+r,center.y-r,center.z+r), 
                              new Vertex3d(center.x+r,center.y+r,center.z+r), 
                              new Vertex3d(center.x-r,center.y+r,center.z+r)),   
                 //Down
                 new square3d(new Vertex3d(center.x-r,center.y-r,center.z-r),
                              new Vertex3d(center.x+r,center.y-r,center.z-r), 
                              new Vertex3d(center.x+r,center.y+r,center.z-r), 
                              new Vertex3d(center.x-r,center.y+r,center.z-r)),
                 
                 //Front
                 new square3d(new Vertex3d(center.x+r,center.y-r,center.z-r),
                              new Vertex3d(center.x+r,center.y-r,center.z+r), 
                              new Vertex3d(center.x+r,center.y+r,center.z+r), 
                              new Vertex3d(center.x+r,center.y+r,center.z-r))
                 ]
  }
                 
}
function renderCubes(cubes){
  for(let i = 0; i < cubes.length; i++){
    for(let j = 0; j < cubes[i].faces.length; j++){
      for(let k = 0; k < cubes[i].faces[j].triangles.length; k++){
        for(let l = 0; l < cubes[i].faces[j].triangles[k].vertices.length; l++){
          let P = project(cubes[i].faces[j].triangles[k].vertices[l])
          mPoint(P)
        }
      }
    }
  }
}
function mtriangle(tri){
  triangle(tri.vertices[0].x,tri.vertices[0].y,
           tri.vertices[1].x,tri.vertices[1].y,
           tri.vertices[2].x,tri.vertices[2].y)
}
function mPoint(v){
  point(v.x,v.y)
}
function project(input){
  let d = 30
  let r = d/input.z
  return(new Vertex2d(r*input.x,r*input.y))
}