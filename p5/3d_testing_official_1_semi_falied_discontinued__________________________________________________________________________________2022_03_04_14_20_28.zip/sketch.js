//TODO
//2. camera rotations (hard)


let obj 
let tobj
let cameraPos
let xrot = 20
function preload(){
  obj = loadStrings('simpleobj.txt')
}
function setup() {
  createCanvas(400, 400);
  strokeWeight(2)
  frameRate(144)
  textAlign(LEFT,TOP)
  textSize(20)
  
  for(let i = 0; i < obj.length; i++){
    obj[i] = obj[i].split(';')
    for(let j = 0; j < obj[i].length; j++){
      obj[i][j] = obj[i][j].split(",")
    }
  }
  tobj = obj
  console.log(obj)
  
  cameraPos = [0,0,-100]
}

function draw() {
  background(220);
  fill('white')
  translate(width/2,height/2)
  
  if(keyIsDown(65)){
    cameraPos[0]--
  }
  if(keyIsDown(68)){
    cameraPos[0]++
  }
  if(keyIsDown(87)){
    cameraPos[2]++
  }
  if(keyIsDown(83)){
    cameraPos[2]--
  }
  if(keyIsDown(32)){
    cameraPos[1]--
  }
  if(keyIsDown(16)){
    cameraPos[1]++
  }

  render(obj,"p")
  fill('black')
  text("X: " + cameraPos[0]+ " Y: " + cameraPos[1] + " Z: " + cameraPos[2],
       -width/2,-height/2)
}
function render(pointList,type){
  for(let i = 0; i < obj.length; i++){
    for(let j = 0; j < obj[i].length; j++){
      for(let k = 0; k < obj[i][j].length; k++){
        tobj[i][j][k] = parseInt(obj[i][j][k])
      }
      tobj[i][0] += sin(radians(xrot))
    }
    if(type == "o"){
      P = orthoProject(obj[i])
    }else if(type == "p"){
      P = perspectiveProject(obj[i])
    }else{
      console.error("Invalid projection type!")
    }
      triangle(P[0][0],P[0][1],P[1][0],P[1][1],P[2][0],P[2][1])
  } 
}
function orthoProject(tri){
  return [[tri[0][0]-cameraPos[0],
           tri[0][1]-cameraPos[1]],
          [tri[1][0]-cameraPos[0],
           tri[1][1]-cameraPos[1]],
          [tri[2][0]-cameraPos[0],
           tri[2][1]-cameraPos[1]]]
}
function perspectiveProject(tri){
  let d = 200
    return [[(d/(tri[0][2]-cameraPos[2]))*(tri[0][0]-cameraPos[0]),
             (d/(tri[0][2]-cameraPos[2]))*(tri[0][1]-cameraPos[1])],
            [(d/(tri[1][2]-cameraPos[2]))*(tri[1][0]-cameraPos[0]),
             (d/(tri[1][2]-cameraPos[2]))*(tri[1][1]-cameraPos[1])],
            [(d/(tri[2][2]-cameraPos[2]))*(tri[2][0]-cameraPos[0]),
             (d/(tri[2][2]-cameraPos[2]))*(tri[2][1]-cameraPos[1])]]

}