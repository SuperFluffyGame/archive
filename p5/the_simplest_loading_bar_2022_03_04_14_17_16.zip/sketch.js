let pb
function setup() {
  createCanvas(400, 400);
  pb = new ProgressBar(width/2,height/2,300,25)
}
function draw() {
  background(220);
  pb.draw()
}

class ProgressBar {
  constructor(x,y,sx,sy){
    this.x = x
    this.y = y
    this.sx = sx
    this.sy = sy
    this.loaded = false
    this.progress = 0
    this.strokeColor = 'black'
    this.fillColor = 'gray'
    this.strokeWeight = 5
  }
  draw(){
    noFill()
    strokeWeight(this.strokeWeight)
    stroke(this.strokeColor)
    rect(this.x-this.sx/2,this.y-this.sy/2,this.sx,this.sy)
    
    noStroke()
    fill(this.fillColor)
    rect(this.x-this.sx/2,this.y-this.sy/2,map(this.progress,0,100,this.x-this.sx/1.5,this.sx),this.sy)
  }
  progressAdd(padd){
    this.progress += padd
  }
}
