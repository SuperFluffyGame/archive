let ball
let mouseClick
let leftWall, rightWall, topWall, bottomWall
let walls
function setup() {
  createCanvas(400, 400);
  ball = new Ball(50,50,20,20)
  leftWall = new Collision(0,0,0,height)
  rightWall = new Collision(width,0,0,height)
  topWall = new Collision(0,0,width,0)
  bottomWall = new Collision(0,height,width,0)
  walls = [leftWall,rightWall,topWall,bottomWall]

}

function draw() {
  background(220);
  ball.show()
  if(mouseClick == 1){
    line(ball.pos.x,ball.pos.y,mouseX,mouseY)
  }
  for(let i = 0; i < walls.length; i++){
    if(collides(walls[i],ball)){
      console.log("Collision!")
    }
  }
}

function mousePressed(){
  mouseClick = 1
}
function mouseReleased(){
  ball.acc = createVector(-(mouseX - ball.pos.x)/25, -(mouseY - ball.pos.y)/25)
  mouseClick = 0
}

class MyObject {
  constructor(px,py,sx,sy){
    this.pos = createVector(px,py)
    this.size= createVector(sx,sy)
    this.vel = createVector(0,0)
    this.acc = createVector(0,0)
  }
}

function collides(object1,object2){
  if(object1.pos.x + object1.size.x/2 > object2.pos.x - object2.size.x/2 && 
     object1.pos.x - object1.size.x/2 < object2.pos.x + object2.size.x/2 &&
     object1.pos.y + object1.size.y/2 > object2.pos.y - object2.size.y/2 &&
     object1.pos.y - object1.size.y/2 < object2.pos.y + object2.size.y/2){
    return true
  }else{
    return false
  }
}

class Collision extends MyObject{
  constructor(x,y,sx,sy){
    super(x,y,sx,sy)
  }
  tempShow(){
    rectMode(CENTER)
    rect(this.pos.x,this.pos.y,this.size.x,this.size.y)
  }
}

class Ball extends MyObject{
  constructor(x,y,sx,sy){
    super(x,y,sx,sy)
  }
  show(){

    ellipse(this.pos.x,this.pos.y,this.size.x,this.size.y)
    this.move()
  }
  move(){
    let c = 0.05
    this.friction = this.vel
    this.friction.mult(-1);
    this.friction.normalize();
    this.friction.mult(c);
    
    this.acc.add(this.friction)
    this.vel.add(this.acc)
    this.vel.add(this.acc)
    if(abs(this.vel.x) < 0.1){
      this.vel.x = 0
    }
    if(abs(this.vel.y) < 0.1){
      this.vel.y = 0
    }
    this.pos.add(this.vel)
  }
}