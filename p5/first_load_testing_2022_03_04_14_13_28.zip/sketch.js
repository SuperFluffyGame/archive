let alertButton, click1 = 0,
  click2 = 0,
  click3 = 0,
  click4 = 0
let loadButton, load, load3 = [0, 0, 0, 0]
let enc = 32
let numenc = 2.1847192047

function setup() {
  createCanvas(400, 400);
  alertButton = createButton('Save')
  alertButton.mousePressed(alert2)
  loadButton = createButton('Load')
  loadButton.mousePressed(load2)
  textAlign(CENTER, CENTER)
  textSize(25)
}

function draw() {
  background(220);
  line(100, 0, 100, height)
  line(200, 0, 200, height)
  line(300, 0, 300, height)
  line(400, 0, 400, height)
  text(click1, 50, height / 2)
  text(click2, 150, height / 2)
  text(click3, 250, height / 2)
  text(click4, 350, height / 2)


}

function alert2() {
  message = toHex(click1) + ":" + toHex(click2) + ":" + toHex(click3) + ":" + toHex(click4)
  prompt("Copy This:", message)
}

function load2() {
  prompty = prompt("Enter Save Game: \nWARNING: DO NOT ENTER NOTHING", "0:0:0:0")
  if (prompty != null && prompty != undefined) {
      load = split(prompty, ":")
      click1 = round(parseInt(load[0], enc) / numenc)
      click2 = round(parseInt(load[1], enc) / numenc)
      click3 = round(parseInt(load[2], enc) / numenc)
      click4 = round(parseInt(load[3], enc) / numenc)
  }
}

function mouseClicked() {
  if (mouseX < 100) {
    click1++
  } else if (mouseX > 100 && mouseX < 200) {
    click2++
  } else if (mouseX > 200 && mouseX < 300) {
    click3++
  } else if (mouseX > 300 && mouseX < 400) {
    click4++
  }
}

function toHex(d) {
  return ((Number(d * numenc).toString(enc))).toUpperCase()
}