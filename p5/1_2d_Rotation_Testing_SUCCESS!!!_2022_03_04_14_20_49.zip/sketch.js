SFG.useP5()
let points;
function setup() {
  createCanvas(400, 400);
  points = [new MyPoint(-25, 25),
            new MyPoint(-25,-25),
            new MyPoint( 25,-25),
            new MyPoint( 25, 25)]
  strokeWeight(4)
}

function draw() {
  background(220);
  translate(width/2,height/2)

  for(let i = 0; i < points.length; i++){
    points[i].resetTransform()
    points[i].rotateAround(0,0,radians(mouseX))
    points[i].transform()
  }
  
  //drawing the lines
  for(let i = 0; i < points.length; i++){
    SFG.mPoint2d(points[i].pos)
  }
  //SFG.mLine2d(points[points.length-1].pos,points[0].pos)


}
class MyPoint{
  constructor(x,y){
    this.pos = SFG.create2dMatrix(x,y)
    this.originalPos = SFG.create2dMatrix(x,y)
    this.tm = new SFG.Matrix([[1,0,0],
                              [0,1,0],
                              [0,0,1]])
  }
  translate(x,y){
    //this.pos = SFG.cloneMatrix(this.originalPos)
    this.tm.mult(new SFG.Matrix([[1,0,0],
                                 [0,1,0],
                                 [x,y,1]]))
  }
  rotate(angle){
    //this.pos = SFG.cloneMatrix(this.originalPos)
    this.tm.mult(new SFG.Matrix([[ cos(angle),-sin(angle),0],
                                 [ sin(angle), cos(angle),0],
                                 [    0      ,    0      ,1]]))
  }
  rotateAround(x,y,angle){
    this.translate(-x,-y)
    this.rotate(angle)
    this.translate(x,y)
  }
  transform(){
    this.pos.mult(this.tm)
  }
  resetTransform(){
    this.pos = SFG.cloneMatrix(this.originalPos)

    this.tm = new SFG.Matrix([[1,0,0],
                              [0,1,0],
                              [0,0,1]])
  }
}