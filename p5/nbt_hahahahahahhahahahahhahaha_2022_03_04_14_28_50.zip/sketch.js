let nbt

function setup() {
  createCanvas(400, 400);
  
  nbt = new NBT(16)
  nbt.writeStart()
  console.log(nbt.exportString())
}

function draw() {
  background(220);
}

class NBT {
  constructor(size){
    this.size = size
    this.data = new Int8Array(new ArrayBuffer(size))
    this.writePos = 0
    this.tags = {
      START: [10,0,0],
      LIST: [9]
    }
  }
  writeStart(){
    this.data.set(this.tags.START,this.writePos)
    this.writePos += this.tags.START.length
  }
  writeList(name,type){
    let data = [...this.tags.list,name.length.toString,0]
    this.data.set(this.tags.LIST,this.writePos)
  }
  export(){
    return this.data
  }
  exportString(){
    let ex = ''
    this.data.forEach((elem)=>{
      ex += elem.toString(16).padStart(2,0) + ' '
    })
    return ex
  }
}

function stringToIntArray(string){
  let out = [...string].map(ch=>ch.charCodeAt(0))
  return out
}
function int32toLE(int){
  let out = int.toString(16).padStart(8,0)
  out = out.toString().match(/.{1,2}/g)
  out.reverse()
  for(let i = 0; i < out.length; i++){
    out[i] = parseInt(out[i],16)
  }
  return out
}