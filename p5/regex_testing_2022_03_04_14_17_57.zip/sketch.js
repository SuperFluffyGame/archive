function setup() {
  createCanvas(400, 400);
  let input = "4 + 5 * 10"
  let parsedInput = parse2(input)
  console.log(parsedInput)
  console.log(sumAll(parsedInput))
}




function sumAll(array){
  let a = 0
  for(let i = 0; i < array.length; i++){
    a += float(array[i])
  }
  return a
}
function parse(string){
  let re = /^\d|\s*[\+|\-]\s*\d*/g   //  /^\d|\s*[\+|\-]\s*\d*/g

  let out = string.match(re)
  for(let i = 0; i < out.length; i++){
    out[i] = out[i].replace(/\s/g,'')
  }
  return out
}
function parse2(input){
  let out = splitByPlus(input)
  return out
}
function splitByPlus(input){
  // if(typeof input == "string"){
  //   input = [input]
  // }
  let out = input.split(/\s*\+\s*/)
  console.log(out)
  out = splitByMult(out)
  return out
}
function splitByMult(input){
  let out = [];
  for(let i = 0; i < input.length; i++){
    out[i] = input[i].split(/\s*\*\s*/)
  }
  return out
}