let global
function onload(){
  console.log("hi")
  global = new svg(100,100)
  global.testLine(100,100,200,200)
  console.log(global.elem)
}
class svg {
  constructor(width,height,res){
    this.elem = document.createElement("SVG")
    this.elem.setAttribute("viewBox","0 0 500 500")
    this.elem.setAttribute("width","500")
    this.elem.style.background = "black"
    document.body.appendChild(this.elem)
  }
  testLine(x1,y1,x2,y2){
    let path = document.createElement("PATH")
    path.setAttribute("d", "M x1 y1 x2 y2")
    console.log(path)
    this.elem.appendChild(path)
  }
}