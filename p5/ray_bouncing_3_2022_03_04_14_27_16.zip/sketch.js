let ray
function setup(){
  createCanvas(400,400)
  ray = new bouncingRay(createVector(0,0),-45,4,500)
}
function draw(){
  background(220)
}
class bouncingRay{
  constructor(origin,angle,maxBounce,lengthLimit){
    this.origin = origin
    this.angle = angle
    this.maxBounce = maxBounce
    this.limit = lengthLimit
    this.rays = []
  }
  showFirst(){
    pLine()
  }
}
function pLine(origin,angle,length){
  line(origin.x+angle*sin(length),origin.y+angle*cos(length))
}