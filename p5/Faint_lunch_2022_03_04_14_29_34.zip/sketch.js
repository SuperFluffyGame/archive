let program
function preload(){
  program = loadShader("shaders/vert.vert","shaders/frag.frag")
}
function setup() {
  createCanvas(400, 400, WEBGL);
}

function draw() {
  background(220);
  shader(program)
  
  let globalMatrix
  
  let stars = [
    100,100,10,1,
    200,300, 2,1,
  ]
  
  program.setUniform("stars",stars)
  
  rect(0,0,width,height)
}