const Mat4 = {
  get i(){
    return [1,0,0,0,
            0,1,0,0,
            0,0,1,0,
            0,0,0,1]
  }
}
Mat4.get = function(mat,a,b){
  return(mat[a*4+b])
}
Mat4.set = function(mat,a,b,v){
  mat[a*4+b] = v
  return mat
}
Mat4.transpose = function(mat){
  let newM = Mat4.i
  for(let i = 0; i < 4; i ++){
    for(let j = 0; j < 4; j++){
      newM[j][i] = mat[i][j]
    }
  }
  return newM
}
Mat4.add = function(mat1,mat2){
  let newM = Mat4.i
  for(let i = 0; i < 16; i++){
    newM[i] = mat1[i] + mat2[i]
  }
  return newM
}
Mat4.identity = function(){
  return [1,0,0,0,
          0,1,0,0,
          0,0,1,0,
          0,0,0,1]
}
Mat4.rotateX = function(x){
  return [      1,      0,      0,      0,
                0, cos(x),-sin(x),      0,
                0, sin(x), cos(x),      0,
                0,      0,      0,      1]
}
Mat4.rotateY = function(y){
  return [ cos(y),      0, sin(y),      0,
                0,      1,      0,      0,
          -sin(y),      0, cos(y),      0,
                0,      0,      0,      1]
}
Mat4.rotateZ = function(z){
  return [ cos(z),-sin(z),      0,      0,
           sin(z), cos(z),      0,      0,
                0,      0,      1,      0,
                0,      0,      0,      1]
}
Mat4.translate = function(x,y,z){
  return [1,0,0,0,
          0,1,0,0,
          0,0,1,0,
          x,y,z,1]
}

Mat4.mult = function(m1,m2){
  let out = Mat4.i
  for(let z = 0; z < 4; z++){
    for(let y = 0; y < 4; y++){
      Mat4.set(out,z,y,0)
    }
  }
  for (let i = 0; i < 4; i++) {
    for (let j = 0; j < 4; j++) {
      for (let k = 0; k < 4; k++) {
        Mat4.set(out,i,j,Mat4.get(out,i,j) + Mat4.get(m1,i,k) * Mat4.get(m2,k,j))
      }
    }
  }
  return out
}

Mat4.multiMult = function(){
  let init = Mat4.i
  arguments.forEach((ele)=>{
    Mat4.mult(init,ele)
  })
  return init
}
Mat4.perspective = function(fovy, aspect, near, far) {
  let out = Mat4.i
  const f = 1.0 / Math.tan(fovy / 2);
  out[0] = f / aspect;
  out[1] = 0;
  out[2] = 0;
  out[3] = 0;
  out[4] = 0;
  out[5] = f;
  out[6] = 0;
  out[7] = 0;
  out[8] = 0;
  out[9] = 0;
  out[11] = -1;
  out[12] = 0;
  out[13] = 0;
  out[15] = 0;
  if (far != null && far !== Infinity) {
    const nf = 1 / (near - far);
    out[10] = (far + near) * nf;
    out[14] = 2 * far * near * nf;
  } else {
    out[10] = -1;
    out[14] = -2 * near;
  }
  return out;
}