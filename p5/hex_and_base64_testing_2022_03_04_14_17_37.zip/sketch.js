function setup() {
  let base = 36
  let json = {x:1}//, stats:{coins: -10, clicks: 1924857914827}}
  let string = JSON.stringify(json)
  let encryptedString = btoa(string)//toHex(string,base)
  console.log(encryptedString)
  let decryptedString = atob(encryptedString)//fromHex(encryptedString,base)
  console.log(decryptedString)
  console.log(JSON.parse(decryptedString))

}

// function fromHex(hex,n) {
//   let hex0 = ""
//   let hex1 = []
//   let hex2 = []
//   for(let i = 0; i < hex.length/4; i++){
//     for(let j = 0; j < 4; j++){
//       hex0 += hex.charAt(j+i*4)
//     }
//     hex1.push(hex0)
//     hex0 = ""
//     hex2.push(String.fromCharCode(parseInt(hex.substr(i, 2), 16)))
//   }
//   return hex2
// }

// function toHex(str,n) {
//   let hex1 = []
//   let hex2 = []
//   for(let i = 0; i < str.length; i++){
//     hex1.push(str.charCodeAt(i).toString(n))
//     hex2.push(hex1[i])//.padStart(4,'0'))
//   }
//   let r = hex2.join('')
//   return r;
// }
function toHex(str,n){
    var hex, i;

    var result = "";
    for (i=0; i<str.length; i++) {
        hex = str.charCodeAt(i).toString(n);
        result += ("00000000"+hex).slice(-2);
    }
    return result
}
function fromHex(str,n){
    var j;
    var hexes = str.match(/.{1,2}/g) || [];
  console.log(hexes)
    var back = "";
    for(j = 0; j<hexes.length; j++) {
        back += String.fromCharCode(parseInt(hexes[j], n));
    }

    return back;
}