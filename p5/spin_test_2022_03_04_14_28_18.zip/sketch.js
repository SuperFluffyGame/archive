let spin
function setup() {
  createCanvas(400, 400);
  angleMode(DEGREES)
  colorMode(HSL)
  textAlign(CENTER,CENTER)
  spin = new Spinner()
  angles.forEach((e,i) => {
    spin.newPart(e,color(random(0,360),100,50),i)
  })
}
let angles = [100,30,50,10,40,80,50]
function draw() {
  background(220);
  spin.show(width/2,height/2,200)
}
class Spinner{
  constructor(){
    this.sectors = []
  }
  show(x,y,s){
    fill('gray')
    circle(x,y,s)
    let totalAngle = 0
    for(let i = 0; i < this.sectors.length; i++){
      resetMatrix()
      translate(x,y)
      rotate(totalAngle)
      fill(this.sectors[i].color)
      arc(0,0,s,s,0,this.sectors[i].size)
      totalAngle += this.sectors[i].size
      fill(0)
      rotate(this.sectors[i].size/2)
      translate(s/2.25,0)
      rotate(90)
      text(this.sectors[i].name,0,0)
    }
  }
  newPart(size,color,name){
    let total = 0
    for(let i = 0; i <this.sectors.length; i++){
      total += this.sectors[i].size
    }
    console.log(total)
    if(total+size <= 360){
      this.sectors.push(new Sector(size,color,name))
    }
  }
}
class Sector{
  constructor(size,color,name){
    this.size = size
    this.color = color
    this.name = name
  }
}