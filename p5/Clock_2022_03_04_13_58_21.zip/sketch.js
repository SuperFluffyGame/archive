z = 133

function setup() {
  createCanvas(600, 500);
  strokeWeight(5)
}

function draw() {
  dv = millis()
  bv = minute()
  av = hour()
  cv = second()
  c2 = map(-cv, 0, 60, PI, 3 * PI)
  b2 = map(-bv, 0, 60, PI, 3 * PI) - ((map(cv, 0, 60, PI, 3 * PI) / 60) - 0.05)
  a2 = map(-av, 0, 12, PI, 3 * PI) - ((map(bv, 0, 60, PI, 3 * PI) / 12) - 0.25)
  textAlign(CENTER, CENTER)
  translate(205, 205)
  background("maroon");
  strokeWeight(8)
  fill("gold")
  circle(0, 0, 400 - 5)
  fill(0)
  strokeWeight(15)
  strokeWeight(2)
  for (let i = 0; i < 60; i++) {
    i2 = map(i, 0, 360, 0, 12 * PI)
    line(sin(i2) * 180, cos(i2) * 180, sin(i2) * 195, cos(i2) * 195)
  }
  strokeWeight(5)
  for (let i = 0; i < 12; i++) {
    i2 = map(i, 0, 360, 0, 60 * PI)
    line(sin(i2) * 160, cos(i2) * 160, sin(i2) * 195, cos(i2) * 195)
  }
  //stroke(0,255,0)
  strokeWeight(10)
  line(0, 0, sin(b2) * 160, cos(b2) * 160)

  //stroke(0,0,255)
  strokeWeight(10)
  line(0, 0, sin(a2) * 100, cos(a2) * 100)

  stroke("red")
  strokeWeight(4)
  line(0, 0, sin(c2) * 160, cos(c2) * 160)

  stroke(0)
  strokeWeight(20)
  point(0, 0)

  strokeWeight(1)
  textSize(50)
  text("1", sin(PI / 6) * z, -cos(PI / 6) * z)
  text("2", sin(2 * PI / 6) * z, -cos(2 * PI / 6) * z)
  text("3", sin(3 * PI / 6) * z, -cos(3 * PI / 6) * z)
  text("4", sin(4 * PI / 6) * z, -cos(4 * PI / 6) * z)
  text("5", sin(5 * PI / 6) * z, -cos(5 * PI / 6) * z)
  text("6", sin(6 * PI / 6) * z, -cos(6 * PI / 6) * z)
  text("7", sin(7 * PI / 6) * z, -cos(7 * PI / 6) * z)
  text("8", sin(8 * PI / 6) * z, -cos(8 * PI / 6) * z)
  text("9", sin(9 * PI / 6) * z, -cos(9 * PI / 6) * z)
  text("10", sin(10 * PI / 6) * z, -cos(10 * PI / 6) * z)
  text("11", sin(11 * PI / 6) * z, -cos(11 * PI / 6) * z)
  text("12", sin(12 * PI / 6) * z, -cos(12 * PI / 6) * z)

  strokeWeight(5)
  stroke("gold")
  line(-202.5,-202.5,400,-202.5)
  line(-202.5,292.5,400,292.5)
  line(-202.5,-202.5,-202.5,300)
  line(392.5,-200,392.5,300)
  stroke(0)
  strokeWeight(1)
  textSize(30)
  if (hour() < 13) {
    if (minute() < 10 && second() > 9) {
      text(hour() + ":" + "0" + minute() + ":" + second(), 0, 220)
    } else if (minute() < 10 && second() < 10) {
      text(hour() + ":" + "0" + minute() + ":" + "0" + second(), 0, 220)
    } else if (minute() > 9 && second() > 9) {
      text(hour() + ":" + minute() + ":" + second(), 0, 220)
    } else if (minute() > 9 && second() < 10) {
      text(hour() + ":" + minute() + ":" + "0" + second(), 0, 220)
    } else {
      text("ERROR", 0, 240)
    }
  } else {
    if (minute() < 10 && second() > 9) {
      text(hour() - 12 + ":" + "0" + minute() + ":" + second(), 0, 220)
    } else if (minute() < 10 && second() < 10) {
      text(hour() - 12 + ":" + "0" + minute() + ":" + "0" + second(), 0, 220)
    } else if (minute() > 9 && second() > 9) {
      text(hour() - 12 + ":" + minute() + ":" + second(), 0, 220)
    } else if (minute() > 9 && second() < 10) {
      text(hour() - 12 + ":" + minute() + ":" + "0" + second(), 0, 220)
    } else {
      text("ERROR", 0, 240)
    }
  }
  if (hour() < 12) {
    text("a.m.", 0, 245)
  } else {
    text("p.m.", 0, 245)
  }

  text(month() + "/" + day() + "/" + year(), 0, 280)

  if (hour() == 8 && minute() >= 10 && minute() <= 48) {
    textSize(25)
    text("Current Class", 300, -140)
    text("AG", 300, -100)
    text("Started 8:10", 300, -60)
    text("Ends 8:48", 300, -20)

    text("Next Class", 300, 40)
    text("S.S.", 300, 80)
    text("Starts 8:50", 300, 120)
    
    text("Time Left:", 300, 180)
    text((48 - minute()) + " minute(s)", 300, 220)
  } else if (hour() == 8 && minute() >= 50 || hour() == 9 && minute() <= 28) {
    textSize(25)
    text("Current Class", 300, -140)
    text("S.S.", 300, -100)
    text("Started 8:50", 300, -60)
    text("Ends 9:28", 300, -20)

    text("Next Class", 300, 40)
    text("P.E.", 300, 80)
    text("Starts 9:30", 300, 120)

    text("Time Left:", 300, 180)
    if (hour() == 8) {
      text(88 - minute() + " minute(s)", 300, 220)
    } else if(hour() == 9){
      text(28 - minute() + " minute(s)", 300, 220)
    }
  } else if (hour() == 13 && minute() >= 20 && minute() <= 58) {
    textSize(25)
    text("Current Class", 300, -140)
    text("READING", 300, -100)
    text("Started 1:20", 300, -60)
    text("Ends 1:58", 300, -20)

    text("Next Class", 300, 40)
    text("SCHOOL ENDS", 300, 80)
    text("1:58", 300, 120)

    text("Time Left:", 300, 180)
    text((58 - minute()) + " minute(s)", 300, 220)
  } else if (hour() == 12 && minute() >= 40 || hour() == 13 && minute() <= 18) {
    textSize(25)
    text("Current Class", 300, -140)
    text("STUDY HALL", 300, -100)
    text("Started 12:40", 300, -60)
    text("Ends 1:18", 300, -20)

    text("Next Class", 300, 40)
    text("READING", 300, 80)
    text("Starts 1:20", 300, 120)

    text("Time Left:", 300, 180)
    if (hour() == 13) {
      text(18 - minute() + " minute(s)", 300, 220)
    } else if(hour() == 12){
      text(78 - minute() + " minute(s)", 300, 220)
    }
  }
}

/*
---8:10-8:48    AG
---8:50-9:28    S.S.
9:30-10:08   P.E.
10:10-10:48  SCIENCE
10:50-11:28  MATH
11:30-11:58  LUNCH
12:00-12:38  ENGLISH
---12:40-1:18   STUDY HALL
---1:20-1:58    READING
*/