let mySize, tri_iter, square_iter, tree_iter, slider,c
function setup() {
  c = createCanvas(800, 800);
  translate(width/2,height/2)
  background(220);
  noFill()
  mySize = 1000
  tri_iter = 8
  square_iter = 6
  tree_iter = 4
  surpinski_square(-width/4,-height/4,mySize)
  surpinski_triangle(width/4,-height/4,2*mySize/3)
  translate(-width/4,1.5*height/4)
  tree(0,0,100,60,3)
}
function surpinski_triangle(x,y,size){
  if(size > mySize/pow(2,tri_iter)){
    size *= 0.5
    myTriangle(x,y,size)
    surpinski_triangle(x+size/4,y+size/4,size)
    surpinski_triangle(x-size/4,y+size/4,size)
    surpinski_triangle(x,y-size/4,size)
  }
}
function surpinski_square(x,y,size){
  rectMode(CENTER)
  if(size > mySize/pow(3,square_iter)){
    size *= 0.333
    rect(x,y,size)
    surpinski_square(x-size/3,y-size/3,size)
    surpinski_square(x,y-size/3,size)
    surpinski_square(x+size/3,y-size/3,size)
    surpinski_square(x-size/3,y,size)
    surpinski_square(x+size/3,y,size)
    surpinski_square(x-size/3,y+size/3,size)
    surpinski_square(x,y+size/3,size)
    surpinski_square(x+size/3,y+size/3,size)
  }
}
function myTriangle(x,y,size){
  triangle(x,y-size/2,x-size/2,y+size/2,x+size/2,y+size/2)
}
function tree(x,y,length,angle,prongs){
  if(length > 32/tree_iter){
    strokeWeight(length/15)
    length *= 0.75
    line(x,y,x,y-length)
    translate(0,-length)
    push()
    rotate(radians(angle*prongs/2))
    tree(x,y,length,angle,prongs)
    pop()
    push()
    rotate(radians(-angle*prongs/2))
    tree(x,y,length,angle,prongs)
    pop()
    if(prongs == 3){
      push()
      tree(x,y,length,angle,prongs)
      pop()
    }
  }
}