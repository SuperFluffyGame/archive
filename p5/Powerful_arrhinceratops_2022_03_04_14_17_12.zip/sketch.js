function setup() {
  createCanvas(400, 400);
  a = [[0,1],[2,3]]
}
let a
function draw() {
  background(220);
  console.log(a[-1][0])
  
}