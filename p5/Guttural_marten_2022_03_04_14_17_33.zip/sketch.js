let m
function setup() {
  m = new mover()
  createCanvas(400, 400);
  stroke(0)
  strokeWeight(1)
}

function draw() {
  background(220);
  translate(width/2,height/2)
  m.draw()
}
class mover {
  constructor(){
    this.pos = createVector(0,0)
    this.vel = createVector(0,0)
    this.acc = createVector(0,0)
  }
  draw(){
    let c = 0.03
    this.friction = this.vel
    this.friction.mult(-1);
    this.friction.normalize();
    this.friction.mult(c);
    rectMode(CENTER)
    rect(this.pos.x,this.pos.y,10)
    
    
    if(keyIsDown(87)){
      this.acc.add(0,-0.05)
    }
    if(keyIsDown(83)){
      this.acc.add(0,0.05)
    }
    if(keyIsDown(68)){
      this.acc.add(this.vel.y,-this.vel.x)
    }
    this.acc.add(this.friction)
    this.vel.add(this.acc)
    this.vel.limit(4)
    this.pos.add(this.vel)
  }
}