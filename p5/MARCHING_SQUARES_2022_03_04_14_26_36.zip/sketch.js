let size = 10
let scale1 = 0.1 //0.08
let scale2 = 1.1
let offset = 0
let noiseOffset = {x: 0, y: 0}
let landColor = 'green'
let seaColor = 'blue'
let renderer
let shapeLookupTable = {
  '0,0,0,0': 0,
  '1,0,0,0': [{points:[[0,0.5],[0.5,0],[0,0]],color:landColor},
             {points:[[0,0.5],[0.5,0],[1,0],[1,1],[0,1]],color:seaColor}],
  '0,1,0,0':
             [{points:[[1,0.5],[0.5,0],[1,0]],color:landColor},
             {points:[[0.5,0],[1,0.5],[1,1],[0,1],[0,0]],color:seaColor}],

  '0,0,1,0':
       [{points:[[1,0.5],[0.5,1],[1,1]],color:landColor},
              {points:[[1,0.5],[0.5,1],[0,1],[0,0],[1,0]],color:seaColor}],
 
  '0,0,0,1':
       [{points:[[0,0.5],[0.5,1],[0,1]],color:landColor},
              {points:[[0,0.5],[0.5,1],[1,1],[1,0],[0,0]],color:seaColor}],
 
  '1,1,0,0':
       [{points:[[0,0.5],[1,0.5],[1,0],[0,0]],color:landColor},
              {points:[[0,0.5],[1,0.5],[1,1],[0,1]],color:seaColor}],

      
  '1,0,1,0':
       [{points:[[0,0],[0.5,0],[0,0.5]],color:landColor},
              {points:[[1,1],[0.5,1],[1,0.5]],color:landColor},
              {points:[[0.5,0],[1,0],[1,0.5],[0.5,1],[0,1],[0,0.5]],color:seaColor}],
 
  '1,0,0,1':
       [{points:[[0.5,0],[0.5,1],[0,1],[0,0]],color:landColor},
              {points:[[0.5,0],[0.5,1],[1,1],[1,0]],color:seaColor}],
    
  '0,1,1,0':
       [{points:[[0.5,0],[0.5,1],[1,1],[1,0]],color:landColor},
              {points:[[0.5,0],[0.5,1],[0,1],[0,0]],color:seaColor}],
     
  
  '0,1,0,1':
       [{points:[[1,0],[1,0.5],[0.5,0]],color:landColor},
              {points:[[0,1],[0,0.5],[0.5,1]],color:landColor},
              {points:[[0,0],[0.5,0],[1,0.5],[1,1],[0.5,1],[0,0.5]],color:seaColor}],
      
  '0,0,1,1':
             [{points:[[0,0.5],[1,0.5],[1,1],[0,1]],color:landColor},
             {points:[[0,0.5],[1,0.5],[1,0],[0,0]],color:seaColor}],
    
  '1,1,1,0':
             [{points:[[0,0.5],[0.5,1],[1,1],[1,0],[0,0]],color:landColor},
             {points:[[0,0.5],[0.5,1],[0,1]],color:seaColor}],
    
  '1,1,0,1':
             [{points: [[1,0.5],[0.5,1],[0,1],[0,0],[1,0]],color:landColor},
             {points:[[1,0.5],[0.5,1],[1,1]],color:seaColor}],
    
  '1,0,1,1':
             [{points: [[0.5,0],[1,0.5],[1,1],[0,1],[0,0]],color:landColor},
             {points:[[1,0.5],[0.5,0],[1,0]],color:seaColor}],
   
  '0,1,1,1': 
             [{points:[[0,0.5],[0.5,0],[1,0],[1,1],[0,1]],color:landColor},
             {points:[[0,0.5],[0.5,0],[0,0]],color:seaColor}],
   
  '1,1,1,1':1
}
let seed = 1
let walkSpeed = 0.2
function preload(){
  arial = loadFont('ARI.ttf')
}
function setup() {
  renderer = P2D
  createCanvas(400, 400,renderer);
  textFont('Helvetica')
  //noiseSeed(seed)
  noiseDetail(4,0.44)
  grid = createGrid(width/size+1,height/size+1,'perlin')
  strokeWeight(2)
  textAlign(LEFT,TOP)
  frameRate(144)
  textFont(arial)
}
let grid
function draw() {
  //grid = createGrid(width/size+1,height/size+1,'perlin')
  if(renderer == WEBGL)
  translate(-width/2,-height/2)
  background(220);
  strokeWeight(1)
  marchShape(grid,size,offset)
  marchLine(grid,size,offset)
  //drawGrid(grid,size,offset)
  textSize(20)
  fill('red')
  text(round(frameRate()),0,0)
  if(keyIsDown(87)){
    noiseOffset.y -= walkSpeed
  }
  if(keyIsDown(83)){
    noiseOffset.y += walkSpeed
  }
  if(keyIsDown(65)){
    noiseOffset.x -= walkSpeed
  }
  if(keyIsDown(68)){
    noiseOffset.x += walkSpeed
  }
}
function createGrid(sizeX,sizeY,type){
  let out = []
  for(let i = 0; i < sizeY; i++){
    out.push([])
    for(let j = 0; j < sizeX; j++){
      if(type == 'random'){
        out[i].push(round(random()))
      }else if(type == 'perlin'){
        out[i].push(round(noise(i*scale1+noiseOffset.x,j*scale1+noiseOffset.y)*scale2))
      }
    }
  }
  return out
}
function drawGrid(grid,mult,offset){
  for(let i = 0; i < grid.length; i ++){
    for(let j = 0; j < grid[0].length; j++){
      strokeWeight((grid[i][j]+2))
      point(i*mult+offset,j*mult+offset)
    }
  }
}
function getPermutationLine(array){
  let stringy = String(array)
  //top left, top right, bottom right, bottom left
  switch(stringy) {
    case '0,0,0,0':
      return 0
      break;
    case '1,0,0,0':
      return [[0,0.5,0.5,0]]
      break;  
    case '0,1,0,0':
      return [[1,0.5,0.5,0]]
      break;  
    case '0,0,1,0':
      return [[1,0.5,0.5,1]]
      break; 
    case '0,0,0,1':
      return [[0,0.5,0.5,1]]
      break;  
    case '1,1,0,0':
      return [[0,0.5,1,0.5]]
      break;  
    case '1,0,1,0':
      return [[0,0.5,0.5,0],[0.5,1,1,0.5]]
      break;  
    case '1,0,0,1':
      return [[0.5,0,0.5,1]]
      break; 
    case '0,1,1,0':
      return [[0.5,0,0.5,1]]
      break;  
    case '0,1,0,1':
      return [[0,0.5,0.5,1],[0.5,0,1,0.5]]
      break; 
    case '0,0,1,1':
      return [[0,0.5,1,0.5]]
      break;
    case '1,1,1,0':
      return [[0,0.5,0.5,1]]
      break;
    case '1,1,0,1':
      return [[1,0.5,0.5,1]]
      break;
    case '1,0,1,1':
      return [[0.5,0,1,0.5]]
      break;
    case '0,1,1,1':
      return [[0,0.5,0.5,0]]
      break;
    case '1,1,1,1':
      return 0
      break;
  }
}
function marchLine(grid,mult,offset){
  stroke(0)
  strokeWeight(2)
  for(let i = 0; i<grid.length-1; i++){
    for(let j = 0; j < grid[0].length-1; j++){
      let thing = [grid[i][j],
                                 grid[i+1][j],
                                 grid[i+1][j+1],
                                 grid[i][j+1]]
      let perm = getPermutationLine(thing)
      if(perm != 0){
        for(let k = 0; k < perm.length; k++){
          line((i*mult)+(perm[k][0]*mult)+offset,
               (j*mult)+(perm[k][1]*mult)+offset,
               (i*mult)+(perm[k][2]*mult)+offset,
               (j*mult)+(perm[k][3]*mult)+offset)
        }
      }
    }
  }
}
function getPermutationShape(array){
  let stringy = String(array)
  //top left, top right, bottom right, bottom left
  switch(stringy) {
    case '0,0,0,0':
      return 0
      break;
    case '1,0,0,0':
      return [{points:[[0,0.5],[0.5,0],[0,0]],color:landColor},
              {points:[[0,0.5],[0.5,0],[1,0],[1,1],[0,1]],color:seaColor}]
      break;  
    case '0,1,0,0':
      return [{points:[[1,0.5],[0.5,0],[1,0]],color:landColor},
              {points:[[0.5,0],[1,0.5],[1,1],[0,1],[0,0]],color:seaColor}]
      break;  
    case '0,0,1,0':
      return [{points:[[1,0.5],[0.5,1],[1,1]],color:landColor},
              {points:[[1,0.5],[0.5,1],[0,1],[0,0],[1,0]],color:seaColor}]
      break; 
    case '0,0,0,1':
      return [{points:[[0,0.5],[0.5,1],[0,1]],color:landColor},
              {points:[[0,0.5],[0.5,1],[1,1],[1,0],[0,0]],color:seaColor}]
      break;  
    case '1,1,0,0':
      return [{points:[[0,0.5],[1,0.5],[1,0],[0,0]],color:landColor},
              {points:[[0,0.5],[1,0.5],[1,1],[0,1]],color:seaColor}]
      break;  
      //
    case '1,0,1,0':
      return [{points:[[0,0],[0.5,0],[0,0.5]],color:landColor},
              {points:[[1,1],[0.5,1],[1,0.5]],color:landColor},
              {points:[[0.5,0],[1,0],[1,0.5],[0.5,1],[0,1],[0,0.5]],color:seaColor}]
      break;  
    case '1,0,0,1':
      return [{points:[[0.5,0],[0.5,1],[0,1],[0,0]],color:landColor},
              {points:[[0.5,0],[0.5,1],[1,1],[1,0]],color:seaColor}]
      break; 
    case '0,1,1,0':
      return [{points:[[0.5,0],[0.5,1],[1,1],[1,0]],color:landColor},
              {points:[[0.5,0],[0.5,1],[0,1],[0,0]],color:seaColor}]
      break;  
      //
    case '0,1,0,1':
      return [{points:[[1,0],[1,0.5],[0.5,0]],color:landColor},
              {points:[[0,1],[0,0.5],[0.5,1]],color:landColor},
              {points:[[0,0],[0.5,0],[1,0.5],[1,1],[0.5,1],[0,0.5]],color:seaColor}]
      break; 
    case '0,0,1,1':
      return [{points:[[0,0.5],[1,0.5],[1,1],[0,1]],color:landColor},
              {points:[[0,0.5],[1,0.5],[1,0],[0,0]],color:seaColor}]
      break;
    case '1,1,1,0':
      return [{points:[[0,0.5],[0.5,1],[1,1],[1,0],[0,0]],color:landColor},
              {points:[[0,0.5],[0.5,1],[0,1]],color:seaColor}]
      break;
    case '1,1,0,1':
      return [{points:[[1,0.5],[0.5,1],[0,1],[0,0],[1,0]],color:landColor},
              {points:[[1,0.5],[0.5,1],[1,1]],color:seaColor}]
      break;
    case '1,0,1,1':
      return [{points:[[0.5,0],[1,0.5],[1,1],[0,1],[0,0]],color:landColor},
              {points:[[1,0.5],[0.5,0],[1,0]],color:seaColor}]
      break;
    case '0,1,1,1':
      return [{points:[[0,0.5],[0.5,0],[1,0],[1,1],[0,1]],color:landColor},
              {points:[[0,0.5],[0.5,0],[0,0]],color:seaColor}]
      break;
    case '1,1,1,1':
      return 1
      break;
  }
}
function marchShape(grid,mult,offset){
  noStroke()
  for(let i = 0; i<grid.length-1; i++){
    for(let j = 0; j < grid[0].length-1; j++){
      let thing = [grid[i][j],
                                 grid[i+1][j],
                                 grid[i+1][j+1],
                                 grid[i][j+1]]
      let perm = shapeLookupTable[thing]
      //let perm = getPermutationShape(thing)
      if(perm != 0 && perm != 1){
        for(let k = 0; k < perm.length; k++){
          fill(perm[k].color)
          beginShape()
          for(let l = 0; l < perm[k].points.length; l++){
            vertex((i*mult)+(perm[k].points[l][0]*mult)+offset,
                   (j*mult)+(perm[k].points[l][1]*mult)+offset)
          }
          vertex((i*mult)+(perm[k].points[0][0]*mult)+offset,
                 (j*mult)+(perm[k].points[0][1]*mult)+offset)
          endShape(CLOSE)
        }
      }else if(perm == 1){
        fill(landColor)
        beginShape()
        vertex((i*mult)+offset,(j*mult)+offset)
        vertex((i*mult)+mult+offset,(j*mult)+offset)
        vertex((i*mult)+mult+offset,(j*mult)+mult+offset)
        vertex((i*mult)+offset,(j*mult)+mult+offset)
        vertex((i*mult)+offset,(j*mult)+offset)
        endShape(CLOSE)
      }else if(perm == 0){
        fill(seaColor)
        beginShape()
        vertex((i*mult)+offset,(j*mult)+offset)
        vertex((i*mult)+mult+offset,(j*mult)+offset)
        vertex((i*mult)+mult+offset,(j*mult)+mult+offset)
        vertex((i*mult)+offset,(j*mult)+mult+offset)
        vertex((i*mult)+offset,(j*mult)+offset)
        endShape(CLOSE)
      }
    }
  }
}
