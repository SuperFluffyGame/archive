function setup() {
  createCanvas(400, 400);
}
function draw() {
  background(220);
  (mouseX < mouseY) ? 
    (()=>{line(0,0,mouseX,mouseY);line(20,20,30,30)})(): 
    line(mouseX,mouseY,400,400)
}
function clampNegative(n){
  return (n > 0) ? n : 0;

}