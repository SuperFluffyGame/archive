let sa
let b
let button
let button2
let t = 0
let f = 0
function setup() {
  createCanvas(600, 400);
  sa = createSlider(2, 601, 101)
  sa.size(600)
  button = createButton("Theme")
  button2= createButton("FullScreen")
  button.mousePressed(theme)
  button2.mousePressed(fullScreen2)
  button.position(width-90,120)
  button2.position(width-100,160)
  sa.position(0,height-25)
  rectMode(CENTER)
  colorMode(HSB)
  noStroke(0)
  textAlign(CENTER)
}

function draw() {
  a = sa.value()
  if(t % 2 == 0){
    background(0)
    fill(255)
  } else{
    background(255)
    fill(0)   
  }
  
  textSize(20)
  text("Framerate:", width - 60, 80)
  text(round(frameRate(), 1), width - 60, 100)
  text("Resolution:", width - 60, 20)
  text(a - 1, width - 85, 40)
  text("x", width - 60, 40)
  text(a - 1, width - 35, 40)
  text((a - 1) * (a - 1), width - 60, 60)
  
  b = height / a
  for (let i = 1; i < a; i++) {
    for (let j = 1; j < a; j++) {
      fill((j%i)/(i%j)*75, 100, 100)
      rect((j * b), (i * b), b)
    }
  }
}
function theme(){
  t++
}
function fullScreen2(){
  f++
  if(f % 2 == 0){
    fullscreen(0)
    createCanvas(600,400)
    button.position(width-90,120)
    button2.position(width-100,160)
    sa.position(0,height-25)
    sa.size(width)
  } else{
    fullscreen(1)
    createCanvas(displayWidth,displayHeight)
    button.position(width-90,120)
    button2.position(width-100,160)
    sa.position(0,height-25)
    sa.size(width)
  }
}