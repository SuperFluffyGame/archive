let mousePos = {x:0,y:0}


function main(){
  let geometry = [
    Triangle([
       0.5,  0.5,
      -0.5,  0.5,
      -0.5, -0.5
    ])
  ]
  render(geometry)
  requestAnimationFrame(main)
}
window.onload = main
document.addEventListener('mousemove',(e)=>{
  mousePos = {
    x: e.x/240,
    y: e.y/240
  }
})

function render(geo){
  const canvas = document.getElementById('canvas')
  const gl = canvas.getContext('webgl')
  
  let program = initShaderProgram(gl,vSource,fSource)
  let programInfo = {
    program,
    aLocations: {
      VertPos: gl.getAttribLocation(program,"aVertPos"),
      VertColor: gl.getAttribLocation(program,"aVertColor")
    },
    uLocations: {
    
    }
  }
  
  gl.clearColor(0.0,0.0,0.0,1.0)
  gl.clear(gl.COLOR_BUFFER_BIT)
  
  let buffers = initBuffers(gl,geo)
  gl.bindBuffer(gl.ARRAY_BUFFER,buffers.position)
  
  gl.vertexAttribPointer(
    programInfo.aLocations.VertPos,
    2,gl.FLOAT,false,0,0
  )
  
  gl.enableVertexAttribArray(programInfo.aLocations.VertPos)
  
  
  gl.bindBuffer(gl.ARRAY_BUFFER,buffers.color)
  
  gl.vertexAttribPointer(
    programInfo.aLocations.VertColor,
    4,gl.FLOAT,false,0,0
  )
  
  gl.enableVertexAttribArray(programInfo.aLocations.VertColor)
  
  gl.useProgram(programInfo.program)
  
  gl.drawArrays(gl.TRIANGLES, 0,3);
}
function initShaderProgram(gl, vsSource, fsSource) {
  const vertexShader = loadShader(gl, gl.VERTEX_SHADER, vsSource);
  const fragmentShader = loadShader(gl, gl.FRAGMENT_SHADER, fsSource);

  const shaderProgram = gl.createProgram();
  gl.attachShader(shaderProgram, vertexShader);
  gl.attachShader(shaderProgram, fragmentShader);
  gl.linkProgram(shaderProgram);

  if (!gl.getProgramParameter(shaderProgram, gl.LINK_STATUS)) {
    console.warn('Unable to initialize the shader program: ' + gl.getProgramInfoLog(shaderProgram));
    return null;
  }

  return shaderProgram;
}
function loadShader(gl, type, source) {
  const shader = gl.createShader(type);

  gl.shaderSource(shader, source);

  gl.compileShader(shader);

  if (!gl.getShaderParameter(shader, gl.COMPILE_STATUS)) {
    console.warn('An error occurred compiling the shaders: ' + gl.getShaderInfoLog(shader));
    gl.deleteShader(shader);
    return null;
  }

  return shader;
}
function initBuffers(gl,geo) {

  let positions = []
  let colors = []
  geo.forEach((e)=>{
    positions.push(...e.vertices)
    colors.push(...e.color)
  })
  const positionBuffer = gl.createBuffer()
  gl.bindBuffer(gl.ARRAY_BUFFER, positionBuffer)
  gl.bufferData(gl.ARRAY_BUFFER, new Float32Array(positions), gl.STATIC_DRAW)
  
  const colorBuffer = gl.createBuffer()
    gl.bindBuffer(gl.ARRAY_BUFFER, colorBuffer)
    gl.bufferData(gl.ARRAY_BUFFER, new Float32Array(colors), gl.STATIC_DRAW)
  
  

  return {
    position: positionBuffer,
    color: colorBuffer
  }
}