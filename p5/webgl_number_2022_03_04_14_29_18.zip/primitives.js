function Triangle(verts,colors=[1,1,1,1]){
  return {
    vertices: verts,
    color: colors
  }
}