let k0, k1, k2, k3, k4, k5, k6, k7, k8, k9
let enter, clear, backs
let keyButtons = [k1, k2, k3, k4, k5, k6, k7, k8, k9, k0]
let current1 = 0
let current2 = 0
let out = 0
let oper = null
let mult, sub, add, div

function setup() {
  createCanvas(375, 450);
  enter = createButton('&check;')
  enter.id(10)
  clear = createButton('CA')
  clear.id(11)
  add = createButton('+')
  add.id(12)
  sub = createButton('-')
  sub.id(13)
  mult = createButton('×')
  mult.id(14)
  div = createButton('÷')
  div.id(15)
  backs = createButton('&larr;')
  backs.id(16)
  for (i = 0; i < keyButtons.length; i++) {
    keyButtons[i] = createButton(i)
    keyButtons[i].id(i)
  }
  style()
}

function draw() {
  background(0);

  fill('darkcyan')
  stroke(0)
  strokeWeight(5)
  rect(0,50,375,100)
  fill('darkslategrey')
  rect(0,0,375,50)
  strokeWeight(2)
  textAlign(CENTER, CENTER)
  fill(255)
  textSize(40)
  if (oper == 1) {
    text(current1 + '+' + current2, width / 2, 100)
  } else if (oper == 2) {
    text(current1 + '-' + current2, width / 2, 100)
  } else if (oper == 3) {
    text(current1 + '×' + current2, width / 2, 100)
  } else if (oper == 4) {
    text(current1 + '÷' + current2, width / 2, 100)
  } else {
    text(current1, width / 2, 100)
  }
  textAlign(RIGHT, CENTER)
  textSize(25)
  text('Answer: ' + out, width - 10, 25)
  mouse(enter)
  mouse(clear)
  mouse(add)
  mouse(sub)
  mouse(mult)
  mouse(div)
  mouse(backs)
  for (i = 0; i < keyButtons.length; i++) {
    mouse(keyButtons[i])
  }
}

function style() {
  enter.position(width - 75, height - 150)
  enter.style('border : 5px solid white')
  enter.style('background : blue')
  enter.style('font-size: 4em')
  enter.size(75, 150)

  add.position(width - 150, height - 300)
  add.style('border : 5px solid white')
  add.style('background : blue')
  add.style('font-size: 4em')
  add.size(75, 75)

  sub.position(width - 150, height - 225)
  sub.style('border : 5px solid white')
  sub.style('background : blue')
  sub.style('font-size: 4em')
  sub.size(75, 75)

  mult.position(width - 150, height - 150)
  mult.style('border : 5px solid white')
  mult.style('background : blue')
  mult.style('font-size: 4em')
  mult.size(75, 75)

  div.position(width - 150, height - 75)
  div.style('border : 5px solid white')
  div.style('background : blue')
  div.style('font-size: 4em')
  div.size(75, 75)

  clear.position(width - 75, height - 300)
  clear.style('border : 5px solid white')
  clear.style('background : blue')
  clear.style('font-size: 2em')
  clear.size(75, 75)
  for (i = 0; i < keyButtons.length; i++) {
    keyButtons[i].style('border : 5px solid white')
    keyButtons[i].style('background : blue')
    keyButtons[i].style('font-size : 3em')
    keyButtons[i].size(75, 75)
  }
  for (i = 0; i < 3; i++) {
    for (j = 1; j < 4; j++) {
      keyButtons[(i * 3) + (j - 1) + 1].position(75 * (j - 1), 75 * (i) + 150)
    }
  }
  keyButtons[0].position(75, 375)
}

function mouse(thing) {
  thing.mouseOver(back)
  thing.mouseOut(oback)
  thing.mousePressed(cback)
  thing.mouseReleased(back)
}

function back() {
  this.style('background : rgb(0,0,215)')
  this.style('border : 5px solid white')

}

function oback() {
  this.style('background : blue')
  this.style('border : 5px solid white')
}

function cback() {
  this.style('background : darkblue')
  this.style('border : 5px solid lightgray')
  if (this.id() == 10) {
    if (oper == 1) {
      out = current1 + current2
    } else if (oper == 2) {
      out = current1 - current2
    } else if (oper == 3) {
      out = current1 * current2
    } else if (oper == 4) {
      out = current1 / current2
    } else {
      out = 'error'
    }
    current1 = out
    oper = null
    current2 = 0
  } else if (this.id() == 11) {
    current1 = 0;
    oper = null
  } else if (oper == null && this.id() < 10 && textWidth(current1) < width - 160) {
    current1 = current1 * 10 + int(this.id())
  } else if (oper != null && this.id() < 10 && textWidth(current2) < width - 160) {
    current2 = current2 * 10 + int(this.id())
  } else if (this.id() == 12) {
    oper = 1
  } else if (this.id() == 13) {
    oper = 2
  } else if (this.id() == 14) {
    oper = 3
  } else if (this.id() == 15) {
    oper = 4
  }
}