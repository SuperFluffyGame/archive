let boardSize = 3;
let numInRowRequired = 3
let boardTiles = [];
let currentPlayer = 1 // 1 == X    2 == O
let winner = {state: 0};

function setup() {
  createCanvas(400, 400);
  textAlign(CENTER,CENTER);
  textSize(40);
  
  spacing = min(width,height) / (boardSize + 1)
  let border = [1,1,1,1];
  for(let i = 0; i < boardSize; i ++){
    for(let j = 0; j < boardSize; j++){
      
      let border = [1,1,1,1];
      
      if(j == 0){border[0] = 0}
      if(i == 0){border[3] = 0}
      if(j == boardSize-1){border[2] = 0}
      if(i == boardSize-1){border[1] = 0}
      
      boardTiles.push(new TicTacSquare(spacing*i+spacing/2,spacing*j+spacing/2,spacing,border))
      
    }
  }
}

function draw() {
  background(220);
  stroke(0)
  strokeWeight(2)
  for(let elem of boardTiles){
    elem.show();
  }
  checkWin()
  if(winner.state != 0){

    fill('gold')
    text(winner.letter + " has Won!",width/2,height-20)
    
    stroke('#029000')
    strokeWeight(10)
    if(winner.winAs == "column"){
      line(winner.num*spacing+spacing,
           spacing/1.5+spacing*winner.startEnd.s-spacing,
           winner.num*spacing+spacing,
           spacing-spacing/1.5+spacing*(winner.startEnd.e)-spacing)
    }else if(winner.winAs == "row"){
      line(spacing/1.5+spacing*winner.startEnd.s-spacing,
           winner.num*spacing+spacing,
           spacing-spacing/1.5+spacing*(winner.startEnd.e)-spacing,
           winner.num*spacing+spacing)
    }
  }
}
function checkWin(){
  let numXinColumn = 0
  let numOinColumn = 0
  let numXinRow = 0
  let numOinRow = 0
  for(let i = 0; i < boardSize; i++){
    //column checking
    numXinColumn = 0;
    numOinColumn = 0;
    for(let j = 0; j < boardSize; j++){
      if(getArr(boardTiles,i,j,boardSize).state == 1){
        numXinColumn ++
        numOinColumn = 0
      }
      else if(getArr(boardTiles,i,j,boardSize).state == 2){
        numOinColumn ++
        numXinColumn = 0
      }else if(getArr(boardTiles,i,j,boardSize).state == 0){
        numOinColumn = 0
        numXinColumn = 0
      }
      if(numXinColumn == numInRowRequired){
        winner = {state: 1,
                  winAs: 'column',
                  num: i,
                  letter: "X",
                  startEnd: {s: j-(numInRowRequired-2), e: j-(numInRowRequired-2)+numXinColumn}}
      }
      else if(numOinColumn == numInRowRequired){
        winner = {state: 2, 
                  winAs: 'column',
                  num: i,
                  letter: "O",
                  startEnd: {s: j-(numInRowRequired-2), e: j-(numInRowRequired-2)+numOinColumn}}
      }
    }
  }
  for(let i = 0; i < boardSize; i++){
    //row checking
    numXinRow = 0;
    numOinRow = 0;
    for(let j = 0; j < boardSize; j++){
      if(getArr(boardTiles,j,i,boardSize).state == 1){
        numXinRow ++
        numOinRow = 0
      }
      else if(getArr(boardTiles,j,i,boardSize).state == 2){
        numOinRow ++
        numXinRow = 0
      }else if(getArr(boardTiles,j,i,boardSize).state == 0){
        numOinRow = 0
        numXinRow = 0
      }
      if(numXinRow == numInRowRequired){
        winner = {state: 1,
                  winAs: 'row',
                  num: i,
                  letter: "X",
                  startEnd: {s: j-(numInRowRequired-2), e: j-(numInRowRequired-2)+numXinRow}}
      }
      else if(numOinRow == numInRowRequired){
        winner = {state: 2, 
                  winAs: 'row',
                  num: i,
                  letter: "O",
                  startEnd: {s: j-(numInRowRequired-2), e: j-(numInRowRequired-2)+numOinRow}}
      }
    }
  }
  
  //diagnal checking
  let numXinDiagRight1 = 0
  let numOinDiagRight1 = 0
  for(let i = 0; i < boardSize; i++){
    for(let j = 0; j < (boardSize-i); j++){
      let a = getArr(boardTiles,j,j+i,boardSize)
      if(a.state == 1){
        numXinDiagRight1++
        numOinDiagRight1 = 0
      }else if(a.state == 2){
        numOinDiagRight1++
        numXinDiagRight1 = 0
      }else if(a.state == 0){
        numXinDiagRight1 = 0
        numOinDiagRight1 = 0
      }
      if(numXinDiagRight1 == numInRowRequired){
        winner = {state: 1, 
                  winAs: 'diagnalR1',
                  num: i,
                  letter: "X",
                  startEnd: {s: j-(numInRowRequired-2), 
                             e: j-(numInRowRequired-2)+numOinRow}}      
      }
    }
  }
  
  
  //no winner checking
  let filledTiles = 0
  for(let i = 0; i < boardTiles.length; i++){
    if(boardTiles[i].state != 0){
      filledTiles ++
    }
  }
  if(filledTiles == boardTiles.length && 
     (winner.state == 0 || winner.state == -1) ){
        winner = {state: -1, 
                  letter: "No one",
                 }
  }
}
class TicTacSquare{
  constructor(x,y,size,borders){
    this.x = x;
    this.y = y;
    this.size = size;
    this.borders = borders;
    this.state = 0;
    document.addEventListener('click',()=>{
      if(this.state == 0 && 
         pointHitRect(this.x,this.y,this.size,this.size,mouseX,mouseY) &&
         winner.state == 0){
        this.state = currentPlayer
        if(currentPlayer == 1){currentPlayer = 2}
        else if(currentPlayer == 2){currentPlayer = 1}
      }
    })
  }
  show(){
    customRect(this.x,this.y,this.size,this.size,this.borders)
    
    if(this.state == 1){
      line(this.x+this.size/10,
           this.y+this.size/10,
           this.x+this.size-this.size/10,
           this.y+this.size-this.size/10)
      line(this.x+this.size-this.size/10,
           this.y+this.size/10,
           this.x+this.size/10,
           this.y+this.size-this.size/10)
    }else if(this.state == 2){
      noFill()
      circle(this.x+this.size/2,this.y+this.size/2,this.size-this.size/5)
    }
  }
}
function customRect(x,y,sx,sy,b){
  if(b[0])
  line(x,y,x+sx,y)
  if(b[1])
  line(x+sx,y,x+sx,y+sy)
  if(b[2])
  line(x,y+sy,x+sx,y+sy)
  if(b[3])
  line(x,y,x,y+sy)

}
function pointHitRect(rectX,rectY,rectSX,rectSY,pointX,pointY){
  if(pointX > rectX && pointX < rectX+rectSX &&
     pointY > rectY && pointY < rectY+rectSY){
    return true
  }
  return false;
}
function getArr(arr,x,y,width){
  return arr[y + x*width]
}