let fr = 60
function setup() {
  createCanvas(400, 400);
  frameRate(fr)
  textSize(20)
  textAlign(LEFT,TOP)
  fill(0)
  strokeWeight(4)
  rectMode(CORNERS)
}
let frameArr = []
function draw() {
  background(220);
  frameArr.unshift(frameRate())
  if(frameArr.length > 80){
    frameArr.pop()
  }
  noStroke()
  text(round(framerate),0,0)
  text(round(frameRate()),0,20)
  for(let i = 0; i < frameArr.length; i++){
    if(frameArr[i] - fr < 5 && frameArr[i] - fr > -5){
       stroke('green')
    }else{
      stroke('red')
    }
    rect(width - i*5, height/2, width- i*5, 
         height/2 - (frameArr[i] - fr)*2)
  }
}




let framerate = 0
let frameRateArr = []
let out = 0
function myFrameRate(){
  if(frameRateArr.length <= 60){
    frameRateArr.push(frameRate())
    requestAnimationFrame(myFrameRate)
  }else{
    for(let i = 0; i < frameRateArr.length; i++){
      out += frameRateArr[i]
    }
    framerate = out/60
    out = 0
    frameRateArr = []  
  }
}
setInterval(myFrameRate,1000)