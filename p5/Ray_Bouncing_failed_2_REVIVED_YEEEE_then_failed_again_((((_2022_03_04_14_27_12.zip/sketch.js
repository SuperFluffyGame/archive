let ray1
let ray2
let bRay
let caster
let globalObsticles


let fov = 60
let density = 2
let length = 125
let keys = {
  "W": 87,
  "A": 65,
  "S": 83,
  "D": 68,
  "SPACE": 32,
  "SHIFT": 16
}
function setup() {
  createCanvas(800, 400);
  frameRate(144)
  ray1 = new Ray(createVector(10,0),radians(40),400)
  ray2 = new Ray(createVector(200,120),radians(-20),200)
  
  globalObsticles = [ray1,ray2]
  
  bRay = new bouncingRay(createVector(100,100),radians(50),10,globalObsticles)
  
  caster = new RayCasterNormal(createVector(200,200),fov,density,0,length,globalObsticles)
}
function fram(){stroke(0);textSize(15);textAlign(LEFT,TOP);text(round(frameRate()),0,0)}
function draw() {
  background(220);
  scale(0.1)
  // translate(10000,1000)
  strokeWeight(1)
  // //ray1.angle = atan2(mouseX,mouseY)
  //   ray1.mag = ray1.originalMag
  // if(ray1.intersects(ray2)){
  //   let intAt = ray1.intersectsAt(ray2)
  //   let intNegDist = ray1.mag - intAt.mag()
  //   let intPosDist = ray1.mag - intNegDist
  //   ray1.mag = sqrt(intAt.x**2+intAt.y**2)
  //   let ray3 = new Ray(intAt,-ray1.angle+2*ray2.angle,intNegDist)
  //   ray3.show()
  // }
  
  
  ray1.show()
  ray2.show()
  // bRay.angle = atan2(mouseX-bRay.origin.x,mouseY-bRay.origin.y)
  // bRay.show()
  
  //caster.pos = createVector(mouseX,mouseY)
  caster.draw(createVector(400,0))
  
  // strokeWeight(4)
  // stroke(0)
  // line(400,0,400,400)
  // noStroke()
  // fill(220)
  // rect(400,0,800,400)
  fram();
  if(keyIsDown(keys.A)){
    caster.globalAngle++
  }
  if(keyIsDown(keys.D)){
    caster.globalAngle--
  }
  if(keyIsDown(keys.W)){
    caster.pos.x += sin(radians(caster.globalAngle+caster.fov/2))
    caster.pos.y += cos(radians(caster.globalAngle+caster.fov/2))
  }
  if(keyIsDown(keys.S)){
    caster.pos.x -= sin(radians(caster.globalAngle+caster.fov/2))
    caster.pos.y -= cos(radians(caster.globalAngle+caster.fov/2))
  }
}
class Ray{
  constructor(origin,angle,mag){
    this.origin = origin
    this.angle = angle
    this.originalMag = mag
    this.mag = mag
  }
  show(extraMagAtStart=0,extraMagAtEnd=0){
      polarLine(this.origin.x-extraMagAtStart*(sin(this.angle)),
                this.origin.y-extraMagAtStart*(cos(this.angle)),
                this.angle,this.mag+extraMagAtEnd)
  }
  getCoords(){
    return {p1: this.origin, 
            p2: createVector(this.origin.x+this.mag*sin(this.angle),
                             this.origin.y+this.mag*cos(this.angle))}
  }
  intersects(ray){
    let ray1coords = ray.getCoords()
    let thiscoords = this.getCoords()

    let x1 = floor(thiscoords.p1.x), x2 = floor(thiscoords.p2.x)
    let x3 = floor(ray1coords.p1.x),  x4 = floor(ray1coords.p2.x)
    let y1 = floor(thiscoords.p1.y),  y2 = floor(thiscoords.p2.y)
    let y3 = floor(ray1coords.p1.y),  y4 = floor(ray1coords.p2.y)
    let uA = ((x4-x3)*(y1-y3) - (y4-y3)*(x1-x3)) / ((y4-y3)*(x2-x1) - (x4-x3)*(y2-y1));
    let uB = ((x2-x1)*(y1-y3) - (y2-y1)*(x1-x3)) / ((y4-y3)*(x2-x1) - (x4-x3)*(y2-y1));
    
    if (uA >= 0 && uA <= 1 && uB >= 0 && uB <= 1) {
        return true;
    }
    return false;
  }
  intersectsAt(ray){
    let ray1coords = ray.getCoords()
    let thiscoords = this.getCoords()

    let x1 = floor(thiscoords.p1.x), x2 = floor(thiscoords.p2.x)
    let x3 = floor(ray1coords.p1.x),  x4 = floor(ray1coords.p2.x)
    let y1 = floor(thiscoords.p1.y),  y2 = floor(thiscoords.p2.y)
    let y3 = floor(ray1coords.p1.y),  y4 = floor(ray1coords.p2.y)
    let uA = ((x4-x3)*(y1-y3) - (y4-y3)*(x1-x3)) / ((y4-y3)*(x2-x1) - (x4-x3)*(y2-y1));
    let uB = ((x2-x1)*(y1-y3) - (y2-y1)*(x1-x3)) / ((y4-y3)*(x2-x1) - (x4-x3)*(y2-y1));
    
    let intersectionX = x1 + (uA * (x2-x1));
    let intersectionY = y1 + (uA * (y2-y1));
    return createVector(floor(intersectionX),floor(intersectionY))
  }
}
function polarLine(startX,startY,ang,mag){
  line(startX,startY,startX+mag*sin(ang),startY+mag*cos(ang))
}
class bouncingRay{
  constructor(origin,angle,bounces,obstacles){
    this.origin = origin
    this.angle = angle
    this.bounce = bounces
    this.rays = [new Ray(this.origin,this.angle,1000)]
    this.obstacles = obstacles
  }
  show(){
    this.rays = [new Ray(this.origin,this.angle,300)]
    let prevIntAt = createVector(this.origin.x,this.origin.y)
    for(let i = 0; i < this.bounce; i++){
      let bounced = false
      let intAt = createVector(1000,1000)
      let bouncedOn
      for(let j = 0; j < this.obstacles.length; j++){
        if(this.rays[i].intersects(this.obstacles[j])){
          if(this.rays[i].intersectsAt(this.obstacles[j]).mag() < intAt.mag()){
            intAt = this.rays[i].intersectsAt(this.obstacles[j])
            bouncedOn = this.obstacles[j]
            bounced = true
          }
        }
      }
      if(bounced == true){
        let ang = -this.rays[i].angle+2*bouncedOn.angle
        this.rays.push(
          new Ray(createVector(intAt.x+10*sin(ang),
                               intAt.y+10*cos(ang)),
                ang,300)
          )
        this.rays[i].mag = floor(sqrt((intAt.x-prevIntAt.x)**2+
                                      (intAt.y-prevIntAt.y)**2))-10
        prevIntAt = createVector(intAt.x,intAt.y)
      }else{
        break;
      }
    }
    this.rays.forEach((elem,index) => {
      if(index == 0){
        elem.show(0,10)
      }else{
        elem.show(10,10)
      }
      
    })
  }
}
class RayCasterNormal{
  constructor(pos,fov,density,startAngle,viewDist,obstacles){
    this.pos = pos
    this.fov = fov
    this.rayDensity = density
    this.rays = []
    this.globalAngle = startAngle
    this.obstacles = obstacles
    this.viewDist = viewDist
  }
  draw(offset){
    this.rays = []
    for(let i = 0; i < 360*this.rayDensity; i++){
      this.rays.push(new Ray(this.pos,radians(i/this.rayDensity),this.viewDist))
    }
    for(let i = this.globalAngle*this.rayDensity; i < this.fov*this.rayDensity+this.globalAngle*this.rayDensity; i++){
      let index = floor(i % (360*this.rayDensity))
      if(index < 0){index = 360*this.rayDensity+index}
      let closestIntersectPointMag = this.viewDist
      for(let j = 0; j < this.obstacles.length; j++){
        if(this.rays[index].intersects(this.obstacles[j])){
          let intAt = this.rays[index].intersectsAt(this.obstacles[j])
          if(sqrt((intAt.x-this.pos.x)**2+(intAt.y-this.pos.y)**2) < closestIntersectPointMag){
            closestIntersectPointMag = sqrt((intAt.x-this.pos.x)**2+(intAt.y-this.pos.y)**2)
          }
        }
      }
      
      this.rays[index].mag = closestIntersectPointMag
      //the 3d part
      //console.log(offset.x+index-this.globalAngle*this.rayDensity)
      noStroke()
      // let reIndex = (index-this.globalAngle)*400/this.fov*this.rayDensity
      let dist = (this.rays[index].mag)
      // if(dist != 0){
      //   dist /= 1*cos(-this.rays[index].angle+
      //             radians((this.globalAngle)+this.fov*this.rayDensity/2))
      // }
      //   rectMode(CENTER)
      //   fill(dist*2)
      //   rect(offset.x-reIndex+1*offset.x,
      //        200,
      //        400/(this.rayDensity*this.fov),
      //        dist*400/this.viewDist)S
      // */
      let reIndex = (index ) - (this.globalAngle % (360*this.rayDensity))
      if(reIndex < 0){
        reIndex = 360*this.rayDensity + reIndex
      }
      if(reIndex > 360*this.rayDensity){
        reIndex -= 360*this.rayDensity
      }
      if( reIndex > 360*this.rayDensity){console.log("OVER BAD")}
      if( reIndex < 0){console.log("UNDER BAD")}
      rectMode(CORNER)
      fill(dist)
      rect(2*offset.x-reIndex*(400/(this.fov*this.rayDensity)),
           0,
           400/(this.fov*this.rayDensity),
           this.viewDist-dist)
    }
    stroke(0)
    strokeWeight(1)
    for(let i = this.globalAngle*this.rayDensity; i < this.fov*this.rayDensity+this.globalAngle*this.rayDensity; i++){
      let index = floor(i % (360*this.rayDensity))
      if(index < 0){index = 360*this.rayDensity+index}
      this.rays[index].show()
      
      
    }
  }
}