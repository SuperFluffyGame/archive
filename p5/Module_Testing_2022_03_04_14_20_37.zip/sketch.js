zconsole.test = function test(){console.log("HIIIIII")}
function t2(){
  test()
  console.test()
}