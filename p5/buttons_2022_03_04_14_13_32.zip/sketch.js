let b
function setup() {
  createCanvas(400, 400);
  b = createButton("Hi").style("width: 200px; height:150px")
                        .style("border: 2px solid black; border-radius: 10px;")
                        .position(width/2-100,height/2-75)
                        .style("outline: 0;")
                        .style("background: #F0F0F0;")
                        .mouseOver(style)
                        .mouseOut(styleOut)
                        .mousePressed(styleClick)
                        .mouseReleased(style)
                        .style("font-size: 40px")
}

function draw() {
  background(220);
  
}
function style(){
  this.style("background: #DDDDDD;")
}
function styleOut(){
  this.style("background: #F0F0F0;")
}
function styleClick(){
  this.style("background: #BBBBBB")
}