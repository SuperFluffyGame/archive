function setup() {
  createCanvas(400, 400);
  pixelDensity(10)
}

function draw() {
  background(220);
  scale(2)
  //square mile
  fill('red')
  rect(0,0,100*1.61)
  //square kilometer
  fill('blue')
  rect(0,0,100)
  //hectare
  fill('green')
  rect(0,0,10)
  //acre
  fill('yellow')
  rect(0,0,6.3)

}