let matrix1, matrix2, matrix3;
let operation
function setup() {
  createCanvas(400, 400);
  matrix1 = new Matrix(100, 100, 20);
  matrix2 = new Matrix(230, 80, 20);
  
  operation = 'x'
  matrix1.setContent([
    [1,2,3,4,5],
    [6,7,8,9,0],
    [3,2,4,1,5],
    [8,7,9,6,0]
  ]);
  matrix2.setContent([
    [5,6],
    [7,8],
    [3,9],
    [8,0],
    [5,1]
  ]);
  
  matrix1.widthPadding = 20
  matrix2.widthPadding = 20
  if (operation == "-") {
    matrix3 = matrixSub(matrix1, matrix2);
  } else if (operation == "+") {
    matrix3 = matrixAdd(matrix1, matrix2);
  } else if (operation == "sx") {
    matrix3 = matrixScalarMult(matrix2, 3);
  } else if (operation == "x") {
    matrix3 = matrixMult(matrix1, matrix2);
  } else {
    console.error("Operation invalid");
  }
  matrix3.widthPadding = 40
  matrix3.x = 175;
  matrix3.y = 240;
}

function draw() {
  background(220);
  matrix1.draw();
  matrix2.draw();
  matrix3.draw();
}

function bracket(x, y, length, width, dir) {
  if (dir == "left") {
    line(x, y, x, y + length);
    line(x, y, x + width, y);
    line(x, y + length, x + width, y + length);
  } else if (dir == "right") {
    line(x + width, y, x + width, y + length);
    line(x, y, x + width, y);
    line(x, y + length, x + width, y + length);
  } else {
    console.error("Invalid Direction");
  }
}
class Matrix {
  constructor(x, y, size) {
    this.x = x;
    this.y = y;
    this.size = size;
    this.sizeText = size;
    this.content = [[]];
    this.widthPadding = size;
    this.lengthPadding = size;
  }
  draw() {
    for (let i = 0; i < this.content.length; i++) {
      for (let j = 0; j < this.content[i].length; j++) {
        textSize(this.sizeText);
        text(
          this.content[i][j],
          this.x + j * this.widthPadding,
          this.y + i * this.lengthPadding
        );
        textSize(this.content.length * 20);
        bracket(
          this.x - 5,
          this.y - 5,
          this.content.length * this.lengthPadding + 8,
          10,
          "left"
        );
        bracket(
          this.x + this.content[0].length * this.widthPadding - 15,
          this.y - 5,
          this.content.length * this.lengthPadding + 8,
          10,
          "right"
        );
        textAlign(LEFT, TOP);
      }
    }
  }
  setContent(c) {
    this.content = c;
    this.mWidth = this.content[0].length;
    this.mHeight = this.content.length;
  }
}
function matrixAdd(m1, m2) {
  if (m1.mWidth == m2.mWidth && m1.mHeight == m2.mHeight) {
    let out = [];
    for (let i = 0; i < m1.mHeight; i++) {
      out.push([]);
      for (let j = 0; j < m1.mWidth; j++) {
        out[i][j] = m1.content[i][j] + m2.content[i][j];
      }
    }
    let out2 = new Matrix(10, 10, 20);
    out2.widthPadding = 30;
    out2.setContent(out);
    return out2;
  } else {
    console.error("Matrix diminsions not the same, impossible");
  }
}
function matrixSub(m1, m2) {
  if (m1.mWidth == m2.mWidth && m1.mHeight == m2.mHeight) {
    let out = [];
    for (let i = 0; i < m1.mHeight; i++) {
      out.push([]);
      for (let j = 0; j < m1.mWidth; j++) {
        out[i][j] = m1.content[i][j] - m2.content[i][j];
      }
    }
    let out2 = new Matrix(10, 10, 20);
    out2.widthPadding = 30;
    out2.setContent(out);
    return out2;
  } else {
    console.error("Matrix diminsions not the same, impossible");
  }
}
function matrixScalarMult(m1, n) {
  let out = [];
  for (let i = 0; i < m1.mWidth; i++) {
    out.push([]);
    for (let j = 0; j < m1.mHeight; j++) {
      out[i][j] = m1.content[i][j] * n;
    }
  }
  let out2 = new Matrix(10, 10, 20);
  out2.widthPadding = 30;
  out2.setContent(out);
  return out2;
}
function matrixMult(m1, m2) {
  let out = [];
  if (m1.mWidth == m2.mHeight) {
    for(let z = 0; z < m1.content.length; z++){
      out.push([0])
      for(let y = 0; y < m2.content[0].length; y++){
        out[z][y] = 0
      }
    }
    for (let i = 0; i < m1.content.length; i++) {
      for (let j = 0; j < m2.content[0].length; j++) {
        for (let k = 0; k < m1.content[0].length; k++) {
          out[i][j] += m1.content[i][k] * m2.content[k][j];
        }
      }
    }
    out2 = new Matrix(10, 10, 20);
    out2.content = out;
    out2.widthPadding = 30;
    return out2;
  } else {
    console.error("Matrices cannot be multiplied");
  }
}
