let s,w,h,t,my,mx,sv,b,i
let vt = 0
let t1=0,t2=0,t3=0,t4=0,t5=0,t6=0,t7=0;t8=0;t9=0;Xwin=0,Owin=0,j=0
let noWin = 0
function setup() {
  i = createCanvas(400,400);
  stroke(0)
  s = createSlider(2,3,3)
  b = createButton("RESET")
  b.position(10,10)
  s.position(80,10)
  s.size(50)
  w = width
  h = height
  noFill()
}
function draw() {
  //init
  background(220)
  translate(w/2,h/2)
  t = s.value() * 50
  my = mouseY-200
  mx = mouseX - 200
  sv = s.value()
  b.mousePressed(reset)

  //if checks
  i.mouseClicked(clicked)
  
  wins()

  //if draws
  if(true){
  noFill()
  strokeWeight(sv*2)
  stroke(0)
  drawBoard()
  if(t2==1){drawX(0,-33*sv,10*sv)}
  if(t1==1){drawX(-33*sv,-33*sv,10*sv)}
  if(t3==1){drawX(33*sv,-33*sv,10*sv)}
  if(t4==1){drawX(0,0,10*sv)}
  if(t5==1){drawX(-33*sv,0,10*sv)}
  if(t6==1){drawX(33*sv,0,10*sv)}
  if(t7==1){drawX(0,33*sv,10*sv)}
  if(t8==1){drawX(-33*sv,33*sv,10*sv)}
  if(t9==1){drawX(33*sv,33*sv,10*sv)}
    
  if(t2==2){drawO(0,-33*sv,22.5*sv)}
  if(t1==2){drawO(-33*sv,-33*sv,22.5*sv)}
  if(t3==2){drawO(33*sv,-33*sv,22.5*sv)}
  if(t4==2){drawO(0,0,22.5*sv)}
  if(t5==2){drawO(-33*sv,0,22.5*sv)}
  if(t6==2){drawO(33*sv,0,22.5*sv)}
  if(t7==2){drawO(0,33*sv,22.5*sv)}
  if(t8==2){drawO(-33*sv,33*sv,22.5*sv)}
  if(t9==2){drawO(33*sv,33*sv,22.5*sv)}
  }
  wins()
  turn()
  if(vturn==0){
    stroke(0)
    strokeWeight(sv*2)
    drawX(25,-175,10)
  } else{stroke(0);strokeWeight(sv*2);drawO(25,-175,22.5);}
  if(Owin){
    fill(255)
    strokeWeight(2)
    stroke(0,255,0)
    textSize(50)
    text("O WON",-100,63*sv)
  }
  if(Xwin){
    fill(255)
    strokeWeight(2)
    stroke(0,255,0)
    textSize(50)
    text("X WON",-100,63*sv)
  }
  if(noWin){
    fill(255)
    strokeWeight(2)
    stroke(0,255,0)
    textSize(50)
    text("NOONE WON",-150,63*sv)  
  }
}
function drawX(x,y,size){
  line(size+x,size+y,x-size,y-size)
  line(x-size,size+y,x+size,y-size)
}
function drawO(x,y,size){
  circle(x,y,size)
}
function drawBoard(){
  line(-t,-t/3,t,-t/3)
  line(-t,t/3,t,t/3)
  line(-t/3,-t,-t/3,t)
  line(t/3,-t,t/3,t)
}
function reset(){
  t1=0
  t2=0
  t3=0
  t4=0
  t5=0
  t6=0
  t7=0
  t8=0
  t9=0
  vt=0
  vturn=0
  Xwin = 0
  Owin = 0
  noWin = 0
  j++
  resetTurn()
}
function turn(){
  if(vt % 2){vturn=1} 
  else{vturn=0}
}
function clicked(){
  if(Xwin == 0 && Owin == 0 && noWin == 0){
  if(my < -16*sv && mx < -16*sv && my > -50*sv && mx > -50*sv && vturn==0 && t1==0)
  {t1 = 1;vt++}
  if(my < -16*sv && mx < -16*sv && my > -50*sv && mx > -50*sv && vturn==1 && t1==0)  
  {t1 = 2;vt++}
  if(my < -16*sv && mx > -16*sv && mx <  16*sv && my > -50*sv && vturn==0 && t2==0) 
  {t2 = 1;vt++}
  if(my < -16*sv && mx > -16*sv && mx <  16*sv && my > -50*sv && vturn==1 && t2==0)  
  {t2 = 2;vt++}  
  if(my < -16*sv && mx >  16*sv && mx <  50*sv && my > -50*sv && vturn==0 && t3==0) 
  {t3 = 1;vt++}
  if(my < -16*sv && mx >  16*sv && mx <  50*sv && my > -50*sv && vturn==1 && t3==0) 
  {t3 = 2;vt++} 
  
  if(my <  16*sv && mx > -16*sv && mx <  16*sv && my > -16*sv && vturn==0 && t4==0) 
  {t4 = 1;vt++}
  if(my <  16*sv && mx > -16*sv && mx <  16*sv && my > -16*sv && vturn==1 && t4==0) 
  {t4 = 2;vt++} 
  if(my <  16*sv && mx > -50*sv && mx < -16*sv && my > -16*sv && vturn==0 && t5==0) 
  {t5 = 1;vt++}
  if(my <  16*sv && mx > -50*sv && mx < -16*sv && my > -16*sv && vturn==1 && t5==0) 
  {t5 = 2;vt++} 
  if(my <  16*sv && mx >  16*sv && mx <  50*sv && my > -16*sv && vturn==0 && t6==0) 
  {t6 = 1;vt++}
  if(my <  16*sv && mx >  16*sv && mx <  50*sv && my > -16*sv && vturn==1 && t6==0) 
  {t6 = 2;vt++}
  
  if(my <  50*sv && mx > -16*sv && mx <  16*sv && my >  16*sv && vturn==0 && t7==0) 
  {t7 = 1;vt++}
  if(my <  50*sv && mx > -16*sv && mx <  16*sv && my >  16*sv && vturn==1 && t7==0) 
  {t7 = 2;vt++}  
  if(my <  50*sv && mx < -16*sv && my >  16*sv && mx > -50*sv && vturn==0 && t8==0) 
  {t8 = 1;vt++}
  if(my <  50*sv && mx < -16*sv && my >  16*sv && mx > -50*sv && vturn==1 && t8==0) 
  {t8 = 2;vt++} 
  if(my <  50*sv && mx >  16*sv && mx <  50*sv && my >  16*sv && vturn==0 && t9==0) 
  {t9 = 1;vt++}
  if(my <  50*sv && mx >  16*sv && mx <  50*sv && my >  16*sv && vturn==1 && t9==0) 
  {t9 = 2;vt++}  
    
  }
}
function wins(){
  stroke(255,180,0)
  strokeWeight(sv*3)
  if(t1==1 && t2==1 && t3==1){line(-45*sv,-33*sv,45*sv,-33*sv); Xwin = 1}
  if(t1==2 && t2==2 && t3==2){line(-45*sv,-33*sv,45*sv,-33*sv); Owin = 1}
  if(t4==1 && t5==1 && t6==1){line(-45*sv,  0*sv,45*sv,  0*sv); Xwin = 1}
  if(t4==2 && t5==2 && t6==2){line(-45*sv,  0*sv,45*sv,  0*sv); Owin = 1}
  if(t7==1 && t8==1 && t9==1){line(-45*sv, 33*sv,45*sv, 33*sv); Xwin = 1}
  if(t7==2 && t8==2 && t9==2){line(-45*sv, 33*sv,45*sv, 33*sv); Owin = 1}
  
  if(t2==1 && t4==1 && t7==1){line(  0*sv,-45*sv,  0*sv, 45*sv); Xwin = 1}
  if(t2==2 && t4==2 && t7==2){line(  0*sv,-45*sv,  0*sv, 45*sv); Owin = 1}
  if(t1==1 && t5==1 && t8==1){line(-33*sv,-45*sv,-33*sv, 45*sv); Xwin = 1}
  if(t1==2 && t5==2 && t8==2){line(-33*sv,-45*sv,-33*sv, 45*sv); Owin = 1}
  if(t3==1 && t6==1 && t9==1){line( 33*sv,-45*sv, 33*sv, 45*sv); Xwin = 1}
  if(t3==2 && t6==2 && t9==2){line( 33*sv,-45*sv, 33*sv, 45*sv); Owin = 1}
  
  if(t1==1 && t4==1 && t9==1){line(-45*sv,-45*sv, 45*sv, 45*sv); Xwin = 1}
  if(t1==2 && t4==2 && t9==2){line(-45*sv,-45*sv, 45*sv, 45*sv); Owin = 1}
  if(t3==1 && t4==1 && t8==1){line( 45*sv,-45*sv,-45*sv, 45*sv); Xwin = 1}
  if(t3==2 && t4==2 && t8==2){line( 45*sv,-45*sv,-45*sv, 45*sv); Owin = 1}
  if(t1 && t2 && t3 && t4 && t5 && t6 && t7 && t8 && t9 && Owin == 0 && Xwin == 0){
    noWin = true
  }
}
function resetTurn(){
  if(j % 2 == 0){vt=0}
  else{vt=1}
}