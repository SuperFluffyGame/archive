let nscale, slider, s2, s3

function setup() {
  slider = createSlider(2, 5, 2)
  s2 = createSlider(0, 1, 0.3, 0.01)
  s3 = createSlider(0, 10, 5, 0.1)
  createCanvas(400, 400);
  background(0, 0);
}

function draw() {
  noiseDetail(slider.value(), slider.value() / 10)
  scale(3)
  background(0)
  nscale = 0.05
  let vstrokeWeight = 1
  strokeWeight(vstrokeWeight)
  for (let i = 0; i < width / vstrokeWeight / 3; i++) {
    for (let j = 0; j < height / vstrokeWeight / 3; j++) {
      if (noise(i * nscale, j * nscale, s3.value()) < s2.value()) {
        stroke(100, 50, 0)
      } else {
        stroke(150, 100, 50)
      }
      //stroke(noise(i*nscale,j*nscale)*255)
      point(i * vstrokeWeight + vstrokeWeight / 2, j * vstrokeWeight + vstrokeWeight / 2)
    }
  }
  textAlign(CENTER, CENTER)
  textSize(8)
  text('Detail', 20, 125)
  text('Threshhold', 65, 125)
  text('3D Seed', 110, 125)

}