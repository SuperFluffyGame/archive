SFG.useP5()
let mstr
let points = []
let tris = []
let pointVariety = 1000
let volumeSize = 1000
let sensitivity = 0.4
let mCamera = {pos: SFG.create3dMatrix(0,0,150),
               rot: SFG.create3dMatrix(0,0,0)}

let movementSpeed = 1
function preload(){
  mstr = loadStrings('obj.txt')
}
function setup() {
  c = createCanvas(displayWidth, displayHeight);
  colorMode(HSB)
  noStroke()
  for(let i = 0; i < mstr.length; i++){
    mstr[i] = mstr[i].split(';')
    for(let j = 0; j < mstr[i].length; j++){
      mstr[i][j] = mstr[i][j].split(",")
    }
  }
  for(let i = 0; i < mstr.length; i++){
      tris[i] = new myTri3d(new myPoint3d(mstr[i][0][0],mstr[i][0][1],mstr[i][0][2]),
                            new myPoint3d(mstr[i][1][0],mstr[i][1][1],mstr[i][1][2]),
                            new myPoint3d(mstr[i][2][0],mstr[i][2][1],mstr[i][2][2]))
  }
  
  for(let i = 0; i < pointVariety; i++){
    points[i] = new myPoint3d(random(-volumeSize,volumeSize),
                              random(-volumeSize,volumeSize),
                              random(-volumeSize,volumeSize),0.5)
    points[i].color = color(38,random(0,50),255)
    if(random() > 0.9){
      points[i].size = random(0.75,1.5)
    }else{
    }
  }
}
document.addEventListener('click',function(){
  requestPointerLock()
})
let mx = 0, my = 0
document.addEventListener('mousemove', function(event){
  mx -= event.movementX * sensitivity
  
  my += event.movementY * sensitivity
  my = Math.max(Math.min(my,90),-90)
})
function keyPressed(){
  if (keyCode === 70) {
    let fs = fullscreen();
    fullscreen(!fs);
  }
}
function draw() {
  background('black');
  translate(width/2,height/2)

  //movement
  mCamera.rot = SFG.create3dMatrix(my,mx,0)
  if(keyIsDown(87)){
    mCamera.pos.content[0][2] -= movementSpeed*cos(radians(mCamera.rot.content[0][1]))
    mCamera.pos.content[0][0] -= movementSpeed*sin(radians(mCamera.rot.content[0][1]))
  }
  if(keyIsDown(83)){
    mCamera.pos.content[0][2] += movementSpeed*cos(radians(mCamera.rot.content[0][1]))
    mCamera.pos.content[0][0] += movementSpeed*sin(radians(mCamera.rot.content[0][1]))  
  }
  if(keyIsDown(65)){
    mCamera.pos.content[0][2] += movementSpeed*sin(radians(mCamera.rot.content[0][1]))
    mCamera.pos.content[0][0] += movementSpeed*-cos(radians(mCamera.rot.content[0][1]))   
  }
  if(keyIsDown(68)){
    mCamera.pos.content[0][2] -= movementSpeed*sin(radians(mCamera.rot.content[0][1]))
    mCamera.pos.content[0][0] -= movementSpeed*-cos(radians(mCamera.rot.content[0][1]))   
  }
  if(keyIsDown(32)){
    mCamera.pos.content[0][1] += movementSpeed
  }
  if(keyIsDown(16)){
    mCamera.pos.content[0][1] -= movementSpeed
  }
  // if(keyIsDown(17)){
  //   movementSpeed = 10
  // }else{movementSpeed = 1}

  //drawing
  // for(let i = 0; i < tris.length; i++){
  //   tris[i].show('red')
  // }
  strokeWeight(5)
  stroke(255)
  for(let i = 0; i < points.length; i++){
    //stroke(points[i].color)
    strokeWeight((1000/points[i].transPos.content[0][2])*points[i].size)
    points[i].perspectiveShow(mCamera)
  }
}
class myPoint3d{
  constructor(x,y,z,size){
    this.size = size
    this.pos = SFG.create3dMatrix(x,y,z)
    this.transPos = SFG.create3dMatrix(x,y,z)
    this.showPos = SFG.create2dMatrix(0,0)
    this.tm = new SFG.Matrix([[1,0,0,0],
                              [0,1,0,0],
                              [0,0,1,0],
                              [0,0,0,1]])  
  }
  calcShowPos(cam){
    this.resetTransform()
    this.translate(-cam.pos.content[0][0],
                   cam.pos.content[0][1],
                   cam.pos.content[0][2])
    this.rotateY(radians(cam.rot.content[0][1]))
    this.rotateX(-radians(cam.rot.content[0][0]))
    this.transform()
  }
  orthoShow(cam){
    this.calcShowPos(cam)
    this.showPos = SFG.create2dMatrix(this.transPos.content[0][0],
                                      this.transPos.content[0][1])
    SFG.mPoint2d(this.showPos)
  }
  perspectiveShow(cam){
    this.calcShowPos(cam)
    let d = 300
    let r = d / this.transPos.content[0][2]

    this.showPos = SFG.create2dMatrix(r*this.transPos.content[0][0],
                                      r*this.transPos.content[0][1])
    if(this.transPos.content[0][2] > 10 && r > 0){
      SFG.mPoint2d(this.showPos)
    }
  }
  translate(x,y,z){
    this.tm.mult(new SFG.Matrix([[1,0,0,0],
                                 [0,1,0,0],
                                 [0,0,1,0],
                                 [x,y,z,1]]))
  }
  rotateX(angle){
    this.tm.mult(new SFG.Matrix([[1,0,0,0],
                                 [0,cos(angle),-sin(angle),0],
                                 [0,sin(angle), cos(angle),0],
                                 [0,0,0,1]]))
  }
  rotateY(angle){
    this.tm.mult(new SFG.Matrix([[cos(angle),0,-sin(angle),0],
                                 [0,1,0,0],
                                 [sin(angle),0,cos(angle),0],
                                 [0,0,0,1]]))
  }
  transform(){
    this.transPos.mult(this.tm)
  }
  resetTransform(){
    this.transPos = SFG.cloneMatrix(this.pos)
    this.tm = new SFG.Matrix([[1,0,0,0],
                              [0,1,0,0],
                              [0,0,1,0],
                              [0,0,0,1]])
  }
}
class myTri3d{
  constructor(p1,p2,p3){
    this.points = [p1,p2,p3]
  }
  show(f){
    noStroke()
    strokeWeight(2)
    fill(f)
    for(let i = 0; i < this.points.length; i++){
      this.points[i].perspectiveShow(mCamera)
    }
    if(this.points[0].transPos.content[0][2] > 0 &&
       this.points[1].transPos.content[0][2] > 0 &&
       this.points[2].transPos.content[0][2] > 0){
      SFG.mTriangle2d(this.points[0].showPos,
                      this.points[1].showPos,
                      this.points[2].showPos)
    }
    stroke(0)
    for(let i = 1; i < this.points.length; i++){
      if(this.points[i].transPos.content[0][2] > 0 &&
         this.points[i-1].transPos.content[0][2] > 0){
        SFG.mLine2d(this.points[i].showPos,this.points[i-1].showPos)
      }
    }
    if(this.points[this.points.length-1].transPos.content[0][2] > 0 &&
      this.points[0].transPos.content[0][2] > 0){
      SFG.mLine2d(this.points[this.points.length-1].showPos,this.points[0].showPos)
    }
  }
}