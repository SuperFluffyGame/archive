let pushedLines = {content: []}
let currentLine = {content: ['>',' '], isInput: true, pos: {x:5,y:15},beginLinePos: {x: 0, y:0}}
let tempLine = {}
let bgcolor = 'black', textcolor = 'white'
function setup() {
  c = createCanvas(600, 400);
  fill('white')
  noStroke()
  textSize(20)
  textFont("Courier New")
  textAlign(LEFT,CENTER)
}

function draw() {
  currentLine.beginLinePos.x = textWidth(currentLine.content.join(''))+5
  background(bgcolor);
  stroke('white')
  line(currentLine.beginLinePos.x,currentLine.beginLinePos.y,
       currentLine.beginLinePos.x,currentLine.beginLinePos.y+20)
  noStroke()
  fill(textcolor)
  text(currentLine.content.join(''),currentLine.pos.x,currentLine.pos.y)
  for(let i = 0; i < pushedLines.content.length; i++){
    text(pushedLines.content[i].content.join(''),pushedLines.content[i].pos.x,pushedLines.content[i].pos.y)
  }
}
function keyPressed(){
  if(keyCode > 40){
    currentLine.content.push(key)
  }else if(key == "Backspace"){
    currentLine.content.pop()
    currentLine.content[0] = '>'
    currentLine.content[1] = ' '
  }else if(key == " "){
    currentLine.content.push(key)
  }else if(key == "Enter"){
    pushedLines.content.push(JSON.parse(JSON.stringify(currentLine)))
    parse()
    currentLine.content = [">"," "]
    if(pushedLines.content.length < height/20-1){
      currentLine.pos.y += 20
      currentLine.beginLinePos.y += 20
    }else{
      for(let i = 0; i < pushedLines.content.length; i++){
        pushedLines.content[i].pos.y -= 20
      }
    }
  }
}
function parse(){
  let a = JSON.parse(JSON.stringify(currentLine))
  if(pushedLines.content.length < height/20-1){
    a.pos.y += 20
    currentLine.pos.y += 20
    currentLine.beginLinePos.y += 20
  }else{
      for(let i = 0; i < pushedLines.content.length; i++){
        pushedLines.content[i].pos.y -= 20
      }  
  }
  a.content.shift()
  a.content.shift()
  
  
    let b = a.content.join('')
    b = b.split(' ')
    if(b[0] == 'bgcolor'){
      if(isColor(b[1])){
        bgcolor = b[1]
        a.content = 'Background Color changed to ' + b[1]
      }else{a.content = "Invalid Color"}
    }else if(b[0] == 'textcolor'){
      if(isColor(b[1])){
      textcolor = b[1]
      a.content = 'Text Color changed to ' + b[1]
      }else{a.content = "Invalid Color"}
    }else if(b[0] == 'say'){
      a.content = b[1]
    }
    // else if(b[0] == 'add'){
    //   a.content = String(float(b[1]) + float(b[2]))
    // }
    else{
      a.content = "Invalid Command"
    }
  
  
  a.content = a.content.split(0)
  pushedLines.content.push(a)
}
function isColor(strColor){
  var s = new Option().style;
  s.color = strColor;
  return s.color == strColor;
}
