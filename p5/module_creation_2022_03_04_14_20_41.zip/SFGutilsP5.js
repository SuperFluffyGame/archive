/*"use strict";*/
let SFG = {};
/* Initialize Error Stuff */
SFG.error = function(text){
  let a = new Error(text);
  a.name = 'SFGutils';
  return a;
};
/* Initialize Normal Stuff */
SFG.Matrix = class {
  constructor(contentArray){
    this.content = contentArray;
    this.dimensions = [this.content.length,this.content[0].length];
  }
  setContent(content){
    this.content = content;
    this.dimensions = [this.content.length,this.content[0].length];
  }
  mult(matrix){
    let out = [];
    if (this.dimensions[1] == matrix.dimensions[0]) {
      for(let z = 0; z < this.dimensions[0]; z++){
        out.push([0]);
        for(let y = 0; y < matrix.dimensions[1]; y++){
          out[z][y] = 0;
        }
      }
      for (let i = 0; i < this.dimensions[0]; i++) {
        for (let j = 0; j < matrix.dimensions[1]; j++) {
          for (let k = 0; k < this.dimensions[1]; k++) {
            out[i][j] += this.content[i][k] * matrix.content[k][j];
          }
        }
      }
      this.content = out;
    } else {
      throw SFG.error("Matrices cannot be multiplied");
    }
  }
  add(matrix){
    if (this.dimensions[0] == matrix.dimensions[0] && this.dimensions[1] == matrix.dimensions[1]) {
      let out = [];
      for (let i = 0; i < this.dimensions[0]; i++) {
        out.push([]);
        for (let j = 0; j < this.dimensions[1]; j++) {
          out[i][j] = this.content[i][j] + matrix.content[i][j];
        }
      }
      this.content = out;
    } else {
      throw SFG.error("Matrix diminsions not the same, impossible");
    }
  }
  sub(matrix){
    if (this.dimensions[0] == matrix.dimensions[0] && this.dimensions[1] == matrix.dimensions[1]) {
      let out = [];
      for (let i = 0; i < this.dimensions[0]; i++) {
        out.push([]);
        for (let j = 0; j < this.dimensions[1]; j++) {
          out[i][j] = this.content[i][j] - matrix.content[i][j];
        }
      }
      this.content = out;
    } else {
      throw SFG.error("Matrix diminsions not the same, impossible");
    }
  }
};
SFG.matrixAdd = function(m1, m2) {
  if (m1.dimensions[0] == m2.dimensions[0] && m1.dimensions[1] == m2.dimensions[1]) {
    let out = [];
    for (let i = 0; i < m1.dimensions[0]; i++) {
      out.push([]);
      for (let j = 0; j < m1.dimensions[1]; j++) {
        out[i][j] = m1.content[i][j] + m2.content[i][j];
      }
    }
    let out2 = new SFG.Matrix(out);
    return out2;
  } else {
    throw SFG.error("Matrix diminsions not the same, impossible");
  }
};
SFG.matrixMult = function(m1, m2) {
  let out = [];
  if (m1.dimensions[1] == m2.dimensions[0]) {
    for(let z = 0; z < m1.dimensions[0]; z++){
      out.push([0]);
      for(let y = 0; y < m2.dimensions[1]; y++){
        out[z][y] = 0;
      }
    }
    for (let i = 0; i < m1.dimensions[0]; i++) {
      for (let j = 0; j < m2.dimensions[1]; j++) {
        for (let k = 0; k < m1.dimensions[1]; k++) {
          out[i][j] += m1.content[i][k] * m2.content[k][j];
        }
      }
    }
    let out2 = new SFG.Matrix(out);
    return out2;
  } else {
    throw SFG.error("Matrices cannot be multiplied");
  }
};
SFG.matrixSub = function(m1, m2) {
  if (m1.dimensions[1] == m2.dimensions[1] && m1.dimensions[0] == m2.dimensions[0]) {
    let out = [];
    for (let i = 0; i < m1.dimensions[0]; i++) {
      out.push([]);
      for (let j = 0; j < m1.dimensions[1]; j++) {
        out[i][j] = m1.content[i][j] - m2.content[i][j];
      }
    }
    let out2 = new SFG.Matrix(out);
    return out2;
  } else {
    throw SFG.error("Matrix diminsions not the same, impossible");
  }
};
SFG.matrixScalarMult = function(m1, n) {
  let out = [];
  for (let i = 0; i < m1.dimensions[1]; i++) {
    out.push([]);
    for (let j = 0; j < m1.dimensions[0]; j++) {
      out[i][j] = m1.content[i][j] * n;
    }
  }
  let out2 = new SFG.Matrix(out);
  return out2;
};
SFG.create2dMatrix = function(x,y) {
  return new SFG.Matrix([[x,y]]);
};
SFG.create3dMatrix = function(x,y,z) {
  return new SFG.Matrix([[x,y,z]]);
};
SFG.pythagorean2d = function(num1, num2) {
  let num3 = Math.sqrt(Math.min(Math.pow(num1, 2)) + Math.min(Math.pow(num2, 2)));
  return num3;
};
SFG.pythagorean3d = function(num1, num2, num3) {
  let num4 = Math.sqrt(Math.min(Math.pow(num1, 2)) + Math.min(Math.pow(num2, 2)) + Math.min(Math.pow(num3,2)));
  return num4;
};
SFG.tetra = function(n1,n2){
  let o = n1;
  for(let i = 0; i < n2-1; i++){
    o = o**n1;
  }
  return o;
};
/* Initialize Console Stuff */
console.matrix = function(matrix){
  for(let i = 0; i < matrix.dimensions[0]; i++){
    console.log(matrix.content[i]);
  }
};
/* Initialize p5 Stuff */
SFG.useP5 = function(){
  if(typeof p5 !== 'undefined' && typeof setup !== 'undefined'){
    SFG.mPoint2d = function(matrix) {
      point(matrix.content[0][0],matrix.content[0][1]);
    }
  }else{
    /*The error is not here... it's in your own code.*/
    throw SFG.error("p5.js is not installed, or p5 setup function has not been called.");
  }
};