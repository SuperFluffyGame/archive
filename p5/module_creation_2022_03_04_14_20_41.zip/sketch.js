let m1,m2,m3
let n1,n2,n3,n4
let p1
SFG.useP5()

function setup() {  
  createCanvas(400,400)
  background(220)
  m1 = new SFG.Matrix([[2,4],
                       [3,5]])
  m2 = new SFG.Matrix([[3,2],
                       [1,0]])
  m3 = SFG.matrixMult(m1,m2)
  console.matrix(m3)
  n1 = 3
  n2 = 4
  n3 = 12
  n4 = SFG.pythagorean3d(n1,n2,n3)
  console.log(n4)
  p1 = SFG.create2dMatrix(50,50)
  SFG.mPoint2d(p1)
}
