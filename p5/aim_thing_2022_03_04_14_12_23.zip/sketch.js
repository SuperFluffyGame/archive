let x, y, c, d, click = 0, debugB
e = 0
let results = []

function setup() {
  createCanvas(500, 400);
  noFill()
  ellipseMode(CENTER)
  strokeWeight(2)
  x = random(0, 400)
  y = random(0, 400)
  textAlign(LEFT, TOP)
  textSize(20)
  c = 0;
  d = 0
  debugB = createCheckbox('Debug', true).style('color: white')
}

function draw() {
  stroke(0)
  strokeWeight(2)
  background(27);
  noFill()
  if (debugB.checked()) {
    debug()
  }
  if (click <= 16) {
    target(x, y)
  } else {
    fill('gold')
    stroke('gold')
    strokeWeight(1)
    for (let i = 0; i < results.length; i++) {
      e = e + results[i]
    }
    textSize(40)
    text(round(e / results.length, 2) + '%', 200, 200)
    textSize(20)
    e = 0
  }
  fill('blue')
  stroke('lime')
  strokeWeight(1)
  for (let i = 0; i < results.length; i++) {
    text(results[i], 425, 20 * (i + 1))
  }

}

function target(x, y) {
  stroke('gold')
  line(x - 50, y, x + 50, y)
  line(x, y - 50, x, y + 50)
  circle(x, y, 80)
  circle(x, y, 60)
  circle(x, y, 40)
  circle(x, y, 20)
}

function rand() {
  x = random(0, 400)
  y = random(0, 400)
}

function mouseClicked() {
  if (mouseX < 400 && mouseY < 400) {
    c = round(pythagorean(mouseX - x, mouseY - y))
    d = round(min0(100 - c))
    if (click <= 16) {
      click++
      rand()
      results[click - 1] = d
    }
  }
}

function debug() {
  stroke('red')
  fill('red')
  strokeWeight(1)
  text('a', mouseX - (mouseX - x) / 2, y)
  text('b', mouseX, mouseY - (mouseY - y) / 2)
  stroke('lime')
  fill('blue')
  text('c', mouseX - (mouseX - x) / 2, mouseY - (mouseY - y) / 2)

  stroke('red')
  strokeWeight(2)
  line(x, y, mouseX, y)
  line(mouseX, y, mouseX, mouseY)
  stroke('lime')
  line(x, y, mouseX, mouseY)




  strokeWeight(1)
  fill('red')
  stroke('red')
  text('a= ' + abs(round(mouseX - x),2), 50, 380)
  text('b= ' + abs(round(mouseY - y),2), 150, 380)
  fill('blue')
  stroke('lime')
  text('c= ' + round(pythagorean(mouseX-x,mouseY-y),2), 250, 380)


  strokeWeight(1)
  fill('gold')
  f = round(pythagorean(mouseX - x, mouseY - y),2)
  text(round(min0(100 - f), 2), 350, 380)
  noFill()
  strokeWeight(2)
  circle(x, y, 200)
}

function pythagorean(num1, num2) {
  num3 = sqrt(min0(pow(num1, 2)) + min0(pow(num2, 2)))
  return num3;
}

function min0(num) {
  if (num < 0) {
    return 0
  } else {
    return num
  }
}