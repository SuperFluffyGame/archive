let dictionary = {
  hello: {
    literal: "hola",
    type: "interjection"
  },
  i: {
    literal: "yo",
    type: "noun"
  },
  we: {
    literal: "nosotros",
    type: "noun"
  },
  you: {
    literal: "usted",
    type: "noun"
  },
  they: {
    literal: "ustedes",
    type: "noun"
  },
  am: {
    literal: "ser",
    type: "verb",
    conjugation: {
      afterType: {
        noun : "es"
      },
      afterWord: {
        yo: "soy",
        tu: "eres",
        usted: "es",
        nosotros: "somos",
        ustedes: "son"
      }
    }
  },
  are: {
    literal: "ser",
    type: "verb",
    afterWord: {
      yo: "soy",
      tu: "eres",
      usted: "es",
      nosotros: "somos",
      ustedes: "son"
    }
  },  
}
function setup() {
  createCanvas(400, 400);
}

function draw() {
  background(220);
}
function Translate(str){
  str = str.matchAll(/\w+|\s+|\W/g)
  let chars = [...str]
  for(let word in chars){
    
  }
}