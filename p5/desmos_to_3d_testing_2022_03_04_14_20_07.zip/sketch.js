let d = 10
let a2 = 0, a1 = 0
let a
function setup() {
  createCanvas(400, 400);
  a = [createVector(10,10,10),
       createVector(-10,10,10),
       createVector(-10,-10,10),
       createVector(-10,-10,10),
       createVector(10,-10,-10),
       createVector(10,-10,-10),
       createVector(-10,10,-10),
       createVector(10,10,-10)]
}

function draw() {
  translate(width/2,height/2)
  background(220);
  strokeWeight(5)
  for(let i = 0; i < a.length; i++){
    vpoint(ctoc(a[i].x,a[i].y,a[i].z))
  }
}
function ctoc(x,y,z){
  t = c(atan(y,x),sqrt(x^2+y^2),z)
  return t
}
function c(p,r,h){
  return createVector(d/d-z(p,r,h)*r*cos(a1+p),d/d-z(p,r,h)*(r*sin(a2)*sin(a1+p)+h*cos(a2)))
}
function z(p,r,h){
  return cos(a2)*r*sin(a1+p)-sin(a2)*h
}
function vpoint(vector){
  point(vector.x,vector.y)
}