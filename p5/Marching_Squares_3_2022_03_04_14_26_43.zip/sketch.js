let points = []
function setup() {
  createCanvas(400, 400);
  points = [new Point(100,100,round(random(),2)),
            new Point(200,100,round(random(),2)),
            new Point(100,200,round(random(),2)),
            new Point(200,200,round(random(),2))]
}

function draw() {
  background(220);
  points.forEach((elem=>elem.show(true)))
}
class Point{
  constructor(x,y,value=0){
    this.pos = createVector(x,y)
    this.value = value
  }
  show(showValue=false){
    strokeWeight(4)
    if(showValue){
      textAlign(CENTER,TOP)
      textSize(15)
      text(this.value,this.pos.x,this.pos.y+10)
    }
    point(this.pos)
  }
}