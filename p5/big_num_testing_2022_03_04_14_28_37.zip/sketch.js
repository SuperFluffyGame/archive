let a,b,c
function setup() {
  createCanvas(400, 400);
  a = new myNum(10,23)
  b = new myNum(3,99)
  c = myNum.div(a,b)
  a.console()
  b.console()
  c.console()
}

function draw() {
  background(220);
}
class myNum{
  constructor(int,dec){
    this.int = int
    this.dec = dec
  }
  console(){
    console.log(this.int + "." + this.dec)
  }
  
  static add(num1,num2){
    let num3 = new myNum(0,0)
    
    let t = num1.dec
    if(num1.int <= -1){
      t *= -1
    }
    num3.dec = 0
    num3.dec += t
    
    t = num2.dec
    if(num2.int <= -1){
      t *= -1
    }
    num3.dec += t
    
    num3.int = num1.int + num2.int
    if(num3.dec >= 100){
      num3.dec -= 100
      num3.int ++
    }else if(num3.dec <= -100){
      num3.dec += 100
      num3.int --
    }
    return num3
  }
  
  static mult(num1,num2){
    let n1i = num1.int
    let n1d = num1.dec
    if(n1i < 0){n1d *= -1}
    
    let n2i = num2.int
    let n2d = num2.dec
    if(n2i < 0){n2d *= -1}
    
    let int = 0
    let dec = 0
    
    let t1 = n1i * n2i
    int += t1
    
    let t2 = n1i * n2d
    dec += (t2 % 100) * 100
    int += floor(t2 / 100)
    
    let t3 = n1d * n2i
    dec += (t3 % 100) * 100
    int += floor(t3 / 100)
    
    let t4 = n1d * n2d
    dec += t4
    
    if(dec < 0){dec *= -1}
    int += floor(dec / 10000)
    dec %= 10000
    
    return new myNum(int,dec)
  }
  
  static div(num1,num2){
     //ez but limit :(
     return new myNum(n3i,n3d)

  }
}