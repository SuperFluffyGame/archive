let playerCar
function setup() {
  createCanvas(400, 400);
  playerCar = new car(100,100,20,40)
}

function draw() {
  background(220);
  playerCar.draw()

}
class car{
  constructor(x,y,sx,sy){
    this.pos = createVector(x,y)
    this.speed = createVector(0,0)
    this.maxSpeed = 5
    this.size= {x:sx,y:sy}
    this.acceleration = createVector(0,0)
    requestAnimationFrame(this.inputs.bind(this))
  }
  draw(){
    rectMode(CENTER)
    rect(this.pos.x,this.pos.y,this.size.x,this.size.y)
    
    line(this.pos.x,this.pos.y,this.pos.x+this.acceleration.x,this.pos.y+this.acceleration.y)
  }
  inputs(){
    
    
    this.move()
    requestAnimationFrame(this.inputs.bind(this))
  }
  move(){
    let c = 0.05;
    this.friction = this.speed
    this.friction.mult(-1);
    this.friction.normalize();
    this.friction.mult(c);
    if(keyIsDown(87)){
      this.acceleration.y -= 0.1
    }
    if(keyIsDown(83)){
      this.acceleration.y += 0.1
    }
    if(keyIsDown(68)){

    }
    this.acceleration.add(this.friction)
    this.speed.add(this.acceleration)
    this.speed.limit(this.maxSpeed)
    this.pos.add(this.speed)
  }
}