function setup() {
  createCanvas(400, 400);
}
let currentText = []
let pushedText = []
function draw() {
  background(220);
  fill('black')
  rect(0,height-50,width,50)
  fill('white')
  textAlign(LEFT,CENTER)
  textSize(20)
  text('>',10,height-25)
  text(currentText.join(''),30,height-25)
  stroke('white')
  line(textWidth(currentText.join(''))+30,height-10,textWidth(currentText.join(''))+30,height-40)
  noStroke()
  fill('black')
  for(let i = 0; i < pushedText.length; i++){
    text(pushedText[i],25,height-20*i-75)
  }
}
function keyPressed(){
  if(key != 'Backspace' && key != 'Enter' && keyCode >= 41){
    if(textWidth(currentText.join('')) < 350){
      currentText.push(key)
    }
  }else if(keyCode == 32){
    if(textWidth(currentText.join('')) < 350){
      currentText.push(key)
    }
  }else if(key == 'Backspace'){
    currentText.pop()
  }else if(key == 'Enter'){
    pushedText.unshift(currentText.join(''))
    currentText = []
  }
}