function setup() {
  createCanvas(400, 400);
  // let t = Date.now()
  // let a = hyper(4,4,3,true)
  // console.log((Date.now() - t)/1000 + " second(s); " + (Date.now() - t) + " milliseconds(s)")
  // console.log("Length: " + a.length + " digits")
  // console.log(a)
  //console.log("Binary Length: "+ BigInt(a).toString(2).length)
  
  
  // let t2 = Date.now()
  // let m = BigInt('0xf' + 'f'.repeat((5000000/4)-1))
  // console.log(String(m))
  // console.log("Length: " + String(m).length)
  // console.log("Bin Length: " + m.toString(2).length)
  // console.log((Date.now()-t2)/1000 + " Seconds for All")
}
  let b = BigInt(2)
  let e = 1;
function keyPressed(){
  if(keyCode == 32){
    d()
  }
}
function d(){
  let t = Date.now()
  console.log(`BigInt of 2^${e} `);
  b = b * b;
  e *= 2;
  console.log((Date.now() - t)/1000 + " Seconds")
}
function tetra(n1,n2,useBig){
  let n, o
  n = BigInt(n1)
  o = BigInt(n1)
  for(let i = 0; i < n2-1; i++){
    //console.log(String(o))
    o = n**o
  }
  return String(o)
}
function hyper(n,a,b,useBig){
  if(useBig === true){
    n = BigInt(n)
    a = BigInt(a)
    b = BigInt(b)

    if (n === BigInt(0)) {return String(b)}
    if (n === BigInt(1)) {return String(a + b)}
    if (n === BigInt(2)) {return String(a * b)}
    if (n === BigInt(3)) {return String(a ** b)}
    let result = a
    if(n > 0){
      for (let i = BigInt(1); i < b; i++) {
        result = hyper(n - BigInt(1), a, result,true)
      }
    }
    return String(result)
  }else{
    if (n === 0) {return b}
    if (n === 1) {return a + b}
    if (n === 2) {return a * b}
    if (n === 3) {return a ** b}
    let result = a
    if(n > 0){
      for (let i = 1; i < b; i++) {
        result = hyper(n - 1, a, result)
      }
    }
    return result
  }
}