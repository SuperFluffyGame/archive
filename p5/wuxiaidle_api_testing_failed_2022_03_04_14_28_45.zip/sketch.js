function setup() {
  createCanvas(400, 400);
  getData()
}

function draw() {
  background(220);
}

async function getData(){
  fetch("https://wuxiaidle.com/api/ah",{
    headers: {
      "Cookie": "__Host-next-auth.csrf-token=7e6ccb3a129f6fac3cac09d0fb02b46b3dbb9d19c4c152dcd41ecd5668d2830d%7C84f9eb5098f273da73d7062d0cd98958391ab72f4b8b74fa00a283260a70fade; __Secure-next-auth.session-token=682e62e154da5b1f89e322716b2ccaebd5886439824837bc32dca7760d60a83c; __Secure-next-auth.callback-url=https%3A%2F%2Fplay.wuxiaidle.com%2F%23cultivator"
    }
  })
  .then(res => res.json())
  .then(data=>console.log(data))
  .catch(err=>console.warn(err))  
}