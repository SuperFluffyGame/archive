let INT = 'int'
let STRING = 'string'
let tokens = {
  "LINE": [INT,INT,INT,INT],
  "VAR" : [STRING,INT],
  "VADD": [INT, INT],
  "CLEAR": []
}
let memory = {}
function preload(){
  code = {fileName: `code.txt`,code: loadStrings('/code.txt')}
}
function setup() {
  createCanvas(400, 400);
  run(code)
}

function draw() {
  background(220);
  run(code)
}
function tokenizeLines(arr){
  let out = []
  for(let i = 0; i < arr.length; i++){
    out[i] = arr[i].split(/\s+/g)
  }
  for(let i = 0; i < arr.length; i++){
    for(let j = 0; j < arr[i].length; j++){
      if(out[i][j] == ''){
        out[i].splice(j,1)
      }
    }
  }
  return out
}
function run(arr){
  mcode = tokenizeLines(arr.code)
  for(let i = 0; i < mcode.length; i++){
    let name = mcode[i][0]
    if(tokens[name] != undefined){
      if(mcode[i].length -1 == tokens[name].length){
        let params = mcode[i]
        switch(name){
          case "LINE":
            for(let z = 1; z < params.length; z++){
              if(params[z].startsWith('.')){
                 params[z] = params[z].replaceAll('.','')
                //console.log(params[z])
                params[z] = memory[params[z]]
              }
            }
            line(params[1],params[2],params[3],params[4])
            break;
          case "VAR":
            memory[params[1]] = params[2]
            break;  
          case "VADD":
            memory[params[1]] =  int(memory[params[1]]) +int( params[2])
            break;
        }
      }else{
        throw Error(`${name} expected ${tokens[name].length} paramaters, received ${mcode[i].length-1} instead; ${arr.fileName}:${i+1}`)
      }
    }else{
      throw Error(mcode[i][0] + " is not a valid function; " +
                  arr.fileName + ":" + i+1)
    }
  }
}