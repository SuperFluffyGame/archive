let iter = 5
let rand =[]
function setup() {
  createCanvas(400, 400);w
  generateTree()
  console.log(rand)
}

function draw() {
  background(220);
}
function generateTree(){
  for(let i = 0; i < iter; i++){
    rand.push(round(random()*360))
  }
}
function drawTree(){
  
}