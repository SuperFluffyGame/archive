function myFunction(){
console.log(document.getElementById('password').value)
}