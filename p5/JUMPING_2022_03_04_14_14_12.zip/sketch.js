let posX = -100, posY;
let jumping = 0
let ms
let player

function setup() {
  createCanvas(400, 400, WEBGL);
  posY=height/2-15;
  ms = millis()
  player = new Player(100,190,20,20)
}

function draw() {
  rectMode(CENTER)
  background(220);
  player.draw()
  player.move()
}
function keyPressed(){
  if(keyCode === 87){
    setInterval(player.jump2,100)
  }
}

class Player {
  constructor(x,y,sizeX,sizeY){
    this.sizeX = sizeX
    this.sizeY = sizeY
    this.x = x
    this.y = y
    this.isJumping = 0
    this.jumpTimer = 0
  }
  move(){
    if(keyIsDown(65)){
      this.x -= 2
    }
    if(keyIsDown(68)){
      this.x += 2
    }
  }
  
  jump2(){
    if(this.jumpTimer < 10){
      this.jumpTimer++
      this.y -= 1
    }
  }
  endJump(){
    console.log("endJump")
    if(this.endJumpTiming < 25){
        if(millis() - this.jumpSomething2 > 1){
          this.y += 2
          this.jumpSomething2 = millis()
        }
      this.endJumpTiming++
      this.endJump()
    }else{
      this.endJumpTiming = 0
      this.isJumping = 0
    }
  }
  draw(){
    rect(this.x,this.y,this.sizeX,this.sizeY)
  }
}