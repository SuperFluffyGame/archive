let points = []
let debugCheck, showSnapGrid, showExtras
let snapSlider, snapText
let resSlider, resText
let resetButton
let snap = true
let snapValue = 10
function setup() {
  createCanvas(600, 500);
  strokeWeight(2)
  ellipseMode(CENTER)
  point1 = new moveablePoint(100,300)
  point2 = new moveablePoint(100,100)
  point3 = new moveablePoint(300,100)
  point4 = new moveablePoint(300,300)
  points = [point1,point2,point3,point4]
  
  debugCheck = createCheckbox("Extra Lines")
  debugCheck.style("color: white")
  
  showSnapGrid = createCheckbox("Show Grid",1)
  showSnapGrid.style("color: white")
  showSnapGrid.position(100,height)
  
  showExtras = createCheckbox("Show Points and Lines",1)
  showExtras.style("color: white")
  showExtras.position(200,height)
  
  snapSlider = createSlider(0,50,10,10)
  snapText = createDiv("Snapping Length")
  snapText.style("color: white")
  snapText.position(25,height+40)
  
  resSlider = createSlider(1,50,25)
  resSlider.position(175,height+20)
  resText = createDiv("Resolution")
  resText.style("color: white")
  resText.position(225,height+40)
  
  resetButton = createButton("Reset")
  resetButton.mousePressed(function(){
    point1 = new moveablePoint(100,300)
    point2 = new moveablePoint(100,100)
    point3 = new moveablePoint(300,100)
    point4 = new moveablePoint(300,300)
    points = [point1,point2,point3,point4]
  })
  resetButton.position(375,height)
  
  textAlign(LEFT,TOP)
  textSize(20)
  frameRate(144)
}
function draw() {
  
  if(snapSlider.value() != 0){
    snapValue = snapSlider.value()
  }else{snapValue = 1}
  res = resSlider.value()
  
  
  background(220);
  //bezier(point1.x,point1.y,point2.x,point2.y,point3.x,point3.y,point4.x,point4.y)
  noStroke()
  fill(0)
  text(round(framerate),width-100,height/2)

  
  myBezier(points[0],points[1],points[2],points[3])
  
  showGrid()
}
function showGrid(){
  if(snapValue != 1){
    if(showSnapGrid.checked() == true){
      stroke("#0000002F")
      strokeWeight(1)
      for(let i = 1; i < height/snapValue; i++){
        line(0,i*snapValue,width,i*snapValue)
      }
      for(let i = 1; i < width/snapValue; i++){
        line(i*snapValue,0,i*snapValue,height)
      }
    }
  }
}
let bezierPoints = [[0,0]]
function myBezier(point1,point2,point3,point4){

  let p = [point1,point2,point3,point4]
  
  if(showExtras.checked() == true){
    for(let i = 0; i < points.length; i++){
      p[i].draw()
    }
    for(let i = 0; i < points.length-1; i++){
      strokeWeight(3)
      stroke(0)
      line(p[i].x,p[i].y,p[i+1].x,p[i+1].y)
    }
  }
  
  for(let i = 1; i < res; i++){
    t = (1/res)*i
    let a = pointLerp(p[0],p[1],t)
    let b = pointLerp(p[1],p[2],t)
    let c = pointLerp(p[2],p[3],t)
    let d = pointLerp(a,b,t)
    let e = pointLerp(b,c,t)
    let bezier = pointLerp(d,e,t)

    bezierPoints.push([bezier.x,bezier.y])
    
    if(debugCheck.checked() == true){
      stroke(0)
      line(a.x,a.y,b.x,b.y)
      line(b.x,b.y,c.x,c.y)
      stroke('red')
      line(d.x,d.y,e.x,e.y)
    }
  }
  bezierPoints.unshift([points[0].x,points[0].y])
  bezierPoints.push([points[3].x,points[3].y])
  strokeWeight(5)
  stroke('#009F00')
  for(let i = 0; i < bezierPoints.length-1; i++){
    line(bezierPoints[i][0],bezierPoints[i][1],bezierPoints[i+1][0],bezierPoints[i+1][1])
  }
  bezierPoints = []
}
function pointLerp(point1,point2,t){
  let out = {x: 0, y: 0}
  out.x = lerp(point1.x,point2.x,t)
  out.y = lerp(point1.y,point2.y,t)
  return out
}
function mousePressed(){
  for(let i = 0; i < points.length; i++){
    points[i].checkMove()
  }}
function mouseDragged(){
  for(let i = 0; i < points.length; i++){
    points[i].move()
  }}
function mouseReleased(){
  for(let i = 0; i < points.length; i++){
    points[i].isClicked = 0
    points[i].color = '#00000099'
  }}
class moveablePoint {
  constructor(ix,iy){
    //this.pos = {x: ix,y: iy}
    this.x = ix
    this.y = iy
    this.isClicked = 0
    this.color = '#00000099'
  }
  draw(){
    noStroke()
    fill(this.color)
    ellipse(this.x,this.y,30)
  }
  checkMove(){
    this.posOnClick = {x:0,y:0}
    if(mouseX > this.x-15 && mouseX < this.x+15 &&
       mouseY > this.y-15 && mouseY < this.y+15){
      if(snapValue !=1)
      this.posOnClick = {x: this.x-mouseX, y: this.y-mouseY}
      
      this.color = '#000000B9'
      this.isClicked = 1
    }
  }
  move(){
    if(this.isClicked){
      this.x = mouseX + this.posOnClick.x
      this.y = mouseY + this.posOnClick.y
    }
    if(snap == true){
      this.x = Math.round(this.x / snapValue) * snapValue
      this.y = Math.round(this.y / snapValue) * snapValue
    }
    if(this.x < 0){
      this.x = 0
    }
    if(this.y < 0){
      this.y = 0
    }
    if(this.x > width){
      this.x = width
    }
    if(this.y > height){
      this.y = height
    }
  }
}


let framerate = 0
let framerate2 = 0
let frameRateArr = []
let out = 0
function myFrameRate(){
  if(frameRateArr.length <= 60){
    frameRateArr.push(frameRate())
    requestAnimationFrame(myFrameRate)
  }else{
    for(let i = 0; i < frameRateArr.length; i++){
      out += frameRateArr[i]
    }
    framerate = out/60
    out = 0
    frameRateArr = []  
  }
}
setInterval(myFrameRate,1000)