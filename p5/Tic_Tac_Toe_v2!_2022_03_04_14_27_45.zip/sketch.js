let boardSize = 3
let board = []
function setup() {
  createCanvas(400, 400);
  for(let i = 0; i < boardSize; i++){
    board.push([])
    for(let j = 0; j < boardSize; j++){
      board[i][j] = new tttSquare(
                    createVector(width/boardSize,height/boardSize),
                    width/boardSize)
    }
  }
}

function draw() {
  background(220);
}
class tttSquare{
  constructor(pos,size,lines){
    this.pos = pos
    this.size = size
    this.lines = lines
  }
  draw(){
    
  }
  changeState(){
    
  }
}