let ftl, ftr, fbl, fbr
let btl, btr, bbl, bbr
let zSlider, xSlider, ySlider
let zv, xv, yv

function setup() {
  zv = -8
  xv = 0
  createCanvas(400, 400);

  zSlider = createSlider(-8, -5, -7.5, 0.1)
  xSlider = createSlider(-100, 100, 0)
  ySlider = createSlider(-100, 100, 0)

  rectMode(CENTER)
  noFill()
}

function draw() {
  yv = -ySlider.value()

  ftl = createVector(50 + xv, 50 + yv, 9 + zv)
  ftr = createVector(-50 + xv, 50 + yv, 9 + zv)
  fbl = createVector(-50 + xv, -50 + yv, 9 + zv)
  fbr = createVector(50 + xv, -50 + yv, 9 + zv)
  btl = createVector(50 + xv, 50 + yv, 10 + zv)
  btr = createVector(-50 + xv, 50 + yv, 10 + zv)
  bbl = createVector(-50 + xv, -50 + yv, 10 + zv)
  bbr = createVector(50 + xv, -50 + yv, 10 + zv)

  background(220);
  translate(width / 2, height / 2)

  quad(ftl.x / ftl.z, ftl.y / ftl.z,
    ftr.x / ftr.z, ftr.y / ftr.z,
    fbl.x / fbl.z, fbl.y / fbl.z,
    fbr.x / fbr.z, fbr.y / fbr.z
  )
  quad(btl.x / btl.z, btl.y / btl.z,
    btr.x / btr.z, btr.y / btr.z,
    bbl.x / bbl.z, bbl.y / bbl.z,
    bbr.x / bbr.z, bbr.y / bbr.z
  )
  quad(ftl.x / ftl.z, ftl.y / ftl.z,
    ftr.x / ftr.z, ftr.y / ftr.z,
    btr.x / btr.z, btr.y / btr.z,
    btl.x / btl.z, btl.y / btl.z
  )
  quad(fbl.x / fbl.z, fbl.y / fbl.z,
    fbr.x / fbr.z, fbr.y / fbr.z,
    bbr.x / bbr.z, bbr.y / bbr.z,
    bbl.x / bbl.z, bbl.y / bbl.z
  )
  if (keyIsPressed) {
    if (keyCode === 87) {
      zv = zv - 0.025
    }
    if (keyCode === 83) {
      zv = zv + 0.025
    }
    if (keyCode === 65) {
      xv = xv + 4
    }
    if (keyCode === 68) {
        xv = xv - 4
    }
  }
}