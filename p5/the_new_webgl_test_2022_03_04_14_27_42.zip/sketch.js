window.onload = preload
async function preload(){
  vertSource = await loadFile('/vertShader.vert')
  fragSource = await loadFile('/fragShader.frag')
  
  main()
}

let verts = [-1,-1,  -1, 1,   1, 1,
             -1,-1,   1,-1,   1, 1]
function main(){
  gl = initGL(400,400)
  gl.clearColor(0,0,0,1)
  gl.clear(gl.COLOR_BUFFER_BIT)
  gl.enable(gl.DEPTH_TEST)
  
  vertBuffer = gl.createBuffer()
  gl.bindBuffer(gl.ARRAY_BUFFER,vertBuffer)
  gl.bufferData(gl.ARRAY_BUFFER,new Float32Array(verts),gl.STATIC_DRAW)
  gl.bindBuffer(gl.ARRAY_BUFFER,null)
  
  program = createShaderProgram(gl,vertSource,fragSource)
  gl.linkProgram(program)
  gl.useProgram(program)
  
  programInfo = {
    attribs: {
      pos: gl.getAttribLocation(program,"pos")
    }
  }
  gl.bindBuffer(gl.ARRAY_BUFFER,vertBuffer)
  
  gl.vertexAttribPointer(programInfo.attribs.pos, 2, gl.FLOAT, false, 0, 0)
  gl.enableVertexAttribArray(programInfo.attribs.pos)
  
  
  gl.viewport(0,0,400,400)
  let numThing = verts.length/2
  gl.drawArrays(gl.TRIANGLES,0,numThing)
}
function createShaderProgram(gl,vs,fs){
  let vertShader = gl.createShader(gl.VERTEX_SHADER)
  let fragShader = gl.createShader(gl.FRAGMENT_SHADER)
  
  gl.shaderSource(vertShader,vs)
  gl.shaderSource(fragShader,fs)
  
  gl.compileShader(vertShader)
  gl.compileShader(fragShader)
  
  let compiledVert = gl.getShaderParameter(vertShader, gl.COMPILE_STATUS);
  if (!compiledVert) {
    let verrors = gl.getShaderInfoLog(vertShader);
    console.error(verrors);
    gl.deleteShader(vertShader);
  }
  
  let compiledFrag = gl.getShaderParameter(fragShader, gl.COMPILE_STATUS);
  if (!compiledFrag) {
    let ferrors = gl.getShaderInfoLog(fragShader);
    console.error(ferrors);
    gl.deleteShader(fragShader);
  }
  
  let shaderProgram = gl.createProgram()
  gl.attachShader(shaderProgram,vertShader)
  gl.attachShader(shaderProgram,fragShader)
  
  return shaderProgram
}
function initGL(w,h){
  let c = document.createElement('canvas')
  document.body.appendChild(c)
  c.width = w
  c.height = h
  return c.getContext('webgl2')
}
async function loadFile(path){
  let o = await fetch(path)
  if(o.status != 404){
    o = await o.text()
    return o  
  }else{
     console.warn("File Not Found: " + path)
  }

}