let theGrid = []
let size = 50
function setup() {
  createCanvas(400, 400);
  strokeWeight(2)
  for(let i = 0; i < width/size+1; i++){
    theGrid.push([])
    for(let j = 0; j < height/size+1; j++){
      theGrid[i].push(noise(i/10,j/10))
    }
  }
}
function draw() {
  background(220);

  for(let i = 0; i < theGrid.length; i++){
    for(let j = 0; j < theGrid[i].length; j++){
      stroke(round(theGrid[i][j])*255)
      strokeWeight(theGrid[i][j]*5+2)
      point(i*size,j*size)
      noStroke()
      text(round(theGrid[i][j],3),i*size,j*size)
    }
  }
  strokeWeight(2)
  for(let i = 0; i < theGrid.length-1; i++){
    for(let j = 0; j < theGrid[i].length-1; j++){
      stroke('red')
      MARCH(theGrid[i][j],
            theGrid[i+1][j],
            theGrid[i][j+1],
            theGrid[i+1][j+1],
            i*size,
            j*size,
            size,
            false)
      stroke('green')
      MARCH(theGrid[i][j],
            theGrid[i+1][j],
            theGrid[i][j+1],
            theGrid[i+1][j+1],
            i*size,
            j*size,
            size,
            true)
    }
  }

}
function MARCH(p1,p2,p3,p4,offsetX,offsetY,size,lerping){
  let x = offsetX
  let xMax = offsetX+size
  let y = offsetY
  let yMax = offsetY+size
  
  let a,b,c,d
  if(lerping == true){
    let t = map(0.5,p1,p2,x,xMax)
    a = createVector(t,y)
    t = map(0.5,p3,p2,y,yMax)
    b = createVector(xMax,t)
    t = map(0.5,p4,p3,x,xMax)
    c = createVector(t,yMax)
    t = map(0.5,p1,p4,y,yMax)
    d = createVector(x   ,t)
  }else{
    a = createVector(x+size/2,y)
    b = createVector(xMax,y+size/2)
    c = createVector(x+size/2,yMax)
    d = createVector(x,y+size/2)
  }
  
  
  let tSquare = [round(p1),round(p2),round(p3),round(p4)]
  switch (tSquare.toString()){
    case '0,0,0,0':
      break;
    case '1,0,0,0':
      vLine(a,d)
      break;
    case '0,1,0,0':
      vLine(a,b)
      break;
    case '0,0,0,1':
      vLine(b,c)
      break;
    case '0,0,1,0':
      vLine(c,d)
      break;
    case '1,1,0,0':
      vLine(b,d)
      break;
    case '1,0,0,1':
      vLine(a,d)
      vLine(b,c)
      break;
    case '1,0,1,0':
      vLine(a,c)
      break;
    case '0,1,0,1':
      vLine(a,c)
      break;
    case '0,1,1,0':
      vLine(a,b)
      vLine(c,d)
      break;
    case '0,0,1,1':
      vLine(b,d)
      break;
    case '1,1,0,1':
      vLine(c,d)
      break;
    case '1,1,1,0':
      vLine(b,c)
      break;
    case '1,0,1,1':
      vLine(a,b)
      break;
    case '0,1,1,1':
      vLine(d,a)
      break;
    case '1,1,1,1':
      break;
  }
}
function vLine(p1,p2){
  line(p1.x,p1.y,p2.x,p2.y)
}