function setup() {
  createCanvas(400, 400);
}

function draw() {
  background(220);
}

function numToChar(i){
  return new TextDecoder("utf-8").decode(new Uint8Array([i+97]))
}

window["a"] = () => "lol"

for(let i = 0; i < 10; i++){
  window[numToChar(i+1)] = ()=>window[numToChar(i)]
}