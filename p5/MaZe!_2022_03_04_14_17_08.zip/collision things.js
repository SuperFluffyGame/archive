class Player {
  constructor(x,y,size,moveSpeed){
    this.x = x
    this.y = y
    this.size = size
    this.collidesWith = null
    this.moveSpeed = moveSpeed
  }
  draw(){
    stroke("black")
    fill("white")
    rectMode(CENTER)
    rect(this.x,this.y,this.size)
    this.move()
  }
  move(){
    if(!this.isCollidingOnTop()){
      if(keyIsDown(87)){
        this.y -= this.moveSpeed
      }
    }
    if(!this.isCollidingOnRight()){
      if(keyIsDown(68)){
        this.x += this.moveSpeed
      }
    }
    if(!this.isCollidingOnBottom()){
      if(keyIsDown(83)){
        this.y += this.moveSpeed
      }
    }
    if(!this.isCollidingOnLeft()){
      if(keyIsDown(65)){
        this.x -= this.moveSpeed
      }
    }
  }
  isCollidingOnTop(){
    let col = 0
    for(let i = 0; i < this.collidesWith.length; i++){
      if(this.y-this.size/2-this.moveSpeed*2 < this.collidesWith[i].y+this.collidesWith[i].sizeY/2 &&
       !(this.x+this.size/2   < this.collidesWith[i].x-this.collidesWith[i].sizeX/2)&&
       !(this.x-this.size/2   > this.collidesWith[i].x+this.collidesWith[i].sizeX/2)&&
       !(this.y+this.size/2   < this.collidesWith[i].y+this.collidesWith[i].sizeY/2)){
        col++
      }  
    }
    if(col){
      return true
    }    
  }
  isCollidingOnRight(){
    let col = 0
    for(let i = 0; i < this.collidesWith.length; i++){
      if(this.x+this.size/2+this.moveSpeed*2 > this.collidesWith[i].x-this.collidesWith[i].sizeX/2 &&
       !(this.y-this.size/2   > this.collidesWith[i].y+this.collidesWith[i].sizeY/2)&&
       !(this.y+this.size/2   < this.collidesWith[i].y-this.collidesWith[i].sizeY/2)&&
       !(this.x+this.size/2   > this.collidesWith[i].x+this.collidesWith[i].sizeX/2)){
        col++
      }
    }   
    if(col){
      return true
    }    
  }
  isCollidingOnBottom(){
    let col = 0
    for(let i = 0; i < this.collidesWith.length; i++){
      if(this.y+this.size/2+this.moveSpeed*2 > this.collidesWith[i].y-this.collidesWith[i].sizeY/2 &&
       !(this.x-this.size/2   > this.collidesWith[i].x+this.collidesWith[i].sizeX/2)&&
       !(this.x+this.size/2   < this.collidesWith[i].x-this.collidesWith[i].sizeX/2)&&
       !(this.y-this.size/2   > this.collidesWith[i].y-this.collidesWith[i].sizeY/2)){
        col++
      }
    }
    if(col){
      return true
    }    
  }
  isCollidingOnLeft(){
    let col = 0
    for(let i = 0; i < this.collidesWith.length; i++){
      if(this.x-this.size/2-this.moveSpeed*2 < this.collidesWith[i].x+this.collidesWith[i].sizeX/2 &&
       !(this.y+this.size/2   < this.collidesWith[i].y-this.collidesWith[i].sizeY/2)&&
       !(this.y-this.size/2   > this.collidesWith[i].y+this.collidesWith[i].sizeY/2)&&
       !(this.x-this.size/2   < this.collidesWith[i].x-this.collidesWith[i].sizeX/2)){
        col++
      }
    }
    if(col){
      return true
    }    
  }
}
class Collision {
  constructor(x,y,sizeX,sizeY){
    this.x = x
    this.y = y
    this.sizeX = sizeX
    this.sizeY = sizeY    
  }
  draw(){
    stroke('blue')
    noFill()
    rectMode(CENTER)
    rect(this.x,this.y,this.sizeX,this.sizeY)
  }
  set(x,y,sX,sY){
    this.x = x
    this.y = y
    this.sizeX = sX
    this.sizeY = sY
  }
}
class CollisionRect{
  constructor(x,y,sx,sy,edgeCode){
    this.x = x
    this.y = y
    this.sx = sx
    this.sy = sy
    this.ec = edgeCode
  }
  draw(){
    if(this.ec[0]){
      this.a = new Collision(this.x+this.sx/2,this.y,this.sx,0)
      this.a.draw()
    }
    if(this.ec[1]){
      this.b = new Collision(this.x+this.sx,this.y+this.sy/2,0,this.sy)
      this.b.draw()
    }
    if(this.ec[2]){
      this.c = new Collision(this.x+this.sx/2,this.y+this.sy,this.sx,0)
      this.c.draw()
    }
    if(this.ec[3]){
      this.d = new Collision(this.x,this.y+this.sy/2,0,this.sy)
      this.d.draw()
    }
  }
  pushToArray(array){
    if(this.ec[0]){
      array.push(this.a)
    }
    if(this.ec[1]){
      array.push(this.b)
    }
    if(this.ec[2]){
      array.push(this.c)
    }
    if(this.ec[3]){
      array.push(this.d)
    }
  }
}