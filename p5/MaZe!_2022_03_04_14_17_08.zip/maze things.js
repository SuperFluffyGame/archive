class Maze {
  constructor(sx,sy){
    this.sx = sx
    this.sy = sy
    this.mazeSquares = []
    this.mazePath = []
    for(let i = 0; i < this.sy; i++){
      this.mazeSquares.push([])
      this.mazePath.push([])
      for(let j = 0; j < this.sx; j++){
          this.mazePath[i].push(0)
      }
    }
    this.currentSquare = [0,0]
    this.atMazeEnd = false
    this.maxAttempts = 100
    this.attempts = 0
    
    this.debugPath = []
    this.generate2()
  }
  generate2(){
    if(this.attempts < this.maxAttempts && this.atMazeEnd == false){
      this.attempts++
      let temp = round(random(1,4))
      this.mazePath[this.currentSquare[0]][this.currentSquare[1]] = 1
      switch (temp){
        case 1:
           //UP
          if(this.currentSquare[1]-1 >= 0 && this.currentSquare[1]-1 < this.sy){
            if(this.mazePath[this.currentSquare[0]][this.currentSquare[1]-1] == 0){
              this.mazePath[this.currentSquare[0]][this.currentSquare[1]-1] = 1
              this.debugPath.push([[this.currentSquare[0],this.currentSquare[1]],
                                   [this.currentSquare[0],this.currentSquare[1]-1],1])
              this.currentSquare[1] -= 1
              console.log("Up: Made new Path")
            }else{
              console.log("Tried Up, Crossed Prev Pass")
              this.debugPath.push([[this.currentSquare[0],this.currentSquare[1]],
                                 [this.currentSquare[0],this.currentSquare[1]-0.4],3])
            }
          }else{
            console.log("Tried Up, Out of Bounds")
            this.debugPath.push([[this.currentSquare[0],this.currentSquare[1]],
                                 [this.currentSquare[0],this.currentSquare[1]-1],2])
            
          }
          break;
        case 2:
           //RIGHT
          if(this.currentSquare[0]+1 >= 0 && this.currentSquare[0]+1 < this.sy){
            if(this.mazePath[this.currentSquare[0]+1][this.currentSquare[1]] == 0){
              this.mazePath[this.currentSquare[0]+1][this.currentSquare[1]] = 1
              this.debugPath.push([[this.currentSquare[0],this.currentSquare[1]],
                                   [this.currentSquare[0]+1,this.currentSquare[1]],1])
              this.currentSquare[0] += 1
              console.log("Right: Made New Path")
            }else{
              console.log("Tried Right, Crossed Prev Pass")
              this.debugPath.push([[this.currentSquare[0],this.currentSquare[1]],
                                 [this.currentSquare[0]+0.4,this.currentSquare[1]],3])
            }
          }else{
            console.log("Tried Right, failed")
            this.debugPath.push([[this.currentSquare[0],this.currentSquare[1]],
                                 [this.currentSquare[0]+1,this.currentSquare[1]],2])
          }
          break;
        case 3:
          //DOWN

          if(this.currentSquare[1]+1 >= 0 && this.currentSquare[1]+1 < this.sy){
            if(this.mazePath[this.currentSquare[0]][this.currentSquare[1]+1] == 0){  
            
              this.mazePath[this.currentSquare[0]][this.currentSquare[1]+1] = 1
              this.debugPath.push([[this.currentSquare[0],this.currentSquare[1]],
                                   [this.currentSquare[0],this.currentSquare[1]+1],1])
              this.currentSquare[1] += 1
              console.log("Down: Made new Path")
            }else{
              console.log("Tried Up, Crossed Prev Pass")
              this.debugPath.push([[this.currentSquare[0],this.currentSquare[1]],
                                 [this.currentSquare[0],this.currentSquare[1]-0.4],3])
            }
          }else{
            console.log("Tried Down, failed")
            this.debugPath.push([[this.currentSquare[0],this.currentSquare[1]],
                                 [this.currentSquare[0],this.currentSquare[1]+1],2])
          } 
          break;
        case 4:
          //LEFT
          if(this.currentSquare[0]-1 >= 0 && this.currentSquare[0]-1 < this.sy){
            if(this.mazePath[this.currentSquare[0]-1][this.currentSquare[1]] == 0){  

              this.mazePath[this.currentSquare[0]-1][this.currentSquare[1]] = 1
              this.debugPath.push([[this.currentSquare[0],this.currentSquare[1]],
                                   [this.currentSquare[0]-1,this.currentSquare[1]],1])
              this.currentSquare[0] -= 1
              console.log("Left: Made New Path")
            }else{
            this.debugPath.push([[this.currentSquare[0],this.currentSquare[1]],
                                 [this.currentSquare[0]-0.4,this.currentSquare[1]],3])   
            }
          }else{
            console.log("Tried Left, failed")
            this.debugPath.push([[this.currentSquare[0],this.currentSquare[1]],
                                 [this.currentSquare[0]-1,this.currentSquare[1]],2])
          }
          break;
        default:
          console.warn("maze generator broke again")
          break;
      }
      
      if(this.currentSquare[0] == this.sx-1 && this.currentSquare[1] == this.sy-1){
        this.atMazeEnd = true
        console.log("MADE IT TO THE END")
      }
      
      requestAnimationFrame(this.generate2.bind(this))
    }else if(this.atMazeEnd != true){
      console.warn("Max Attempts Reached.")

      this.mazeSquares = []
      this.mazePath = []
      for(let i = 0; i < this.sy; i++){
        this.mazeSquares.push([])
        this.mazePath.push([])
        for(let j = 0; j < this.sx; j++){
            this.mazePath[i].push(0)
        }
      }
      
      this.currentSquare = [0,0]
      this.atMazeEnd = false
      this.maxAttempts = 100
      this.attempts = 0

      this.debugPath = []
      this.generate2()   
    }else{
      this.generate()
    }
  }
  generate(){
    for(let i = 0; i < this.sy; i++){
      for(let j = 0; j < this.sx; j++){
        if(this.mazePath[j][i] == 1){
          this.mazeSquares[j][i] = new CollisionRect(0,0,0,0,[0,0,0,0])
        }else{
        this.mazeSquares[j][i] = new CollisionRect((400/12)*(j+1),(400/12)*(i+1),35,35,[1,1,1,1])
          
        this.mazeSquares[j][i].draw()
        this.mazeSquares[j][i].pushToArray(allCollisions)
        }
      }
    }
    this.isDone = 1
  }
  draw(){
      for(let i = 0; i < this.sy; i++){
        for(let j = 0; j < this.sx; j++){

          this.mazeSquares[j][i].draw()
        }
      }
  }
  debugDraw(){
    for(let i = 0; i < this.debugPath.length; i++){
      strokeWeight(2)
      if(this.debugPath[i][2] == 1){
        stroke('lime')
      }else if(this.debugPath[i][2] == 2){
        stroke('red')
      }else if(this.debugPath[i][2] == 3){
        stroke('orange')
      }
      line(this.debugPath[i][0][0]*(400/12)+35*1.5,
           this.debugPath[i][0][1]*(400/12)+35*1.5,
           this.debugPath[i][1][0]*(400/12)+35*1.5,
           this.debugPath[i][1][1]*(400/12)+35*1.5)
    }
  }
}