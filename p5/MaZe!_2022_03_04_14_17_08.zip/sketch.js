let player

let allCollisions

let leftWallCol
let topWallCol
let rightWallCol
let bottomWallCol

let MAZE
function setup() {
  createCanvas(400, 400);
  player = new Player(50,50,20,1)
  
  leftWallCol = new Collision(0,height/2,0,height)
  topWallCol = new Collision(width/2,0,width,0)
  bottomWallCol = new Collision(width/2,height,width,0)
  rightWallCol = new Collision(width,height/2,0,height)
  
  allCollisions = [leftWallCol,topWallCol, bottomWallCol, rightWallCol]
  
  player.collidesWith = allCollisions
  
  MAZE = new Maze(10,10)
  
}

function draw() {
  background(220);
  if(MAZE.isDone == 1){
    MAZE.draw()
    player.draw()
    MAZE.debugDraw()
  }
  //MAZE.draw()
  
  
}


