function init(w,h,id="canvas"){
  can = document.createElement("canvas")
  can.width = w; can.height = h; can.id = id
  document.body.appendChild(can)
  gl = can.getContext("webgl")
}
function clearCanvas(r=1,g=1,b=1,a=1){
  gl.clearColor(r,g,b,a)
  gl.clear(gl.COLOR_BUFFER_BIT)
}
async function getText(src){
  let out
  out = await fetch(src)
  out = await out.blob()
  out = await out.text()
  return out
}
function createShaderProgram(vs,fs){
  let vertShader = mcreateShader(vs,gl.VERTEX_SHADER)
  let fragShader = mcreateShader(fs,gl.FRAGMENT_SHADER)
  let program = gl.createProgram()
  gl.attachShader(program,vertShader)
  gl.attachShader(program,fragShader)
  gl.linkProgram(program)
  return program
}
function mcreateShader(src,type){
  let shader = gl.createShader(type)
  gl.shaderSource(shader,src)
  gl.compileShader(shader)
  
  return shader
}