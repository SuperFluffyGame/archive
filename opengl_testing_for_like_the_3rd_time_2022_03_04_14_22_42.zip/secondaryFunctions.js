function bufferInit(){
  let posBuffer = gl.createBuffer()
  gl.bindBuffer(gl.ARRAY_BUFFER, posBuffer)
  let positions = new Float32Array([
    -1, 1,
     1, 1,
    -1,-1,
     1,-1
  ])
  gl.bufferData(gl.ARRAY_BUFFER,positions,gl.STATIC_DRAW)
  return {
    position: posBuffer
  }
}
function drawScene(prgmINFO,buffers){
  gl.clearDepth(1)
  gl.clearColor(0,0,0,1)
  gl.enable(gl.DEPTH_TEST)
  gl.depthFunc(gl.LEQUAL)
  
  gl.clear(gl.COLOR_BUFFER_BIT | gl.DEPTH_BUFFER_BIT)
  
  gl.bindBuffer(gl.ARRAY_BUFFER, buffers.position)
  gl.vertexAttribPointer(prgmINFO.attributes.vertPos,2,gl.FLOAT,false,0,0)
  gl.enableVertexAttribArray(prgmINFO.attributes.vertPos)
  
  gl.useProgram(prgmINFO.program)
  
  gl.drawArrays(gl.TRIANGLE_STRIP,0,4)
  
}