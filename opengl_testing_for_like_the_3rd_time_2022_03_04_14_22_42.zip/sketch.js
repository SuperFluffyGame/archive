window.onload = pre
let vertShaderSrc,fragShaderSrc
let mainProgram
let mainProgramInfo
async function pre(){
  vertShaderSrc = await getText('vertexshader.vert')
  fragShaderSrc = await getText('fragmentShader.frag')
  before()
}
function before(){
  init(400,400)
  mainProgram = createShaderProgram(vertShaderSrc,fragShaderSrc)
  
  mainProgramInfo = {
    program: mainProgram,
    attributes: {
      vertPos: gl.getAttribLocation(mainProgram,'vertPos')
    },
    uniforms: {
      
    }
  }
  
  
  main()
}
function main(){
  let buffers = bufferInit()
  
  drawScene(mainProgramInfo,buffers)
}