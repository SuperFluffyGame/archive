let grid
let size = 8
let showPoints = false
function setup() {
  createCanvas(400, 400);
  mnoise = new OpenSimplexNoise(Date.now());
  grid = new Grid(ceil(width/size)+1,ceil(height/size)+1)
}
let zoff = 0
function draw() {
  if(deltaTime == 0){dt = 1}else{dt = deltaTime/60}
  background(255);
  strokeWeight(1)
  if(showPoints){
    for(let i = 0; i < grid.width; i++){
      for(let j = 0; j < grid.height; j++){
        //stroke(grid.content[i][j]*255)
        point(i*size,j*size)
      }
    }
  }
  stroke(0)
  strokeWeight(2)
  for(let i = 0; i < grid.width-1; i++){
    for(let j = 0; j < grid.height-1; j++){
      march(grid.content[i][j],
            grid.content[i+1][j],
            grid.content[i][j+1],
            grid.content[i+1][j+1],
            createVector(i*size,j*size),size,true)
    }
  }
  grid.clear()
  grid.generateMetaball(floor(width/size)/2,floor(height/size)/2,50/size)
  grid.generateMetaball(floor(mouseX/size),floor(mouseY/size),50/size)
  
  // zoff += 0.01*dt
  // grid.fillNoise(50/size,zoff*100,0,zoff)
}
function march(p1,p2,p3,p4,offset,size,lerping){
  let t = [round(p1),round(p2),round(p3),round(p4)]
  let a = createVector(offset.x+size/2,offset.y)
  let b = createVector(offset.x+size  ,offset.y+size/2)
  let c = createVector(offset.x+size/2,offset.y+size)
  let d = createVector(offset.x       ,offset.y+size/2)
  
  let x = offset.x
  let y = offset.y
  
  let a_val = p1
  let b_val = p2
  let c_val = p3
  let d_val = p4
  if(lerping){
  a = createVector();
  let amt = (0.5 - a_val) / (b_val - a_val);
  a.x = lerp(x, x + size, amt);
  a.y = y;

  b = createVector();
  amt = (0.5 - b_val) / (d_val - b_val);
  b.x = x + size;
  b.y = lerp(y, y + size, amt);

  c = createVector();
  amt = (0.5 - c_val) / (d_val - c_val);
  c.x = lerp(x, x + size, amt);
  c.y = y + size;

  d = createVector();
  amt = (0.5 - a_val) / (c_val - a_val);
  d.x = x;
  d.y = lerp(y, y + size, amt);
  }
  switch(t.toString()){
    case '0,0,0,0':
      break;
    case '1,0,0,0':
      vLine(a,d)
      break;
    case '0,1,0,0':
      vLine(a,b)
      break;
    case '0,0,1,0':
      vLine(c,d)
      break;
    case '0,0,0,1':
      vLine(b,c)
      break;
    case '1,1,0,0':
      vLine(b,d)
      break;
    case '1,0,1,0':
      vLine(a,c)
      break;
    case '1,0,0,1':
      vLine(a,d)
      vLine(b,c)
      break;
    case '0,1,1,0':
      vLine(a,b)
      vLine(c,d)
      break;  
    case '0,1,0,1':
      vLine(a,c)
      break;
    case '0,0,1,1':
      vLine(b,d)
      break;
    case '0,1,1,1':
      vLine(a,d)
      break;
    case '1,0,1,1':
      vLine(a,b)
      break;  
    case '1,1,0,1':
      vLine(c,d)
      break;
    case '1,1,1,0':
      vLine(b,c)
      break;
    case '1,1,1,1':
      break;
  }
}
function vLine(v1,v2){
  line(v1.x,v1.y,v2.x,v2.y)
}
class Grid{
  constructor(width,height){
    this.width = width
    this.height = height
    this.clear()
  }
  clear(){
    this.content = []
    for(let i = 0; i < this.width; i++){
      this.content.push([])
      for(let j = 0; j < this.height; j ++){
        this.content[i].push(0)
      }
    }
  }
  fillNoise(noiseScale,offX=0,offY=0,zoff=0){
    this.content = []
    for(let i = 0; i < this.width; i++){
      this.content.push([])
      for(let j = 0; j < this.height; j ++){
        this.content[i].push(
          (mnoise.noise3D(i/noiseScale-offX/this.width+500,
                         j/noiseScale-offY/this.height+500,
                         zoff)+1)/2
        )
      }
    }
  }
  generateCircle(x,y,r){
    for(let i = 0; i < this.width; i++){
      for(let j = 0; j < this.height; j++){
        let z = (length2d(x,y,i,j))
        this.content[i][j] += (z < r) ? (r-z) : 0
        let w = this.content[i][j]
        this.content[i][j] = (w <= 1) ? w : 1
      }
    }
  }
  generateMetaball(x,y,r){
    for(let i = 0; i < this.width; i++){
      for(let j = 0; j < this.height; j++){
        let w = (r*r/2) / ((i - x) * (i - x) + (j - y) * (j - y));
        if(w > 1){w = 1}
        if(w < 0){w = 0}
        this.content[i][j] += w
      }
    }
  }
}
function length2d(x1,y1,x2,y2){
  return sqrt((x1-x2)**2+(y1-y2)**2)
}