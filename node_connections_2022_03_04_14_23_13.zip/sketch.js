let nodes = []
let createNodeButton
function setup() {
  createCanvas(600, 400);
  noFill()
  textAlign(CENTER,CENTER)
  for(let i = 0; i < 20; i++){
    new Node(random(140,width),random(0,height),nodes,i)
  }
  nodes.forEach((elem,index,arr) => {
    let connection = floor(random(0,arr.length))
    if(connection != 0 && connection != index){
      nodes[index].connect(nodes[connection])
    }
  })
  
  createNodeButton = new Button(20,20,100,30,{
    noAction: {
      stroke: {width: 3,color: 'black'},
      fill: {color: 'darkgray'},
      rounded: {all: 5},
      text: {text: 'Create Node',color: 'black',size: 16,stroke: false}
    },
    hover: {
      stroke: {width: 3,color: 'black'},
      fill: {color: 'slategray'},
      rounded: {all: 5},
      text: {text: 'Create Node',color: 'black',size: 16,stroke: false}
    },
    click: {
      stroke: {width: 3,color: 'black'},
      fill: {color: 'darkslategray'},
      rounded: {all: 5},
      text: {text: 'Create Node',color: 'black',size: 16,stroke: false} 
    }
  },
  function(){
    new Node(220,20,nodes,'new node :')
  })
  randomNodes = new Button(20,100,100,30,{
    noAction: {
      stroke: {width: 3,color: 'black'},
      fill: {color: 'darkgray'},
      rounded: {all: 5},
      text: {text: '20 Nodes',color: 'black',size: 16,stroke: false}
    },
    hover: {
      stroke: {width: 3,color: 'black'},
      fill: {color: 'slategray'},
      rounded: {all: 5},
      text: {text: '20 Nodes',color: 'black',size: 16,stroke: false}
    },
    click: {
      stroke: {width: 3,color: 'black'},
      fill: {color: 'darkslategray'},
      rounded: {all: 5},
      text: {text: '20 Nodes',color: 'black',size: 16,stroke: false} 
    }
  },
  function(){
    if(nodes.length < 100){
      for(let i = 0; i < 20; i++){
      new Node(random(140,width),random(0,height),nodes,i)
    }
      nodes.forEach((elem,index,arr) => {
      let connection = floor(random(0,arr.length))
      if(connection != 0 && connection != index){
        nodes[index].connect(nodes[connection])
      }
    })  
    }
  })
  deleteAllNodes = new Button(20,60,100,30,{
    noAction: {
      stroke: {width: 3,color: 'black'},
      fill: {color: '#FF3030'},
      rounded: {all: 5},
      text: {text: 'DELETE ALL',color: 'black',size: 16,stroke: false}
    },
    hover: {
      stroke: {width: 3,color: 'black'},
      fill: {color: 'red'},
      rounded: {all: 5},
      text: {text: 'DELETE ALL',color: 'black',size: 16,stroke: false}
    },
    click: {
      stroke: {width: 3,color: 'black'},
      fill: {color: '#DD0000'},
      rounded: {all: 5},
      text: {text: 'DELETE ALL',color: 'black',size: 16,stroke: false} 
    }
  },
  function(){
    nodes = []
  })
}

function draw() {
  background(220);
  stroke(0)
  nodes.forEach(elem => elem.show())
  strokeWeight(5)
  line(140,0,140,height)
  createNodeButton.show()
  deleteAllNodes.show()
  randomNodes.show()
  textSize(20)
  text('Nodes',70,height-40)
  text(nodes.length + ' / 100',70,height-20)
}
document.addEventListener('click',function(evt){

  let isOverNodes = []
  nodes.forEach((elem,index,arr) => {
    if(arr[index].isOver(mouseX,mouseY)){
      isOverNodes.push(arr[index])
    }
  })
  if(isOverNodes.length != 0){
    let prevMaxIndexNode = isOverNodes[0]
    let maxIndexNode = isOverNodes[0]
    isOverNodes.forEach((elem,index,arr) => {
      if(nodes[index].zIndex > prevMaxIndexNode.zIndex){
        prevMaxIndexNode = maxIndexNode
        maxIndexNode = nodes[index]
      }
    })
    if(maxIndexNode.isOver(mouseX,mouseY))
    maxIndexNode.isDragging = !maxIndexNode.isDragging
  }

})
let z_index = 0
class Node{
  constructor(x,y,nodeList,name){
    this.name = name
    this.zIndex = z_index
    z_index++
    this.pos = createVector(x,y)
    this.connections = []
    nodeList.push(this)
    this.isDragging = false
  }
  connect(node){
    this.connections.push(node)
  }
  show(){
    if(this.isDragging){
      this.drag(mouseX,mouseY)
    }
    strokeWeight(8)
    point(this.pos)
    strokeWeight(1)
    this.connections.forEach(elem => {
      line(this.pos.x,this.pos.y,elem.pos.x,elem.pos.y)
      fill(0)
      rotatedTriangle(elem.pos.x,elem.pos.y,3,
                      atan2((elem.pos.x-this.pos.x),-(elem.pos.y-this.pos.y)),7)
    })
  }
  drag(x,y){
    this.pos = createVector(x,y)
    if(this.pos.x < 150){
      this.pos.x = 150
    }
  }
  isOver(x,y){
    if(x > this.pos.x-10 && x < this.pos.x+10 &&
       y > this.pos.y-10 && y < this.pos.y+10){
      return true
    }else{
      return false
    }
  }
  delete(nodeList){
    nodeList.splice(nodeList.indexOf(this),1)
  }
}
function rotatedTriangle(x,y,size,angle,offset){
  push()
  translate(x,y)
  rotate(angle)
  translate(-x,-y)
  triangle(x,y-size+offset,x+size,y+size+offset,x-size,y+size+offset)
  pop()
}
class Button{
  constructor(x,y,sx,sy,colorProperties,clickFunc){
    this.pos = createVector(x,y)
    this.size = createVector(sx,sy)
    this.clickFunction = clickFunc
    this.properties = colorProperties
    this.clicked = false
    document.addEventListener('mousedown',function(){
      if(this.isOver(mouseX,mouseY)){
        this.clicked = true
        this.clickFunction()
      }
    }.bind(this))
    document.addEventListener('mouseup',function(){
      this.clicked = false
    }.bind(this))
  }
  isOver(x,y){
    if(x > this.pos.x && x < this.pos.x+this.size.x &&
       y > this.pos.y && y < this.pos.y+this.size.y){
       return true
    }else{
      return false
    }
  }
  show(){
    if(this.clicked == true){
      this.clickShow()
    }else if(this.isOver(mouseX,mouseY)){
      this.hoverShow()
    }else{
      this.noActionShow()
    }
  }
  noActionShow(){
    stroke(this.properties.noAction.stroke.color)
    strokeWeight(this.properties.noAction.stroke.width)
    fill(this.properties.noAction.fill.color)
    rect(this.pos.x,this.pos.y,this.size.x,this.size.y,
         this.properties.noAction.rounded.all)
    noStroke()
    fill(this.properties.noAction.text.color)
    textSize(this.properties.noAction.text.size)
    text(this.properties.noAction.text.text,
         this.pos.x+this.size.x/2,this.pos.y+this.size.y/2)
  }
  hoverShow(){
    stroke(this.properties.hover.stroke.color)
    strokeWeight(this.properties.hover.stroke.width)
    fill(this.properties.hover.fill.color)
    rect(this.pos.x,this.pos.y,this.size.x,this.size.y,
         this.properties.hover.rounded.all)
    noStroke()
    fill(this.properties.hover.text.color)
    textSize(this.properties.hover.text.size)
    text(this.properties.hover.text.text,
         this.pos.x+this.size.x/2,this.pos.y+this.size.y/2)
  }
  clickShow(){
    stroke(this.properties.click.stroke.color)
    strokeWeight(this.properties.click.stroke.width)
    fill(this.properties.click.fill.color)
    rect(this.pos.x,this.pos.y,this.size.x,this.size.y,
         this.properties.click.rounded.all)
    noStroke()
    fill(this.properties.click.text.color)
    textSize(this.properties.click.text.size)
    text(this.properties.click.text.text,
         this.pos.x+this.size.x/2,this.pos.y+this.size.y/2)
  }
}