window.onload = preLoad;
let vss,fss,mainProgram

async function preLoad(){
  vss = await loadText('/vert.vert')
  fss = await loadText('/frag.frag')
  main()
}

function main(){
  gl = setupGL(400,400)
  mainProgram = createShaderProgram(gl,vss,fss)

  drawScene(gl,mainProgram)
}

function drawScene(gl,program){
  let locations = {
    program: program,
    attributes: {
      vertPos: gl.getAttribLocation(program, 'aVertPos')
    }
  }
  let positions = [
    -1,-1,1,
    -1, 1,1,
     1, 1,1,
     1,-1,1
  ]
  let posBuffer = initBuffers(gl,positions)

  
  gl.clearColor(0,0,0,1)
  gl.clear(gl.COLOR_BUFFER_BIT)

  gl.bindBuffer(gl.ARRAY_BUFFER, posBuffer.buffer);
  gl.vertexAttribPointer(
      locations.attributes.vertPos,
      3,gl.FLOAT,false,0,0)
  gl.enableVertexAttribArray(locations.attributes.vertPos)
  
  gl.useProgram(program)
  gl.drawArrays(gl.TRIANGLE_STRIP,0,4)
}

function initBuffers(gl,data){
  const outBuffer = gl.createBuffer()
  gl.bindBuffer(gl.ARRAY_BUFFER, outBuffer)
  gl.bufferData(gl.ARRAY_BUFFER,data,gl.STATIC_DRAW)
  return {buffer: outBuffer}
}
function setupGL(w,h){
  let can = document.createElement('CANVAS')
  can.width = w; can.height = h;
  document.body.appendChild(can)
  let gl = can.getContext('webgl')
  return gl
}
async function loadText(src){
  let out
  out = await fetch(src)
  out = await out.blob()
  out = await out.text()
  return out
}
function createShaderProgram(gl,vs,fs){
  let vertShader = mcreateShader(gl,vs,gl.VERTEX_SHADER)
  let fragShader = mcreateShader(gl,fs,gl.FRAGMENT_SHADER)
  let program = gl.createProgram()
  gl.attachShader(program,vertShader)
  gl.attachShader(program,fragShader)
  gl.linkProgram(program)
  return program
}
function mcreateShader(gl,src,type){
  let shader = gl.createShader(type)
  gl.shaderSource(shader,src)
  gl.compileShader(shader)
  
  return shader
}