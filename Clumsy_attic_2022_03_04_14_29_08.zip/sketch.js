function setup() {
  createCanvas(400, 400);
}

function draw() {
  background(220);
}


let myObject = {
  firstTest: 200,
  secondTest: 300
}

{
  let {secondTest: test, firstTest} = myObject
  console.log(test, firstTest)
}
