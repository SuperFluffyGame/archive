function setup() {
  createCanvas(400, 400);
}

function draw() {
  background(220);
}

function lexer(string){
  let out = ""
  out = string.match(/(?<!\d)[\-\+]?(\d+|\()|[\+\-\*\/\^\(\)]/g)
  let lex = []
  out.forEach(e=>{
    if(e == e.match(/\-+\d+/)){
      lex.push(token("OPERATOR","UNARY_NEGATIVE"))
      lex.push(token("INTEGER",e.match(/\d+/).join()))
    }else if(e == "-("){
      lex.push(token("OPERATOR","UNARY_NEGATIVE"))
      lex.push(token("OPERATOR","L_PEREN"))
    }else if(e == e.match(/\d+/)){
      lex.push(token("INTEGER",e.match(/\d+/).join()))
    }else if(e == "+"){
      lex.push(token("OPERATOR","PLUS"))
    }else if(e == "-"){
      lex.push(token("OPERATOR","SUB"))
    }else if(e == "*"){
      lex.push(token("OPERATOR","MULT"))
    }else if(e == "/"){
      lex.push(token("OPERATOR","DIV"))
    }else if(e == "^"){
      lex.push(token("OPERATOR","POW"))
    }else if(e == "("){
      lex.push(token("OPERATOR","L_PEREN"))
    }else if(e == ")"){
      lex.push(token("OPERATOR","R_PEREN"))
    }
  })
  return lex
}

function rpnParse(lex){
  let opQ = []
  let outQ = []
  lex.forEach(e=>{
    switch(e.type){
      case "INTEGER": {
        outQ.push(e.value)
        break
      }
      case "OPERATOR": {
        while(prec[opQ[opQ.length-1]] <= prec[e]){
          outQ.push(opQ.pop())
        }
        opQ.push(e.value)
        break
      }
    }
  })
  for(let i = 0; i < opQ.length; i++){
    outQ.push(opQ[opQ.length-1-i])
  }
  return outQ
}

let prec = {
  "PLUS": 2,
  "SUB": 2,
  "MULT": 3,
  "DIV": 3,
  "POW": 4,
}

function token(type,value){
  if(value ?? false)
  return {type,value}
  else
  return {type}
}
// 2+3*4
// -6+12^8