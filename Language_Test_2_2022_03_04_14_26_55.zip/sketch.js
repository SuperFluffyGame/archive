window.onload = preload
let code
async function preload(){
  code = await get('code.txt')
  main()
}
function main(){
  code = code.replaceAll('\n','')
  console.log(code)
  code2 = tokenize(code)
}
function tokenise(input){
  
}
async function get(path){
  let out;
  out = await fetch(path)
  out = await out.blob()
  out = await out.text()
  return out
}