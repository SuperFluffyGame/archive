window.onload = setup
let woodCount = 1
function setup(){
  can = createCanvas(400,400,'2d')
  c = can.getContext('2d',{antialias: false,alpha: false})
  c.fillStyle = 'lightgray'
  c.fillRect(0,0,can.width,can.height)
  c.fillStyle = 'black'
  c.textBaseline = 'top'
  c.font = '20px arial'
  c.fillText("Wood: " + woodCount,0,0)
}
function update(){
  c.fillStyle = 'lightgray'
  c.fillRect(0,0,can.width,can.height)
  c.fillStyle = 'black'
  c.textBaseline = 'top'
  c.font = '20px arial'
  c.fillText("Wood: " + woodCount,0,0)
}
document.addEventListener('click',getWood)
function getWood(){
  woodCount*=2
  update()
}
function createCanvas(x,y,type){
  let canvas = document.createElement('canvas')
  canvas.width = x
  canvas.height = y
  document.body.appendChild(canvas)
  return canvas
}
