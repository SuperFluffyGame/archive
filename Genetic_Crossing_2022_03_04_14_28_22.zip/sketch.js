String.prototype.replaceAt = function(index, replacement) {
    return this.substr(0, index) + replacement + this.substr(index + replacement.length);
}
let inputs = []
let off = 100
let names = {
  A: "",
  a: "",
  B: "",
  b: "",
  C: "",
  c: "",
  1: "",
  2: ""
}
let mbox = []
let numSelect
function setup() {
  createCanvas(600, 500);
  for(let i = 0; i < 8; i++){
    inputs.push(createInput())
    inputs[i].size(100)
  }
  inputs[0].position(30,10+off)
  inputs[1].position(30,35+off)
  inputs[2].position(30,70+off)
  inputs[3].position(30,95+off)
  inputs[4].position(30,130+off)
  inputs[5].position(30,155+off)
  
  numSelect = createSelect()
  numSelect.option("Monohybrid")
  numSelect.option("Dihybrid")
  numSelect.size(128.5).position(10,10)
  
  inputs[6].position(30,35)
  inputs[7].position(30,60)
  
  
  
  textSize(22)
  textAlign(RIGHT,TOP)
}

function draw() {
  background(220);

  textAlign(RIGHT,TOP)
  textSize(20)
  text("1: ",30,35)
  text("2: ",30,60)
  
  names.A = inputs[0].value()
  names.a = inputs[1].value()
  names.B = inputs[2].value()
  names.b = inputs[3].value()
  names.C = inputs[4].value()
  names.c = inputs[5].value()
  names[1] = inputs[6].value()
  names[2] = inputs[7].value()
  
  if(numSelect.value() == "Monohybrid"){
    inputs[0].show()
    inputs[1].show()
    inputs[2].hide()
    inputs[3].hide()
    inputs[4].hide()
    inputs[5].hide()
    text("A: ",30,10+off)
    text("a: ",30,35+off)
  }else if(numSelect.value() == "Dihybrid"){
    inputs[0].show()
    inputs[1].show()
    inputs[2].show()
    inputs[3].show()
    inputs[4].hide()
    inputs[5].hide()
    text("A: ",30,10+off)
    text("a: ",30,35+off)
    text("B: ",30,70+off)
    text("b: ",30,95+off)
  }
  
  
  //table
  textAlign(CENTER,CENTER)
  if(numSelect.value() == "Monohybrid"){
    line(200,50,350,50)
    line(200,200,350,200)
    line(200,50,200,200)
    line(350,50,350,200)
    line(275,50,275,200)
    line(200,125,350,125)
    text(names[1][0],200+(75/2),25)
    text(names[1][1],275+(75/2),25)
    text(names[2][0],175,50+(75/2))
    text(names[2][1],175,125+(75/2))
    
    if(names[1].length == 2 &&
       names[2].length == 2){
      mbox[0] = names[1][0] + names[2][0]
      mbox[1] = names[1][1] + names[2][0]
      mbox[2] = names[1][0] + names[2][1]
      mbox[3] = names[1][1] + names[2][1]
      for(let i = 0; i < mbox.length; i++){
        if(mbox[i][1] == 'A' && mbox[i][0] == "a"){
          mbox[i] = "Aa"
        }
      }
    }
    text(mbox[0],200+(75/2),50+(75/2))
    text(mbox[1],275+(75/2),50+(75/2))
    text(mbox[2],200+(75/2),125+(75/2))
    text(mbox[3],275+(75/2),125+(75/2))
    let geno = []
    let num = []
    for(let i = 0; i < mbox.length; i++){
      if(!geno.find(e => e == mbox[i])){
        geno.push(mbox[i])
        num.push(1)
      }else{
        num[geno.findIndex(e => e == mbox[i])] ++
      }
    }
    let genof = ""
    for(let i = 0; i < geno.length; i++){
      genof += (num[i] + "x " + geno[i] + "    ")
    }

    let pnum = [0,0]
    let phenof = ""
    for(let i = 0; i < mbox.length; i++){
      if(mbox[i][0] == "A"){pnum[0] ++}
      else if(mbox[i][0] == "a"){pnum[1] ++}
    }
    phenof = pnum[0] + 'x ' + names.A + "    " + pnum[1] + 'x ' + names.a
    textSize(14)
    text("Genotype:",275,225)
    text(genof,275,250)

    text("Phenotype:",275,275)
    text(phenof,275,300)
  }else if(numSelect.value() == "Dihybrid"){
    line(200,50,500,50)
    line(200,200,500,200)
    line(200,50,200,200)
    line(500,50,500,200)
    line(275,50,275,200)
    line(200,125,500,125)
    
    line(200+75,50,200+75,200)
    line(275+75,50,275+75,200)
    line(350+75,50,350+75,200)
    line(200,50+75/2,500,50+75/2)
    line(200,125+75/2,500,125+75/2)
    if(names[1].length == 4 && names[2].length == 4){ 
      let one = names[1]
      let two = names[2]
      let p1 = [
        one[0] + one[2],
        one[0] + one[3],
        one[1] + one[2],
        one[1] + one[3]
      ]
      let p2 = [
        two[0] + two[2],
        two[0] + two[3],
        two[1] + two[2],
        two[1] + two[3]
      ]
      let z = 75/2
      let y = 75/4
      text(p1[0],200+z,25)
      text(p1[1],200+3*z,25)
      text(p1[2],200+5*z,25)
      text(p1[3],200+7*z,25)

      text(p2[0],175,50+y)
      text(p2[1],175,50+3*y)
      text(p2[2],175,50+5*y)
      text(p2[3],175,50+7*y)

      let inner = []
      for(let i = 0; i < 4; i++){
        for(let j = 0; j < 4; j++){
          let temp = (p1[i][0] + p2[j][0] + p1[i][1] + p2[j][1])
          if(temp[0] == 'a' && temp[1] == 'A'){
            temp = temp.replaceAt(0,'A')
            temp = temp.replaceAt(1,'a')
          }
          if(temp[2] == 'b' && temp[3] == 'B'){
            temp = temp.replaceAt(2,'B')
            temp = temp.replaceAt(3,'b')
          }
          inner.push(temp)
        }
      }
      for(let i = 0; i < inner.length; i++){
        text(inner[i],200+(z*(i%4)*2)+z,50+(y*(i-(i%4))/2)+y)
      }

      let geno = []
      let num = []
      let genof = ""
      let pheno = []
      let pnum = [0,0,0,0]
      let phenof = ""

      for(let i = 0; i < inner.length; i++){
        if(!geno.find(e => e == inner[i])){
          geno.push(inner[i])
          num.push(1)
        }else{
          num[geno.findIndex(e => e == inner[i])] ++
        }
      }
      for(let i = 0; i < geno.length; i++){
        genof += (num[i] + "x " + geno[i] + "\n")
      }
      for(let i = 0; i < inner.length; i++){
        if(inner[i][0] == "A" && inner[i][2] == "B"){
          pnum[0] ++
        }else if(inner[i][0] == "A" && inner[i][2] == "b"){
          pnum[1] ++
        }else if(inner[i][0] == "a" && inner[i][2] == "B"){
          pnum[2] ++
        }else if(inner[i][0] == "a" && inner[i][2] == "b"){
          pnum[3] ++
        }

      }
      phenof = (
      pnum[0] + "x " + names.A + ', ' + names.B + "\n" +
      pnum[1] + "x " + names.A + ', ' + names.b + "\n" +
      pnum[2] + "x " + names.a + ', ' + names.B + "\n" +
      pnum[3] + "x " + names.a + ', ' + names.b + "\n"

      )

      textAlign(CENTER,TOP)
      textSize(14)
      text("Genotype:",200+z,225)
      text(genof,200+z,250)

      text("Phenotype:",350+z,225)
      text(phenof,350+z,250)
    }
  }
}