let res = 20
let jso = {"r": 'red',
           "g": 'green',
           "b": 'black',
           "y": 'yellow',
           "o": 'orange',
           "p": 'purple',
           "m": 'magenta',
           "c": 'teal'}
let m = `
-g-sbp -os
-rc-yb-sc
`
function setup() {
  createCanvas(400, 400);
  m = m.replace(/\n/,'')
  noStroke()
}

function draw() {
  background(220);
  let xpos = 0,ypos = 0
  let size = 1
  for(let i = 0; i < m.length; i++){
    switch(m.charAt(i)){
      case 's':
        size = 0.5
        break;
        case '-': 
        stroke(0)
        strokeWeight(2)
        break;
      case ' ':
        xpos++
        break;
      case '\n':
        ypos++
        xpos = 0
        break;
      default:
        fill(jso[m.charAt(i)])
        rect(xpos*res+((1-size/2)*res)-res/2,ypos*res+((1-size/2)*res)-res/2,res*size,res*size)
        noStroke()
        size = 1
        xpos++
        break;
    }
  }
}