let p1,sun,moon
function setup() {
  createCanvas(400, 400);
  textAlign(CENTER,TOP)
  textSize(16)
  sun = new Star(200,200,80, {colors: {primary: 'yellow',secondary: 'orange'},
                              outline:{width: 5},
                              name:   {value: 'Sun',showName: true, position: 'center'},
                            revolving:{isRevolving: false}})
  p1 = new Planet(200,300,40,{colors: {primary: 'green',secondary: 'blue'},
                              outline:{width: 3},
                              name:   {value: 'Earth',showName: true, position: 'bottom'},
                            revolving:{isRevolving: true, revolvesAround: sun,
                                       revolveSpeed: 1, revolveDistance: 100}})
  moon = new Planet(200,300,20,{colors: {primary: 'gray',secondary: 'darkslategray'},
                              outline:{width: 2},
                              name:   {value: 'Moon',showName: true, position: 'bottom'},
                            revolving:{isRevolving: true, revolvesAround: p1,
                                       revolveSpeed: 5, revolveDistance: 50}})
}

function draw() {
  background(220);
  p1.show()
  sun.show()
  moon.show()
}
// let OPTION_DEFAULT = {colors: {primary: 'white',secondary: 'black'},
//                               outline:{width: 1},
//                               name:   {showName: false},
//                             revolving:{isRevolving: false}}
class Planet{
  constructor(x,y,size=10,options=OPTION_DEFAULT){
    this.pos =createVector(x,y)
    this.posOriginal = createVector(x,y)
    this.size = size
    this.options = options

  }
  setColors(prim,second){
    this.options.colors.primary = prim
    this.options.colors.secondary = second
  }
  show(){
    fill(this.options.colors.primary)
    stroke(this.options.colors.secondary)
    strokeWeight(this.options.outline.width)
    if(this.options.revolving.isRevolving == true){
      this.pos.x -= this.options.revolving.revolvesAround.pos.x
      this.pos.y -= this.options.revolving.revolvesAround.pos.y
      this.pos.normalize()
      this.pos.rotate(radians(this.options.revolving.revolveSpeed))
      this.pos.mult(this.options.revolving.revolveDistance)
      this.pos.x += this.options.revolving.revolvesAround.pos.x
      this.pos.y += this.options.revolving.revolvesAround.pos.y
    }
    circle(this.pos.x,this.pos.y,this.size)
    if(this.options.name.showName == true){
      noStroke()
      fill('black')
      if(this.options.name.position == 'bottom'){
        textAlign(CENTER,TOP)
        text(this.options.name.value,this.pos.x,this.pos.y+this.size/2)
      }else if(this.options.name.position == 'center'){
        textAlign(CENTER,CENTER)
        text(this.options.name.value,this.pos.x,this.pos.y)       
      }
    }
  }
}
class Star extends Planet{
  constructor(x,y,size,options){
    super(x,y,size,options)
  }
}