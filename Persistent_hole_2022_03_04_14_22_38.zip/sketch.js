window.onload = main
let can
function main(){
  can = document.getElementById('canvas')
  can.width = 512; can.height = 512
  c = can.getContext('2d')
  clear(c)
  for(let i = 0; i < can.width; i++){
    for(let j = 0; j < can.height; j++){
      pixel(c,i,j,(j^i))
    }
  }

}
function clear(ctx){
  ctx.fillStyle = 'lightgray'
  ctx.fillRect(0,0,can.width,can.height)
}
function pixel(ctx,x,y,color){
  color = 'hsl(' + color + ',100%,50%)'
  ctx.fillStyle = color
  ctx.fillRect(x,y,1,1)
}