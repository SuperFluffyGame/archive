let m
function preload(){
  fetch('https://raw.githubusercontent.com/SuperFluffyGame/js-modules/main/p5/testModule1.js').then(response => response.text()).then(data => m = data)
}
function setup() {
  createCanvas(400, 400);
  console.log(m)
  eval(m)
}
function draw() {
  background(220);
}