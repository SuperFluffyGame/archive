window.onload = setup

let testButton
function setup(){
  //testButton = new Button('Chop 1 Wood')
  //testButton.setStyle('background: blue')
}
class Element{
  constructor(){
    this.id = ''
    this.class = ''
    this.style = ''
    this.html = ''
    this.style = ''
    this.hoverStyle = ''
    this.clickStyle = ''
  }
}
class Button extends Element{
  constructor(name='',id='',parent=document.body){
    super()
    this.id = id
    this.name = name
    this.html = document.createElement('button')
    this.html.textContent = this.name
    parent.appendChild(this.html)
    this.html.classList.add('default-button')
  }
}