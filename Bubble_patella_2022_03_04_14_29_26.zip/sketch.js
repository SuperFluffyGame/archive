let canvas = document.getElementById("canvas")
let gl = canvas.getContext("webgl2")

function main(){
  console.log(gl)
  
  gl.clearColor(0,0,0,1)
  gl.clear(gl.COLOR_BUFFER_BIT)
  
  let program = initShaderProgram(gl,vsSource,fsSource)
  
  let verts = [
     1, 1,
    -1, 1,
    -1,-1,
     1, 1,
     1,-1,
    -1,-1,
  ]
  
  let aPosition = gl.getAttribLocation(program,"aPosition")
  createBuffer(gl,verts,aPosition)
  
  gl.useProgram(program)
  
  gl.drawArrays(gl.TRIANGLES,0,verts.length/2)
}
main()