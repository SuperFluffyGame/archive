window.addEventListener('load',main)
let hi
let can,c
function main(){
  hi = window.open('','title')
  hi.document.write("<title>HOI</title>")

  can = hi.document.createElement('CANVAS')
  hi.document.body.appendChild(can)
  //c = can.getContext('2d')

  console.log(window)
}
