let minput
function setup() {
  createCanvas(400, 400);
  minput = new InputController()
  // minput.onClick = () => {
  //   console.log("Clicked")
  // }
  minput.mouseDown = () => {
    console.log(0)
  }
}

function draw() {
  background(220);
}
class InputController{
  constructor(){
    this.clickFunctions = []
    this.downFunctions = []
    this.numClicks = 0
    document.addEventListener('click',()=>{
      this.numClicks ++
      for(let i in this.clickFunctions){
        this.clickFunctions[i](this.numClicks)
      }
    })
    document.addEventListener('mousedown',()=>{
      for(let i in this.downFunctions){
        this.downFunctions[i]()
      }   
    })
  }
  set onClick(f){
    if(typeof f == 'function'){
      this.clickFunctions.push(f)
    }else{
      console.error(f + " is not a function")
    }
  }
  set mouseDown(f){
    if(typeof f == 'function'){
      this.downFunctions.push(f)
    }else{
      console.error(f + " is not a function")
    }  
  }
}