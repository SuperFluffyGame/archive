let chunkSize = 50
let chunkOffset = {x: 0, y: 0}
let mainGrid

function setup() {
  createCanvas(400, 400);
  rectMode(CORNERS)
  mainGrid = new Grid(40,40)
  background(220)
}
let x = 0
let y = 0
function draw() {
  strokeWeight(1)
  // drawChunk(floor(x),floor(y))
  // //drawLineGrid()
  // x += 0.05
  // if(x > width/chunkSize){
  //   y++
  //   x = 0
  // }
  background(220)
  let ch = getChunkUnderPoint(mouseX,mouseY)
  drawChunks(ch.x+2,ch.y+2,3)

}
function Point(x,y){
  return {x: x, y: y}
}
function drawLineGrid(){
  stroke(0)
  for(let i = -floor(chunkOffset.x/chunkSize)-1; 
      i < -floor(chunkOffset.x/chunkSize)+(width/chunkSize)-1; i++){
    line(i*chunkSize+chunkSize+chunkOffset.x,0,
         i*chunkSize+chunkSize+chunkOffset.x,height)
  }
  for(let i =  -floor(chunkOffset.y/chunkSize)-1; 
      i < -floor(chunkOffset.y/chunkSize)+(height/chunkSize)-1; i++){
    line(0,i*chunkSize+chunkSize+chunkOffset.y,
         width,i*chunkSize+chunkSize+chunkOffset.y)
  }
}
let dotSpacing = chunkSize
let dotsPerChunk
let p = 0
function drawChunk(x,y){
  dotsPerChunk = floor(chunkSize/dotSpacing)
  //rect(x*chunkSize+chunkOffset.x,y*chunkSize+chunkOffset.y,    x*chunkSize+chunkSize+chunkOffset.x,y*chunkSize+chunkSize+chunkOffset.y)
  for(let i = 0; i < dotsPerChunk+1; i++){
    for(let j = 0; j < dotsPerChunk+1; j++){
      strokeWeight(mainGrid.get(i+x*dotsPerChunk,j+y*dotsPerChunk)*3+1)
      point(x*chunkSize+i*dotSpacing,
            y*chunkSize+j*dotSpacing)
    }
  }
  marchLine([mainGrid.get(x,y),
             mainGrid.get(x+1,y),
             mainGrid.get(x+1,y+1),
             mainGrid.get(x,y+1)],
            {x: x*chunkSize, y: y*chunkSize},{x: chunkSize, y: chunkSize})
}
function getChunkUnderPoint(x,y){
  return {x: floor(mouseX/chunkSize), y: floor(mouseY/chunkSize)}
}
function drawChunks(x,y,r){
  for(let i = -r+1; i <= r-1; i++){
    for(let j = -r+1; j <= r-1; j++){
      drawChunk(i+x,j+y)
    }
  }
}
class Grid{
  constructor(w,h){
    this.a = []
    this.width = w
    this.height = h
    for(let i = 0; i < w*h; i++){
      this.a.push(round(random()))
    }
  }
  get(x,y){
    return this.a[y*this.width+x]
  }
}

function getPermutationLine(array){
  let stringy = String(array)
  //top left, top right, bottom right, bottom left
  switch(stringy) {
    case '0,0,0,0':
      return 0
      break;
    case '1,0,0,0':
      return [[0,0.5,0.5,0]]
      break;  
    case '0,1,0,0':
      return [[1,0.5,0.5,0]]
      break;  
    case '0,0,1,0':
      return [[1,0.5,0.5,1]]
      break; 
    case '0,0,0,1':
      return [[0,0.5,0.5,1]]
      break;  
    case '1,1,0,0':
      return [[0,0.5,1,0.5]]
      break;  
    case '1,0,1,0':
      return [[0,0.5,0.5,0],[0.5,1,1,0.5]]
      break;  
    case '1,0,0,1':
      return [[0.5,0,0.5,1]]
      break; 
    case '0,1,1,0':
      return [[0.5,0,0.5,1]]
      break;  
    case '0,1,0,1':
      return [[0,0.5,0.5,1],[0.5,0,1,0.5]]
      break; 
    case '0,0,1,1':
      return [[0,0.5,1,0.5]]
      break;
    case '1,1,1,0':
      return [[0,0.5,0.5,1]]
      break;
    case '1,1,0,1':
      return [[1,0.5,0.5,1]]
      break;
    case '1,0,1,1':
      return [[0.5,0,1,0.5]]
      break;
    case '0,1,1,1':
      return [[0,0.5,0.5,0]]
      break;
    case '1,1,1,1':
      return 0
      break;
  }
}
function marchLine(points,init,mult){
  stroke(0)
  strokeWeight(2)
  let perm = getPermutationLine(points)
  if(perm != 0 || perm != 1)
  for(let i = 0; i<points.length-1; i++){
    for(let j = 0; j < perm.length; j++){
      line(perm[j][0]*mult.x+init.x,perm[j][1]*mult.y+init.y,
           perm[j][2]*mult.x+init.x,perm[j][3]*mult.y+init.y)
    }
  }
}