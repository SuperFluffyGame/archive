let md = 1,lendiv = 1,cmult = 1
function setup() {
  createCanvas(512, 512);
  pixelDensity(1)
  colorMode(HSL)
  textSize(20)
  textAlign(LEFT, TOP)
  m()
}
function m(){
  background(11);
  loadPixels()
  for(let i = 0; i < width/lendiv; i+= md){
    for(let j = 0; j < height/lendiv; j+= md){
      let index = (width*4*i) + 4*j
      let c = color(((i) ^ (j))*cmult,100,50)
      pixels[index] = red(c)  
      pixels[index+1] = green(c)  
      pixels[index+2] = blue(c)  
      pixels[index+3] = 255 
      for(let k = 0; k < md; k++){
        for(let l = 0; l < md; l++){
          let i2 = index+(width*4*k) + (4*l)
          pixels[i2] = red(c)  
          pixels[i2+1] = green(c)  
          pixels[i2+2] = blue(c)  
          pixels[i2+3] = 255        
        }
      }
    }
  }
  updatePixels()
  text(round(frameRate(),2),0,0)
}