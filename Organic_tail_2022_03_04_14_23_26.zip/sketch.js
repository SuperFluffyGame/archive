window.onload = main
let woodButton
function main(){
  console.log('main')
  woodButton = new Button('beginningButton')
}

class Button{
  constructor(id,func){
    this.id = id
    this.func = func
    this.html = document.createElement('button')
    this.html.id = this.id
    document.body.appendChild(this.html)
  }
}