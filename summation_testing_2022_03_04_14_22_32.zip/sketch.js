let out
let EULER = 2.71828182846
function setup() {
  let now = Date.now()
  createCanvas(400, 400);
  out = 0
  for(let i = 0; i < 100; i++){
    out += 1/2**i  *-(i%2*2-1)
  }
  let elapsed = Date.now() - now
  console.log(out)
  console.log(elapsed + " milliseconds")
}
function tri(n){
  let ou = (n*(n-1))/2
  return ou
}
function factorial(n){
  let fa = 1
  for(let i = n; n > 0; n--){
    fa*=n
  }
  return fa
}