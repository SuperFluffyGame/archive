let myCanvas = [
  [0,0,0,0,0],
  [1,1,1,1,1],
  [2,2,2,2,2],
  [3,3,3,3,3],
  [4,4,4,4,4]
]

function setup() {
  createCanvas(400, 400);
  noStroke()
}

function draw() {
  background(220);
  clearMyCanvas()
  myCanvasLine(1,2,3,3)  
  
  
  
  for(let i = 0; i < myCanvas.length; i++){
    for(let j = 0; j < myCanvas[i].length; j++){
      fill(myCanvas[j][i]*(255/5))
      rect(i*50,j*50,50,50)
    }
  }
}

function clearMyCanvas(){
  for(let i = 0; i < myCanvas.length; i++){
    for(let j = 0; j < myCanvas[i].length; j++){
      myCanvas[j][i] = 0
    }
  }
}

function myCanvasLine(x1,y1,x2,y2){
  for(let i = 0; i < myCanvas.length; i++){
    for(let j = 0; j < myCanvas[i].length; j++){
      let s = myCanvas[j][i]
      if(i >= x1 && j >= y1 && i <= x2 && j <= y2){
         myCanvas[j][i] = 5
      }
    }
  }
}