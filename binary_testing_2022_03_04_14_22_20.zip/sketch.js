let a = 0b100000000000000000000000000000000000000000000000000000
function setup() {
  createCanvas(400, 400);
  console.log(a)
  console.log(Number.MAX_SAFE_INTEGER)
}

function draw() {
  background(220);
}