
function setup() {
  let tsize = 10
  let tsize2 = floor(350/tsize)
  createCanvas(400, 400);
  background(220);
  textSize(tsize)
  textAlign(CENTER,TOP)
  for(let i = 1; i <= 2000000; i++){
    collatz(i)
    //text(iterations,floorToNum(i-1,tsize2)+tsize,i*tsize-tsize-floorToNum(i-1,tsize2)*tsize)
    if(iterations > highestIter){
      highestIter = iterations
    }
    iterations = 0
  }
  line(0,350,width,350)
  text("HIGHEST ITERATION: " + highestIter,width/2,375)
}

let highestNum = 0
let highestIter = 0
let iterations = 0
function collatz(num){
  if(num <= 1){
    return
  }
  if(num % 2 == 0){
    num /= 2
  }else{
    num *= 3
    num++
  }
  iterations++
  if(num > highestNum){highestNum = num}
  collatz(num)
}
function floorToNum(num1,num2){
  let modnum = num1 % num2
  return num1 - modnum
}