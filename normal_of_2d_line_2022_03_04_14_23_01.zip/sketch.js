let p1,p2
function setup() {
  createCanvas(400, 400);
  p1 = new moveablePoint(100,100)
  p2 = new moveablePoint(200,200)
}

function draw() {
  background(220);
  p1.show()
  p2.show()
  strokeWeight(2)
  line(p1.pos.x,p1.pos.y,p2.pos.x,p2.pos.y)
  centerPoint = p5.Vector.lerp(p1.pos,p2.pos,0.5)
  angle = atan2(p1.pos.x-p2.pos.x,p1.pos.y-p2.pos.y)
  console.log(angle)
  angle+=PI/2
  n = createVector(50*sin(angle)+centerPoint.x,50*cos(angle)+centerPoint.y)
  stroke('blue')
  line(centerPoint.x,centerPoint.y,n.x,n.y)
  strokeWeight(4)
  stroke('black')
  point(centerPoint)
  point(n)

}
function getNormal(v1,v2){
  
}
class moveablePoint{
  constructor(x,y){
    this.pos = createVector(x,y)
  }
  show(){
    this.checkMovement()
    if(this.mouseOver){
      strokeWeight(10)
    }else{
      strokeWeight(5)
    }
    point(this.pos)
  }
  checkMovement(){
    if(this.mouseOver && mouseIsPressed){
      this.pos = createVector(mouseX,mouseY)
    }
    if(mouseX > this.pos.x-10 && mouseX < this.pos.x+10 &&
       mouseY > this.pos.y-10 && mouseY < this.pos.y+10){
     this.mouseOver = true
    }else{
      this.mouseOver = false
    }

  }
}